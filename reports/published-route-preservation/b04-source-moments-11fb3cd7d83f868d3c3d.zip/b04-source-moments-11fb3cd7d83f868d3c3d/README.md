# B04 exact source-candidate certificate

Open `index.html` for the result, all-stage figure, exact witness, source scope and the complete 14-dimensional optimal-family description.

This is a mathematical exact-decimal candidate certificate, not a claim that the original floating-point solver was certified or that this source revision generated the historical result. The commented and active rounded initializations remain separate cases. Archived MATLAB, Pascal and FIG files are not included.

## Offline verification

Extract `../b04-source-moments-11fb3cd7d83f868d3c3d.zip` into a fresh directory, enter its report folder, and run:

```sh
sha256sum -c SHA256SUMS
python3 -B offline_check.py
```

Verification uses Python's standard library and the included source-root snapshot. It recomputes the exact certificate and all-stage geometry from saved rational inputs, then checks the saved SVG/PNG hashes. It requires no Git checkout, network, solver, Matplotlib, archive source or private file. The included renderer is provenance and is not executed.

`publication-manifest.json` records the fixed mathematical source anchor, Git blob identities for selected source/evidence bytes, the current staging-adapter hash separately, and hashes of every bundle file except the manifest and checksum list themselves. `certificate.json`, `minimal-inputs.json`, `stage-sets.json`, and `figures/` are directly inspectable.
