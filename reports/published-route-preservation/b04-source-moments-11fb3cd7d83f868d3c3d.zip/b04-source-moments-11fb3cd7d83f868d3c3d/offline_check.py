#!/usr/bin/env python3
"""Verify the saved B04 exact certificate and stage sets without Git or plotting."""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUNDLE = HERE
ROOT = HERE / "source-root"
MANIFEST = json.loads((BUNDLE / "publication-manifest.json").read_text(encoding="utf-8"))

def require(ok, message):
    if not ok: raise ValueError(message)

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

checksum_rows = {}
for line in (BUNDLE / "SHA256SUMS").read_text(encoding="ascii").splitlines():
    digest, name = line.split("  ", 1)
    require(len(digest) == 64 and name not in checksum_rows and ".." not in Path(name).parts,
            "invalid checksum inventory")
    checksum_rows[name] = digest
expected_names = set(MANIFEST["files"]) | {"publication-manifest.json"}
require(set(checksum_rows) == expected_names, "checksum inventory differs")
for rel, expected in checksum_rows.items():
    path = BUNDLE / rel
    require(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == expected,
            "bundle checksum mismatch: " + rel)
for rel, expected in MANIFEST["files"].items():
    path = BUNDLE / rel
    require(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == expected,
            "bundle file hash mismatch: " + rel)
for rel, entry in MANIFEST["source_anchor"]["files"].items():
    data = (ROOT / rel).read_bytes()
    require(hashlib.sha256(data).hexdigest() == entry["sha256"], "snapshot SHA-256 mismatch: " + rel)
    git_blob = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
    require(git_blob == entry["git_blob_sha1"], "snapshot Git-blob identity mismatch: " + rel)

import sys
sys.path.insert(0, str(ROOT / "benchmarks/reporting/mpc08_explicit"))
sys.path.insert(0, str(ROOT / "docs/research/tools"))
checker = load("b04_source_moment_checker", ROOT / "docs/research/tools/check_b04_source_moments.py")
geometry = load("b04_source_moment_geometry", ROOT / "scripts/reports/b04_source_moments/geometry.py")
inputs = json.loads((ROOT / "docs/research/evidence/b04-source-moment-inputs.json").read_text())
certificate = json.loads((ROOT / "docs/research/evidence/b04-source-moment-certificate.json").read_text())
stage_sets = json.loads((ROOT / "docs/research/evidence/b04-source-moment-stage-sets.json").read_text())
checker.verify_certificate(certificate, inputs)
geometry.verify_stage_sets(stage_sets, certificate)
figure = json.loads((ROOT / "docs/research/evidence/b04-source-moment-figures/figure-export.json").read_text())
for output in figure["outputs"]:
    data = (ROOT / "docs/research/evidence/b04-source-moment-figures" / output["path"]).read_bytes()
    require(hashlib.sha256(data).hexdigest() == output["sha256"] and len(data) == output["bytes"],
            "figure export hash mismatch: " + output["path"])
print("B04 source-candidate certificate, 17 stage sets, and saved figure hashes verified")
