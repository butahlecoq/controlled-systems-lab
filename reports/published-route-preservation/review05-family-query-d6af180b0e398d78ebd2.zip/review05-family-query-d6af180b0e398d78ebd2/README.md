# Immutable REVIEW-05 publication

The two named report subdirectories are byte-preserved frozen evidence. Their
original SHA256SUMS, checks, source snapshots, timings and raw ZIP are unchanged.
The outer publication manifest records current independent rechecks separately.

After downloading/extracting the publication ZIP into a fresh directory, enter
this route and run `sha256sum -c SHA256SUMS`. For complete raw query data, verify
the frozen query manifest, then extract its `offline.zip` into a new empty folder.
Inside that folder run `sha256sum -c SHA256SUMS`, followed by
`python3 post-capture/check_family_query.py .`. This executes only independent
checks; it never runs the recorded native binary. The frozen REPRODUCE.md names
the optional plotting environment and distinguishes historical host paths from
portable commands. The phase report's REPRODUCE.md similarly checks saved data.

Publication happens only through the existing reviewed main/CI deployment path
and its current-head freshness gate. This local stager does not deploy anything.
