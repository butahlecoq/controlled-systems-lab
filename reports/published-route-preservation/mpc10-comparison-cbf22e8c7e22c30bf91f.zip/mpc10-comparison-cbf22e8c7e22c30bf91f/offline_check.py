from pathlib import Path
import importlib.util,json,sys
r=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('publication',r/'source-root/scripts/reports/stage_mpc10_comparison.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
print(json.dumps(m.offline_check(r,full='--full' in sys.argv)))
