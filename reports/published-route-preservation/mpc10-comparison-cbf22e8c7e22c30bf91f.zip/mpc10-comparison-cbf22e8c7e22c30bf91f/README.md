# MPC10 complete offline evidence

Original immutable capture and figures remain byte-preserved under original/.
The strengthened current checking/metrics receipt is a separate reading layer.
Authentic minimal Git objects are inside the ZIP only, under source-root/.git;
this is not a full checkout/history and includes no host configuration/hooks.

Extract ../mpc10-comparison-cbf22e8c7e22c30bf91f.zip into a fresh directory and enter this report folder:

```sh
sha256sum -c OFFLINE_SHA256SUMS
python3 -B offline_check.py
<QUALIFIED_SCIP_PYTHON> -B offline_check.py --full
```

The first command needs Python3.11+ and Git only and checks authentic helper and
capture-source identities, all raw/current-receipt bindings and derived metrics.
The --full command additionally needs PySCIPOpt6.3.0/SCIP10.0.2: it independently
rechecks the exact oracle/whole LP rows, ties, raw responses/solutions and rebuilds
SCIP indicator models for byte comparison. It performs NO optimization or native
execution. It works outside a source checkout without a network. Missing source
objects refuse validation; no cached-success fallback exists. Matplotlib is not
needed for saved checking. Optional figure reproduction requires the qualified
Matplotlib3.11.2 environment; native reproduction requires the normal reviewed
CSL/backend build. Historical binary paths are evidence, not portable commands.

119 native LPs,24 unrestricted SCIP models,131 fixed-history solves and one
node-limit attempt remain separate. All26 fixtures and failed/unsupported/raw
attempts are retained. Continuous proof statuses and numerical witnesses remain
separate; descriptive one-observation clocks support no performance ranking.
Staging is not deployment. Managed current-main CI and live verification remain
required before any issue completion. No API/package/release change is introduced.
