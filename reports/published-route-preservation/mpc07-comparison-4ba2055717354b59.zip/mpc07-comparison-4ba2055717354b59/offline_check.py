from pathlib import Path
import importlib.util,json
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('mpc07_stage',root/'source-root/scripts/reports/stage_mpc07_comparison.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.verify_export(root/'source-root',json.loads((root/'source-files.json').read_bytes()))
_,_,checks=m.validate({name:root/'evidence'/name for name in m.ANCHORS},repository=root/'source-root')
online=m.online_inputs({name:root/'evidence'/name for name in m.ONLINE_ANCHORS})
checks['online']=m.validate_online(online,repository=root/'source-root',sources={name:root/'evidence'/name for name in m.ANCHORS})
assert checks==json.loads((root/'verification.json').read_bytes()),'publication check sidecar differs'
print(json.dumps(checks))
