#include <csl/adapters/convex/highs.hpp>
#include <csl/adapters/lp/highs.hpp>
#include <csl/adapters/polyhedral/qhull.hpp>
#include <csl/geometry/affine_sum.hpp>
#include <csl/input/scenario_loader.hpp>
#include <csl/optimization/convex_backend.hpp>
#include <csl/optimization/linear_program.hpp>
#include <csl/registry/registry.hpp>
#include <csl/synthesis/strategy_a/strategy.hpp>
#include <csl/synthesis/strategy_b/direct_joint.hpp>

#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

using namespace csl;
using namespace csl::registry;

namespace {
using Clock = std::chrono::steady_clock;

template<class T, class... R>
T take(std::variant<T, R...> value, std::string_view name) {
    if (auto* result = std::get_if<T>(&value)) return std::move(*result);
    std::ostringstream message;
    message << name << " failed";
    std::visit([&](const auto& error) {
        using E = std::decay_t<decltype(error)>;
        if constexpr (std::is_same_v<E, Rejection>) {
            for (const auto& diagnostic : error.diagnostics)
                message << ": " << diagnostic.field << " " << diagnostic.explanation;
        } else if constexpr (std::is_same_v<E, Unsupported>) {
            for (const auto& diagnostic : error.diagnostics)
                message << ": " << diagnostic.field << " " << diagnostic.explanation;
        }
    }, value);
    throw std::runtime_error(message.str());
}

template<class Port>
PreparedProvider<Port> selected(Registration<Port> registration, std::string representation) {
    Registry<Port> registry;
    const Method method{registration.identity.id, registration.identity.version};
    if (registry.add(std::move(registration))) throw std::runtime_error("provider registration failed");
    Requirements requirements;
    requirements.output.representation = {std::move(representation)};
    if constexpr (std::is_same_v<Port, GeometryPort> || std::is_same_v<Port, ConversionPort>)
        requirements.output.relation = SetRelation::equivalent;
    return take(prepare_provider(select_provider(registry, method, requirements)), "provider selection");
}

struct Query {
    std::string id, p_exact, v_exact, u_exact, value_exact;
    double p{}, v{}, u{}, u1{}, value{};
    bool nonunique{};
};

std::vector<Query> read_queries(const char* path) {
    std::ifstream input(path);
    if (!input) throw std::runtime_error("cannot open exact reference queries");
    std::string line;
    if (!std::getline(input, line)) throw std::runtime_error("query CSV is empty");
    std::vector<Query> queries;
    while (std::getline(input, line)) {
        std::istringstream row(line);
        std::vector<std::string> fields;
        std::string field;
        while (std::getline(row, field, ',')) fields.push_back(field);
        const auto parse_rational = [](const std::string& text) {
            const auto slash = text.find('/');
            if (slash == std::string::npos) return std::stod(text);
            return std::stod(text.substr(0, slash)) / std::stod(text.substr(slash + 1));
        };
        if (fields.size() == 7) {
            queries.push_back({fields[0], fields[1], fields[2], fields[3], fields[4],
                std::stod(fields[5]), std::stod(fields[6]), parse_rational(fields[3]), 0.0,
                parse_rational(fields[4]), false});
        } else if (fields.size() == 10) {
            queries.push_back({fields[0], fields[1], fields[2], fields[3], fields[5],
                parse_rational(fields[6]), parse_rational(fields[7]), parse_rational(fields[8]),
                parse_rational(fields[9]), parse_rational(fields[5]), true});
        } else {
            throw std::runtime_error("query CSV row must have seven (unique) or ten (nonunique) fields");
        }
    }
    if (queries.empty()) throw std::runtime_error("no exact reference queries");
    return queries;
}

SetHandle input_box() {
    auto h = sets::make_h({{"mpc08-control-box"}, 1, {"u0"}},
        {take(numeric::snapshot(Matrix{2,1,{1,-1}}), "control matrix"),
         take(numeric::snapshot_vector(Vector{1,1}), "control bounds"),
         take(numeric::snapshot(Matrix{0,1,{}}), "control equalities"),
         take(numeric::snapshot_vector(Vector{}), "control equality values")});
    return take(std::move(h), "control set").as_handle();
}

SetHandle terminal_set() {
    auto h = sets::make_h({{"mpc08-invariant-terminal-set"}, 2, {}},
        {take(numeric::snapshot(Matrix{4,2,{1,1,-1,-1,1,2,-1,-2}}), "terminal matrix"),
         take(numeric::snapshot_vector(Vector{1,1,1,1}), "terminal bounds"),
         take(numeric::snapshot(Matrix{0,2,{}}), "terminal equalities"),
         take(numeric::snapshot_vector(Vector{}), "terminal equality values")});
    return take(std::move(h), "terminal set").as_handle();
}

problem::ResolvedProblem resolve(const Query& query) {
    const LinearStage flow{Matrix{2,2,{1,1,0,1}}, Matrix{2,1,{0,1}},
                            Matrix{2,0,{}}, Vector{0,0}};
    if (query.nonunique) {
        Problem source{{"mpc08-double-integrator-horizon-2-nonunique"},
            std::make_shared<const SystemModel>(SystemModel{{{2,1,0}, TimeDomain::discrete, flow}, {}}),
            {0,1,2}, KnownInitial{{query.p,query.v}}, ContinuousDomain{{input_box(),input_box()}},
            {UniversalSet{2},UniversalSet{2},UniversalSet{2}}, {}, {}, InformationPattern::nominal_open_loop,
            QuadraticTerminal{Matrix{2,2,{0,0,0,2}}, Vector{0,0}, 0}};
        return take(problem::resolve(source,
            {problem::UncertaintyStructure::stage_product_uncoupled, {}, {}}), "nonunique problem resolution");
    }
    Problem source{{"mpc08-double-integrator-horizon-1"},
        std::make_shared<const SystemModel>(SystemModel{{{2,1,0}, TimeDomain::discrete, flow}, {}}),
        {0,1}, KnownInitial{{query.p,query.v}}, ContinuousDomain{{input_box()}},
        {UniversalSet{2}, terminal_set()}, {}, {}, InformationPattern::nominal_open_loop,
        QuadraticTerminal{Matrix{2,2,{2,0,0,2}}, Vector{0,0}, 0}};
    return take(problem::resolve(source,
        {problem::UncertaintyStructure::stage_product_uncoupled, {}, {}}), "problem resolution");
}

struct Providers {
    std::shared_ptr<StrategyRegistry> strategies;
    std::shared_ptr<Registry<GeometryPort>> projections, affines;
    std::shared_ptr<Registry<ConversionPort>> conversions;
    std::shared_ptr<Registry<LPPort>> lps;
    std::shared_ptr<Registry<ConvexPort>> convexes;
    ModuleId lp_id, convex_id, strategy_a_id, strategy_b_id;
};

std::string json_escape(std::string_view value) {
    std::string out;
    for (const unsigned char ch : value) {
        switch (ch) {
        case '"': out += "\\\""; break;
        case '\\': out += "\\\\"; break;
        case '\n': out += "\\n"; break;
        case '\r': out += "\\r"; break;
        case '\t': out += "\\t"; break;
        default: if (ch >= 0x20) out += static_cast<char>(ch); break;
        }
    }
    return out;
}

std::string stop_summary(const SynthesisStopEvidence& stop) {
    std::string summary;
    const auto append = [&](const Diagnostics& diagnostics) {
        for (const auto& diagnostic : diagnostics) {
            if (!summary.empty()) summary += "; ";
            summary += diagnostic.field + ": " + diagnostic.explanation;
        }
    };
    std::visit([&](const auto& evidence) {
        using T = std::decay_t<decltype(evidence)>;
        if constexpr (std::is_same_v<T, ScopedOperationStopped>) summary = evidence.stop.diagnostics;
        else if constexpr (std::is_same_v<T, ScopedRequestRejection>) append(evidence.diagnostics);
        else if constexpr (std::is_same_v<T, ContractValidationFailure>) append(evidence.diagnostics);
    }, stop);
    return summary;
}

Providers make_providers() {
    auto lp = take(adapters::lp::make_highs_registration(), "HiGHS LP registration");
    auto convex = take(adapters::convex::make_highs_registration(), "HiGHS convex registration");
    const auto lp_id=lp.identity.id, convex_id=convex.identity.id;
    auto converter = take(adapters::polyhedral::make_qhull_registration(lp), "Qhull registration");
    auto projection = geometry::polyhedral::make_projection_registration();
    auto affine = geometry::make_affine_sum_registration({
        selected(geometry::make_lp_hull_reducer_registration(), ""),
        selected(lp, "csl.program-result.v1"),
        selected(converter, "csl.polyhedron.v")});

    Providers result;
    result.projections = std::make_shared<Registry<GeometryPort>>();
    result.affines = std::make_shared<Registry<GeometryPort>>();
    result.conversions = std::make_shared<Registry<ConversionPort>>();
    result.lps = std::make_shared<Registry<LPPort>>();
    result.convexes = std::make_shared<Registry<ConvexPort>>();
    const Method pm{projection.identity.id,{}}, am{affine.identity.id,{}},
        cm{converter.identity.id,{}}, lm{lp.identity.id,{}}, qm{convex.identity.id,{}};
    if (result.projections->add(projection) || result.affines->add(affine) ||
        result.conversions->add(converter) || result.lps->add(lp) || result.convexes->add(convex))
        throw std::runtime_error("provider registry failed");
    Requirements h, v, program;
    h.output.representation = {"csl.polyhedron.h"}; h.output.relation = SetRelation::equivalent;
    v.output.representation = {"csl.polyhedron.v"}; v.output.relation = SetRelation::equivalent;
    program.output.representation = {"csl.program-result.v1"};
    auto checked = take(check_providers(select_provider(*result.projections,pm,h),
        select_provider(*result.affines,am,v), select_provider(*result.conversions,cm,h),
        select_provider(*result.lps,lm,program), select_provider(*result.convexes,qm,program)), "Strategy A providers");
    auto a = synthesis::strategy_a::make_registration(std::move(checked));
    auto b = synthesis::strategy_b::make_registration(*result.lps, *result.convexes);
    const auto a_id = a.identity.id, b_id = b.identity.id;
    result.strategies = std::make_shared<StrategyRegistry>();
    if (result.strategies->add(std::move(a)) || result.strategies->add(std::move(b)))
        throw std::runtime_error("strategy registry failed");
    result.lp_id = lp_id; result.convex_id = convex_id;
    result.strategy_a_id = a_id; result.strategy_b_id = b_id;
    return result;
}

bool candidate_contains(const SynthesisResult& result, const Query& query,
                        std::string& labels, std::size_t& inequalities,
                        std::size_t& equalities) {
    if (!result.family) return false;
    const auto* candidate = std::get_if<CandidateFamily>(&result.family->outcome());
    if (!candidate || !candidate->relation.payload) return false;
    const sets::SetData* data = candidate->relation.payload->h_relation_for_recording();
    if (const auto* history = dynamic_cast<const synthesis::strategy_a::CandidateHistory*>(candidate->relation.payload.get()))
        data = &history->history.relation;
    if (!data) return false;
    const auto representation = data->representation();
    const auto* h = std::get_if<sets::HRepresentation>(&representation);
    if (!h) return false;
    inequalities = h->inequalities.rows(); equalities = h->equalities.rows();
    const auto metadata = data->metadata();
    for (std::size_t i=0; i<metadata->coordinate_labels.size(); ++i) {
        if (i) labels += ";";
        labels += metadata->coordinate_labels[i];
    }
    const Vector point = query.nonunique
        ? Vector{query.p,query.v,query.p+query.v,query.v+query.u,
                 query.p+2*query.v+query.u,query.v+query.u+query.u1,query.u,query.u1}
        : Vector{query.p,query.v,query.p+query.v,query.v+query.u,query.u};
    if (h->inequalities.cols() != point.size() || h->equalities.cols() != point.size()) return false;
    constexpr double tolerance = 2e-6;
    for (std::size_t r=0; r<h->inequalities.rows(); ++r) {
        double lhs=0; for (std::size_t c=0; c<point.size(); ++c) lhs += h->inequalities(r,c)*point[c];
        if (lhs > h->upper_bounds[r] + tolerance) return false;
    }
    for (std::size_t r=0; r<h->equalities.rows(); ++r) {
        double lhs=0; for (std::size_t c=0; c<point.size(); ++c) lhs += h->equalities(r,c)*point[c];
        if (std::abs(lhs-h->equality_values[r]) > tolerance) return false;
    }
    return true;
}

void run_one(Providers& providers, const Query& query, bool use_a,
             std::size_t repetition, bool warmup) {
    const auto started=Clock::now();
    std::string status="failed", error, labels;
    bool result_optimal=false, candidate_member=false;
    bool family_present=false;
    int termination_code=-1, outcome_code=-1;
    std::size_t rows=0, equalities=0;
    std::string strategy_id, stop_details;
    try {
        const auto resolved=resolve(query);
        FamilyRequest family;
        family.profile="nominal_open_loop";
        family.objective=resolved.identity(); family.target=FamilyTarget::candidate_relaxation;
        family.assurance=Assurance::numerical; family.representation={"csl.polyhedron.h"};
        StrategyConfiguration configuration;
        configuration.strategy=use_a?providers.strategy_a_id:providers.strategy_b_id;
        configuration.lp=providers.lp_id; configuration.convex=providers.convex_id;
        configuration.representation=family.representation;
        strategy_id=configuration.strategy.value;
        const StrategyRequest request{resolved,configuration,family,{},{}};
        Requirements output;
        output.output.representation=family.representation;
        output.output.family=family.target;
        const auto prepared=take(providers.strategies->prepare(request,output),"strategy preparation");
        auto workspace=prepared.create();
        if (!workspace) throw std::runtime_error("strategy workspace is null");
        ExecutionContext context; context.numerical=family.numerical;
        context.resources=std::make_shared<const ResourcePolicy>(ResourcePolicy{1,1,1,{}});
        auto result=take(workspace->run(context),"strategy run");
        family_present=result.family.has_value();
        termination_code=static_cast<int>(result.termination);
        outcome_code=static_cast<int>(result.outcome.value);
        result_optimal=result.termination==Termination::completed && result.outcome.value==MathematicalOutcome::optimal;
        stop_details=stop_summary(result.stop);
        candidate_member=candidate_contains(result,query,labels,rows,equalities);
        const auto membership_status=candidate_member?"candidate_contains_analytic_reference_history":
            (result.family?"candidate_excludes_analytic_reference_history":"no_candidate_family");
        status=result.termination==Termination::completed?membership_status:
            "noncompleted_"+std::string(membership_status);
    } catch (const std::exception& exception) {
        error=exception.what();
    }
    const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-started).count();
    std::cout << "{\"schema\":\"csl.mpc08-explicit-candidate-observation/1\",\"fixture\":\""
        << (query.nonunique?"nonunique_horizon_2":"unique_horizon_1") << "\",\"horizon\":"
        << (query.nonunique?2:1) << ",\"query_id\":\""
        << query.id << "\",\"strategy\":\"" << json_escape(strategy_id) << "\",\"warmup\":"
        << (warmup?"true":"false") << ",\"repetition\":" << repetition
        << ",\"status\":\"" << status << "\",\"termination_optimal\":"
        << (result_optimal?"true":"false") << ",\"family_present\":" << (family_present?"true":"false")
        << ",\"termination_code\":" << termination_code << ",\"outcome_code\":" << outcome_code
        << ",\"candidate_contains_exact_reference_history\":"
        << (candidate_member?"true":"false") << ",\"action_and_value_match_exact_reference\":null"
        << ",\"expected_value_exact\":\"" << query.value_exact
        << "\",\"candidate_inequality_rows\":" << rows << ",\"candidate_equality_rows\":" << equalities
        << ",\"coordinate_labels\":\"" << json_escape(labels) << "\",\"elapsed_ns\":" << elapsed
        << ",\"stop_details\":\"" << json_escape(stop_details)
        << "\",\"error\":\"" << json_escape(error) << "\"}\n";
}

void run_online_qp(Providers& providers, const Query& query, std::size_t repetition, bool warmup) {
    const auto started=Clock::now();
    std::string status="online_qp_failed", error;
    bool optimal=false, matches_reference=false;
    int termination_code=-1, outcome_code=-1;
    double input_value=0, objective_at_primal=0;
    std::optional<double> second_input_value;
    std::optional<double> objective_lower, objective_upper;
    try {
        const auto resolved=resolve(query);
        const auto program=[&] {
          if (query.nonunique) {
            return optimization::make_convex_program({
                {resolved.identity(),{"mpc08-nonunique-online-qp:"+query.id}},
                QuadraticTerminal{Matrix{2,2,{2,2,2,2}},Vector{2*query.v,2*query.v},query.v*query.v},
                SparseMatrix{0,2,{0},{},{}},{{-1,1},{-1,1}},{},{}});
          }
            const double lower=std::max({-1.0,-1.0-query.p-2*query.v,(-1.0-query.p-3*query.v)/2});
            const double upper=std::min({1.0,1.0-query.p-2*query.v,(1.0-query.p-3*query.v)/2});
            if (lower>upper) throw std::runtime_error("query is outside the feasible initial domain");
            return optimization::make_convex_program({
                {resolved.identity(),{"mpc08-condensed-online-qp:"+query.id}},
                QuadraticTerminal{Matrix{1,1,{2.0}},Vector{2*query.v},
                    (query.p+query.v)*(query.p+query.v)+query.v*query.v},
                SparseMatrix{0,1,{0},{},{}},{{lower,upper}},{},{}});
        }();
        if (const auto* failure=std::get_if<Diagnostics>(&program)) {
            std::ostringstream message; for (const auto& item:*failure) message<<item.field<<": "<<item.explanation<<"; ";
            throw std::runtime_error(message.str());
        }
        if (!std::holds_alternative<ConvexProgram>(program))
            throw std::runtime_error("online QP construction stopped");
        Requirements requirements; requirements.output.representation={"csl.program-result.v1"};
        const Method method{providers.convex_id,{}};
        auto provider=take(prepare_provider(select_provider(*providers.convexes,method,requirements)),"online QP provider selection");
        auto pipeline=take(provider.prepare(std::get<ConvexProgram>(program)),"online QP preparation");
        auto [workspace]=pipeline.create();
        if (!workspace) throw std::runtime_error("online QP workspace is null");
        ExecutionContext context; context.numerical={1e-8,1e-8};
        context.resources=std::make_shared<const ResourcePolicy>(ResourcePolicy{1,1,1,{}});
        auto solved=workspace->run(context);
        if (const auto* unsupported=std::get_if<Unsupported>(&solved)) {
            std::ostringstream message; for (const auto& item:unsupported->diagnostics)
                message<<item.field<<": "<<item.explanation<<"; ";
            throw std::runtime_error(message.str());
        }
        const auto& result=std::get<ProgramResult>(solved);
        termination_code=static_cast<int>(result.termination);
        outcome_code=static_cast<int>(result.outcome.value);
        if (result.objective.lower) objective_lower=result.objective.lower->value;
        if (result.objective.upper) objective_upper=result.objective.upper->value;
        optimal=result.termination==Termination::completed&&result.outcome.value==MathematicalOutcome::optimal&&
            result.primal.has_value()&&result.primal->size()==(query.nonunique?2U:1U);
        if (result.primal&&result.primal->size()==(query.nonunique?2U:1U)) {
            input_value=result.primal->front();
            if (query.nonunique) {
                const double u1=result.primal->at(1);
                second_input_value=u1;
                const double terminal_v=query.v+input_value+u1;
                objective_at_primal=terminal_v*terminal_v;
                matches_reference=optimal&&std::abs(objective_at_primal-query.value)<=2e-6&&
                    input_value>=-1.0-2e-6&&input_value<=1.0+2e-6&&u1>=-1.0-2e-6&&u1<=1.0+2e-6;
            } else {
                objective_at_primal=(query.p+query.v)*(query.p+query.v)+
                    (query.v+input_value)*(query.v+input_value);
                const bool action_matches=std::abs(input_value-query.u)<=2e-6;
                const bool value_matches=std::abs(objective_at_primal-query.value)<=2e-6;
                matches_reference=optimal&&action_matches&&value_matches;
            }
        }
        status=matches_reference?"online_qp_matches_exact_reference":"online_qp_result_mismatch";
    } catch (const std::exception& exception) { error=exception.what(); }
    const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-started).count();
    std::cout<<"{\"schema\":\"csl.mpc08-explicit-candidate-observation/1\",\"fixture\":\""
        <<(query.nonunique?"nonunique_horizon_2":"unique_horizon_1")<<"\",\"horizon\":"
        <<(query.nonunique?2:1)<<",\"query_id\":\""
        <<query.id<<"\",\"strategy\":\"online-condensed-qp\",\"warmup\":"<<(warmup?"true":"false")
        <<",\"repetition\":"<<repetition<<",\"status\":\""<<status<<"\",\"termination_optimal\":"
        <<(optimal?"true":"false")<<",\"family_present\":false,\"termination_code\":"<<termination_code
        <<",\"outcome_code\":"<<outcome_code<<",\"candidate_contains_exact_reference_history\":"
        <<"false,\"action_and_value_match_exact_reference\":"<<(matches_reference?"true":"false")
        <<",\"input_value\":"<<std::setprecision(17)<<input_value
        <<",\"second_input_value\":";
    if(second_input_value)std::cout<<std::setprecision(17)<<*second_input_value;else std::cout<<"null";
    std::cout<<",\"objective_at_primal\":"<<std::setprecision(17)<<objective_at_primal
        <<",\"objective_lower\":";
    if (objective_lower) std::cout<<std::setprecision(17)<<*objective_lower; else std::cout<<"null";
    std::cout<<",\"objective_upper\":";
    if (objective_upper) std::cout<<std::setprecision(17)<<*objective_upper; else std::cout<<"null";
    std::cout
        <<",\"expected_value_exact\":\""<<query.value_exact<<"\",\"candidate_inequality_rows\":0"
        <<",\"candidate_equality_rows\":0,\"coordinate_labels\":\"\",\"elapsed_ns\":"<<elapsed
        <<",\"stop_details\":\"\",\"error\":\""<<json_escape(error)<<"\"}\n";
}

void run_support_csv(Providers& providers,const char* path) {
    std::ifstream input(path);std::string line;
    if(!input||!std::getline(input,line))throw std::runtime_error("support CSV missing");
    while(std::getline(input,line)) {
        std::istringstream stream(line);std::vector<std::string> fields;std::string field;
        while(std::getline(stream,field,','))fields.push_back(field);
        if(fields.size()<5||(fields.size()-3)%3)throw std::runtime_error("support CSV shape");
        for(std::size_t repetition=0;repetition<6;++repetition) {
            const auto begin=Clock::now();auto prepared_end=begin,solved_end=begin;
            bool optimal=false;std::string error;std::optional<Vector> primal;
            std::optional<std::size_t> threads;
            try {
                const std::size_t rows=(fields.size()-3)/3;SparseMatrix matrix{rows,2,{0},{},{}};std::vector<Interval> bounds;
                for(std::size_t i=0;i<rows;++i) {
                    for(std::size_t j=0;j<2;++j) {
                        const auto value=std::stod(fields[3+3*i+j]);
                        if(value!=0) {matrix.column_indices.push_back(j);matrix.values.push_back(value);}
                    }
                    matrix.row_offsets.push_back(matrix.values.size());bounds.push_back({{},std::stod(fields[5+3*i])});
                }
                auto program=take(optimization::make_linear_program({{{"mpc08-set-support"},{fields[0]}},
                    {std::stod(fields[1]),std::stod(fields[2])},0,std::move(matrix),std::vector<Interval>(2),std::move(bounds)}),"support LP");
                Requirements requirements;requirements.output.representation={"csl.program-result.v1"};
                auto provider=take(prepare_provider(select_provider(*providers.lps,{providers.lp_id,{}},requirements)),"support provider");
                auto pipeline=take(provider.prepare(program),"support prepare");auto [workspace]=pipeline.create();
                ExecutionContext context;context.numerical={1e-8,1e-8};context.resources=std::make_shared<const ResourcePolicy>(ResourcePolicy{1,1,1,{}});
                context.backend_thread_observation=std::make_shared<execution::BackendThreadObservation>();
                prepared_end=Clock::now();auto outcome=workspace->run(context);solved_end=Clock::now();
                threads=context.backend_thread_observation->maximum();
                if(const auto* result=std::get_if<ProgramResult>(&outcome)) {
                    optimal=result->termination==Termination::completed&&result->outcome.value==MathematicalOutcome::optimal&&result->primal&&result->primal->size()==2;
                    primal=result->primal;
                } else error="support LP unsupported";
            } catch(const std::exception& e) {error=e.what();solved_end=Clock::now();}
            std::cout<<"{\"schema\":\"csl.mpc08-support/1\",\"query_id\":\""<<json_escape(fields[0])
                <<"\",\"repetition\":"<<repetition<<",\"warmup\":"<<(repetition==0?"true":"false")
                <<",\"optimal\":"<<(optimal?"true":"false")<<",\"primal\":";
            if(primal)std::cout<<'['<<std::setprecision(17)<<(*primal)[0]<<','<<(*primal)[1]<<']';else std::cout<<"null";
            std::cout<<",\"prepare_ns\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(prepared_end-begin).count()
                <<",\"run_ns\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(solved_end-prepared_end).count()<<",\"observed_backend_threads\":";
            if(threads)std::cout<<*threads;else std::cout<<"null";
            std::cout<<",\"error\":\""<<json_escape(error)<<"\"}\n";
        }
    }
}

void run_horizon_family(Providers& providers, const char* path) {
    std::ifstream input(path);std::string line;
    if(!std::getline(input,line))throw std::runtime_error("empty horizon family CSV");
    while(std::getline(input,line)) {
        std::istringstream row(line);std::vector<std::string> fields;std::string field;
        while(std::getline(row,field,','))fields.push_back(field);
        if(fields.size()!=6)throw std::runtime_error("horizon family row needs id,N,p,v,zp,zv");
        const auto n=static_cast<std::size_t>(std::stoul(fields[1]));
        if(n!=2&&n!=4&&n!=8)throw std::runtime_error("unsupported family horizon");
        const double p=std::stod(fields[2]),v=std::stod(fields[3]),zp=std::stod(fields[4]),zv=std::stod(fields[5]);
        if(!std::isfinite(p)||!std::isfinite(v)||!std::isfinite(zp)||!std::isfinite(zv))throw std::runtime_error("nonfinite family input");
        for(const bool original:{true,false})for(std::size_t rep=0;rep<6;++rep) {
            const auto start=Clock::now();bool verified=false,complete=false;int termination=-1,outcome=-1;
            std::string error,stop;std::optional<sets::HRepresentation> relation;
            try {
                const LinearStage flow{Matrix{2,2,{1,1,0,1}},Matrix{2,1,{0,1}},Matrix{2,0,{}},Vector{0,0}};
                std::vector<double> times;std::vector<AdmissibleSet> controls;
                for(std::size_t t=0;t<=n;++t)times.push_back(static_cast<double>(t));
                for(std::size_t t=0;t<n;++t)controls.push_back(input_box());
                std::vector<AdmissibleSet> states(n+1,UniversalSet{2});
                states.back()=original?AdmissibleSet{terminal_set()}:AdmissibleSet{Singleton{Vector{zp,zv}}};
                TerminalObjective objective=LinearTerminal{Vector{0,0},0};
                if(original)objective=QuadraticTerminal{Matrix{2,2,{2,0,0,2}},Vector{0,0},0};
                Problem source{{"mpc08-horizon-family-"+fields[0]+(original?"-quadratic":"-endpoint-reduction")},
                    std::make_shared<const SystemModel>(SystemModel{{{2,1,0},TimeDomain::discrete,flow},{}}),times,
                    KnownInitial{{p,v}},ContinuousDomain{controls},states,{},{},InformationPattern::nominal_open_loop,objective};
                auto resolved=take(problem::resolve(source,{problem::UncertaintyStructure::stage_product_uncoupled,{},{}}),"family resolve");
                FamilyRequest family;family.profile=synthesis::strategy_b::nominal_linear_exact_profile;
                family.objective=resolved.identity();family.target=FamilyTarget::exact_optimal_relation;
                family.assurance=Assurance::numerical;family.representation={"csl.polyhedron.h"};
                StrategyConfiguration config;config.strategy=providers.strategy_b_id;config.lp=providers.lp_id;
                config.convex=providers.convex_id;config.representation=family.representation;
                StrategyRequest request{resolved,config,family,{},{}};Requirements output;
                output.output.representation=family.representation;output.output.family=family.target;output.output.completeness=Completeness::established;
                auto prepared=take(providers.strategies->prepare(request,output),"exact family prepare");auto workspace=prepared.create();
                ExecutionContext context;context.resources=std::make_shared<const ResourcePolicy>(ResourcePolicy{1,1,1,{}});
                const auto result=take(workspace->run(context),"exact family run");
                termination=static_cast<int>(result.termination);outcome=static_cast<int>(result.outcome.value);stop=stop_summary(result.stop);
                if(result.family) {
                    verified=result.family->registry_verified();
                    if(const auto* f=std::get_if<CompleteOptimalFamily>(&result.family->outcome())) {
                        complete=true;
                        if(f->relation.payload)if(const auto* data=f->relation.payload->h_relation_for_recording())
                            if(const auto representation=data->representation();const auto* h=std::get_if<sets::HRepresentation>(&representation))relation=*h;
                    }
                }
                // HRepresentation views must remain alive while serialized below.
                std::cout<<"{\"schema\":\"csl.mpc08-horizon-family/1\",\"query_id\":\""<<json_escape(fields[0])<<"\",\"horizon\":"<<n
                    <<",\"original_quadratic\":"<<(original?"true":"false")<<",\"repetition\":"<<rep<<",\"warmup\":"<<(rep==0?"true":"false")
                    <<",\"registry_verified\":"<<(verified?"true":"false")<<",\"complete\":"<<(complete?"true":"false")
                    <<",\"termination\":"<<termination<<",\"outcome\":"<<outcome<<",\"stop\":\""<<json_escape(stop)<<"\",\"elapsed_ns\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count();
                if(relation) {
                    const auto matrix=[](const auto& m){std::cout<<'[';for(std::size_t r=0;r<m.rows();++r){if(r)std::cout<<',';std::cout<<'[';for(std::size_t c=0;c<m.cols();++c){if(c)std::cout<<',';std::cout<<std::setprecision(17)<<m(r,c);}std::cout<<']';}std::cout<<']';};
                    const auto vector=[](const auto& v0){std::cout<<'[';for(std::size_t i=0;i<v0.size();++i){if(i)std::cout<<',';std::cout<<std::setprecision(17)<<v0[i];}std::cout<<']';};
                    std::cout<<",\"inequalities\":";matrix(relation->inequalities);std::cout<<",\"upper_bounds\":";vector(relation->upper_bounds);
                    std::cout<<",\"equalities\":";matrix(relation->equalities);std::cout<<",\"equality_values\":";vector(relation->equality_values);
                }
                std::cout<<",\"error\":\"\"}\n";
                continue;
            } catch(const std::exception& e){error=e.what();}
            std::cout<<"{\"schema\":\"csl.mpc08-horizon-family/1\",\"query_id\":\""<<json_escape(fields[0])<<"\",\"horizon\":"<<n
                <<",\"original_quadratic\":"<<(original?"true":"false")<<",\"repetition\":"<<rep<<",\"warmup\":"<<(rep==0?"true":"false")
                <<",\"registry_verified\":false,\"complete\":false,\"termination\":"<<termination<<",\"outcome\":"<<outcome
                <<",\"elapsed_ns\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count()<<",\"error\":\""<<json_escape(error)<<"\"}\n";
        }
    }
}
}

int main(int argc,char** argv) try {
    if(argc==3&&std::string_view(argv[1])=="--horizon-family") {auto providers=make_providers();run_horizon_family(providers,argv[2]);return 0;}
    if(argc==3&&std::string_view(argv[1])=="--support") {auto providers=make_providers();run_support_csv(providers,argv[2]);return 0;}
    if (argc!=2) { std::cerr << "Usage: csl_mpc08_explicit_compare <exact-queries.csv>\n"; return 2; }
    const auto queries=read_queries(argv[1]);
    auto providers=make_providers();
    constexpr std::size_t measured=5;
    for (const auto& query:queries) {
        for (int method=0; method<2; ++method) run_one(providers,query,method==0,0,true);
        run_online_qp(providers,query,0,true);
        for (std::size_t repetition=1; repetition<=measured; ++repetition) {
            if (repetition%3==1) {
                run_one(providers,query,true,repetition,false);
                run_one(providers,query,false,repetition,false);
                run_online_qp(providers,query,repetition,false);
            } else if (repetition%3==2) {
                run_online_qp(providers,query,repetition,false);
                run_one(providers,query,false,repetition,false);
                run_one(providers,query,true,repetition,false);
            } else {
                run_one(providers,query,false,repetition,false);
                run_online_qp(providers,query,repetition,false);
                run_one(providers,query,true,repetition,false);
            }
        }
    }
    return 0;
} catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
}
