from pathlib import Path
import importlib.util,json
r=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('offline_extension',r/'source-root/scripts/reports/stage_mpc06_offline_costs.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.verify_export(r/'source-root',json.loads((r/'source-files.json').read_bytes()))
_,_,checked,_=m.validate(r/'evidence'/m.SOURCE.name,repository=r/'source-root')
assert checked==json.loads((r/'verification.json').read_bytes())
print(json.dumps(checked))
