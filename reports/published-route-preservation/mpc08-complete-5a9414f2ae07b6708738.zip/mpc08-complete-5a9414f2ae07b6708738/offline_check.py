"""Saved-only offline checks; no native executable, optimizer or renderer."""
from pathlib import Path
import importlib.util,json
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('mpc08_offline',root/'source-root/scripts/reports/stage_mpc08_complete.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.verify_export(root/'source-root',json.loads((root/'source-files.json').read_bytes()))
_,_,checks=module.validate(root/'evidence/mpc08-exact-regions-79ec2978-20261110',root/'evidence/mpc08-horizon-regions-01762505-20261110',repository=root/'source-root')
print(json.dumps(checks))
