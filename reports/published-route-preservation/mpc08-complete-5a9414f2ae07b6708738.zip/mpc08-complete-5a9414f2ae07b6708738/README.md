# Bounded MPC08 source/raw publication

Two frozen captures remain byte-preserved under evidence/. Their capture source
commits are 79ec2978bb18a77abf5817b6f940aa3a89b0e488 and 017625057d253ae191405ca163bbda85729af3aa.
Current saved-only checks and helper fingerprints are separate in verification.json
and source-files.json. Open index.html for labelled 2D figures and minimal inputs.

After downloading/extracting ../mpc08-complete-5a9414f2ae07b6708738.zip into a fresh directory, enter this
route and run:

```sh
sha256sum -c OFFLINE_SHA256SUMS
python3 -B offline_check.py
```

This needs Python3.11+ and Git, with no solver, Matplotlib, native binary, network
or existing source checkout. Inside the offline ZIP only, source-root/.git contains fresh fixed
configuration and only authentic commit/tree/blob objects needed by the original
full-commit git-show checks. It contains no host config, credentials, hooks or
complete repository history. Missing objects/source mismatches refuse the check;
there is no weaker cached-check fallback. This object store is not a full checkout.

The native process paths/compiler/library receipts are historical evidence, not
portable commands or redistributed binaries. Actual original-quadratic request
refusals, reduced-linear complete families and resource stops remain separate.
All optional plotting/native reproduction sources are included; reproducing native
runs additionally requires the normal reviewed CSL/backend build. No timing ranking,
MPT execution, new public API/required dependency or library release is claimed.

Only the existing current-main CI/freshness workflow may deploy this staged route.
Local source/HTML validation alone does not establish live publication or #604 closure.
