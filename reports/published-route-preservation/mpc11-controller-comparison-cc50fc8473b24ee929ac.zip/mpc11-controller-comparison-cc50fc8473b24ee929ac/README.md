# Offline saved comparison checks

Enter this publication route after extracting the complete ZIP into a fresh
folder. Run `sha256sum -c SHA256SUMS`. Frozen pilot/figure manifests and receipts
remain byte-preserved. New checking provenance is publication-manifest.json.
The separately qualified current affine derivation checker and numerical rebuild
tolerances are documented in `benchmarks/reporting/mpc11/AFFINE-RECHECK.md`. Stored identity checks
remain exact.

Use the optional environment described in `benchmarks/reporting/mpc11/environment/README.md`;
its exact Linux CPython wheel lock and notices are included. No required library
dependency is added. Do not infer redistribution permission from version pins.

Extract each raw archive into a separate new directory, then check its manifest:

```sh
mkdir affine nonlinear nmpc
unzip raw/affine.zip -d affine
unzip raw/nonlinear.zip -d nonlinear
unzip raw/nmpc.zip -d nmpc
(cd affine && sha256sum -c SHA256SUMS)
(cd nonlinear && sha256sum -c SHA256SUMS)
(cd nmpc && sha256sum -c SHA256SUMS)
python benchmarks/reporting/mpc11/check_affine_saved.py --bundle affine/accepted
python benchmarks/reporting/mpc11/check_nonlinear_saved.py --bundle nonlinear/accepted
python benchmarks/reporting/mpc11/check_nmpc_saved.py --bundle nmpc/accepted
```

These commands check saved evidence and rebuild transcriptions without running
optimization or numerical integration. `benchmarks/reporting/mpc11/FIGURES.md` documents optional
rendering to a new directory. This publication is staged locally only; managed
main/CI freshness, review, shared route audit and deployed-link checks remain
required before calling it published. No comparative timing verdict is supported.
