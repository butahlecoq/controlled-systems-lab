import hashlib,importlib.metadata,json,os,subprocess,sys,time
from pathlib import Path
R=Path('/home/butahlecoq/.local/share/codex/tmp/learning-control-execution-20261111')
source=Path('/home/butahlecoq/.codex/worktrees/947-campaign-sdk-089075e9')
notes=Path('/home/butahlecoq/.local/state/controlled-systems-lab/working-documents/947-initial-baselines-089075e9-20261114')
notes.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected='089075e919cdea0a59d6535235d62b0c06ceb7a9'
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==expected
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
assert json.loads((Path('/home/butahlecoq/.local/state/controlled-systems-lab/working-documents/947-fresh-sdk-089075e9-20261114')/'installed-consumer-attempt02-receipt.json').read_text())['state']=='pass'
controller=R/'947-campaign-sdk-089075e9-build/csl_closed_loop_native_policy'
bridge=R/'947-replay-sdk-consumer-089075e9-build/csl_mpc11_nonlinear_replay'
assert sha(controller)=='579551de4156c9cd9d8f2ec06add67c725253ec6d160b3992c10a7e403f84dc9'
assert sha(bridge)=='b5d47c14c65f1d2f833eaec4d9713bcc4717b130bd688e943ade7442c363973f'
record={'schema':'local.campaign-attempt-freeze/1','claim':'initial functional backward-controller baseline attempts; no timing comparison, exhaustive universe or global optimality claim','source':expected,'controller_binary_sha256':sha(controller),'execution_binary_sha256':sha(bridge),'driver_sha256':sha(Path(__file__)),'scope':'three tasks; existing default exact-polytope backward profile only; remaining four-group universe stays open under947','limits':'common runner 300s worker wall/CPU, existing per-process 1GiB address-space limit; checker/replay separately limited, no aggregate descendant memory cap; one worker and serial tasks','versions':{name:importlib.metadata.version(name) for name in ['numpy','scipy','matplotlib','casadi']},'capability_manifest_sha256':sha(source/'docs/catalogue/closed-loop-native-capabilities-v1.json'),'task_files':{name:sha(source/f'docs/contracts/closed-loop/{name}.json') for name in ['syn-nl-lv-01','earth-orbit','syn-nl-fuel-01']},'attempts':[]}
(notes/'freeze.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy();env.update(CSL_NATIVE_POLICY_BRIDGE=str(controller),TMPDIR=str(R/'test-tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
for task in ['syn-nl-lv-01','earth-orbit','syn-nl-fuel-01']:
    cmd=[sys.executable,str(source/'benchmarks/reporting/closed_loop/run_closed_loop.py'),'--task',task,'--bridge',str(bridge),'--controller-id','native-exact-polytope-backward-graph/1','--output-root',str(notes/'attempts'),'--attempt-wall-seconds','300','--attempt-cpu-seconds','300']
    row={'task':task,'command':cmd,'started_unix':time.time()};record['attempts'].append(row)
    (notes/'driver-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    with (notes/f'{task}-driver.stdout').open('w') as out,(notes/f'{task}-driver.stderr').open('w') as err:
        result=subprocess.run(cmd,cwd=source,env=env,stdout=out,stderr=err)
    row.update(driver_exit_code=result.returncode,finished_unix=time.time())
    (notes/'driver-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(task,'driver_exit',result.returncode,flush=True)
assert sha(controller)==record['controller_binary_sha256'] and sha(bridge)==record['execution_binary_sha256']
record['state']='all_three_drivers_terminal_inspection_required'
(notes/'driver-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
