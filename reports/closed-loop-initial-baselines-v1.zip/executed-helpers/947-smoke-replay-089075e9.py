import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/home/butahlecoq/.codex/worktrees/947-native-compositions-20261114')
sys.path.insert(0,str(root/'benchmarks/reporting/closed_loop'))
from contracts import load_task,manifest_sha256
from task_models import make_held_step_request,validate_held_step_response,validate_source_binding
folder=Path('/home/butahlecoq/.local/state/controlled-systems-lab/working-documents/947-replay-smoke-089075e9-20261114')
folder.mkdir(exist_ok=False)
binary=Path('/home/butahlecoq/.local/share/codex/tmp/learning-control-execution-20261111/947-replay-sdk-consumer-089075e9-build/csl_mpc11_nonlinear_replay')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'scope':'functional one-hold smoke only; no performance or full-campaign claim','sdk_source':'089075e919cdea0a59d6535235d62b0c06ceb7a9','orchestration_source':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'binary_sha256':sha(binary),'helper_sha256':sha(Path(__file__)),'cases':[]}
for name in ['syn-nl-lv-01','earth-orbit','syn-nl-fuel-01']:
    task=load_task(name);validate_source_binding(task)
    state=[x['initial'] for x in task['model']['states']]
    control=[sum(x['bounds'])/2 for x in task['model']['controls']]
    held=make_held_step_request(task,state,control,0,'functional-smoke-no-optimality-claim')
    request=folder/f'{name}-request.json';request.write_text(json.dumps(held['bridge_request'],indent=2)+'\n')
    (folder/f'{name}-held-request.json').write_text(json.dumps(held,indent=2)+'\n')
    proc=subprocess.run([str(binary),str(request)],capture_output=True,timeout=30)
    (folder/f'{name}-stdout.json').write_bytes(proc.stdout)
    (folder/f'{name}-stderr.txt').write_bytes(proc.stderr)
    row={'task':name,'task_sha256':manifest_sha256(task),'exit_code':proc.returncode,'request_sha256':sha(request)}
    record['cases'].append(row)
    (folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    assert proc.returncode==0,(name,proc.stderr)
    output=json.loads(proc.stdout);validated=validate_held_step_response(held,output)
    (folder/f'{name}-validated.json').write_text(json.dumps(validated,indent=2)+'\n')
    row.update(status=validated['status'],samples=len(validated['physical_states']),final_physical_state=validated['physical_states'][-1],validation='original task identity, observed initial state, held-input/time association, finite complete physical states, empty execution diagnostics')
    (folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(name,row['status'],row['samples'],flush=True)
record['state']='pass'
(folder/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
