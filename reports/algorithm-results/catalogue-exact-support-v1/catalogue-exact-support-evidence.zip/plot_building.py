"""Render exact support witnesses and the sub-visual effect of the building budget."""

import json
from fractions import Fraction
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from verify_certificates import matvec, prepare

ROOT = Path(__file__).resolve().parent
COLORS = ("#227C83", "#7154A2", "#BA4024")
DIRECTIONS = {
    (1, 0): "→",
    (1, 1): "↗",
    (0, 1): "↑",
    (-1, 1): "↖",
    (-1, 0): "←",
    (-1, -1): "↙",
    (0, -1): "↓",
    (1, -1): "↘",
}


def point_at(data, prepared, record):
    A, B, x, drift, *_ = prepared
    for k, control in enumerate(record["controls"][: record["stage"]]):
        u = list(map(Fraction, control))
        x = [
            a + b + c
            for a, b, c in zip(matvec(A, x), matvec(B, u), drift[k], strict=True)
        ]
    return tuple(x[j] for j in data["plane"])


def outline(points):
    def turn(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])

    if len(points) <= 2:
        return points
    chains = []
    for ordered in (points, reversed(points)):
        chain = []
        for point in ordered:
            while len(chain) >= 2 and turn(chain[-2], chain[-1], point) <= 0:
                chain.pop()
            chain.append(point)
        chains.extend(chain[:-1])
    return chains + [chains[0]] if len(chains) > 2 else chains


def main():
    data = json.loads((ROOT / "input/raw/28.json").read_bytes())
    report = json.loads((ROOT / "results/28.json").read_bytes())
    model = prepare(data)
    matplotlib.rcParams["svg.hashsalt"] = "csl-exact-building-budget-model28"
    fig, (geom, gap) = plt.subplots(
        1,
        2,
        figsize=(11.4, 4.85),
        gridspec_kw={"width_ratios": [1.1, 1]},
        layout="constrained",
    )
    for stage, color in enumerate(COLORS, 1):
        for profile, line, offset in (
            ("intervals_only", "--", 4),
            ("full_history", "-", 2),
        ):
            samples = [item for item in report[profile] if item["stage"] == stage]
            points = sorted({point_at(data, model, sample) for sample in samples})
            x, y = zip(*(tuple(map(float, xy)) for xy in outline(points)), strict=True)
            geom.plot(x, y, line, color=color, linewidth=1.6, zorder=offset)
        strict = []
        for loose, full in zip(
            report["intervals_only"], report["full_history"], strict=True
        ):
            if full["stage"] != stage:
                continue
            reduction = Fraction(loose["relaxed_support"]) - Fraction(
                full["relaxed_support"]
            )
            if reduction > 0:
                strict.append(
                    (list(DIRECTIONS).index(tuple(full["direction"])), float(reduction))
                )
        xs, ys = zip(*strict, strict=True)
        gap.scatter(xs, ys, color=color, s=42, label=f"Stage {stage}")

    x0, y0 = (data["initial"][j] for j in data["plane"])
    geom.scatter([x0], [y0], s=33, color="#222735", zorder=5)
    geom.set(
        title="Sampled state projections",
        xlabel=r"Building state $x_1$",
        ylabel=r"Building state $x_2$",
    )
    geom.legend(
        handles=[
            Line2D([], [], color="#222735", linestyle="-", label="Full constraints"),
            Line2D(
                [], [], color="#222735", linestyle="--", label="Control intervals alone"
            ),
            Line2D(
                [], [], color="#222735", marker="o", linestyle="", label="Initial state"
            ),
        ],
        fontsize=8,
    )
    gap.set(
        title="Positive support deficits",
        xlabel="Sampled support direction",
        ylabel=r"$h_{\mathrm{intervals}}(d)-h_{\mathrm{full}}(d)$",
        yscale="log",
    )
    gap.set_xticks(range(len(DIRECTIONS)), DIRECTIONS.values())
    gap.legend(loc="lower right", fontsize=8)
    for axis in (geom, gap):
        axis.grid(alpha=0.22)
    fig.suptitle(
        "Twenty-zone building · exact effect of the control budget", fontweight="bold"
    )
    fig.savefig(ROOT / "building-budget-projection.svg", metadata={"Date": None})
    fig.savefig(ROOT / "building-budget-projection.png", dpi=155)


if __name__ == "__main__":
    main()
