"""Check exact primal and dual certificates over the saved binary64 inputs."""

import copy
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

MODELS = (23, 27, 28)
PROFILES = ("intervals_only", "full_history")


def matrix(data):
    values = list(map(Fraction, data["values"]))
    rows, cols = data["rows"], data["cols"]
    assert len(values) == rows * cols
    return [values[i * cols : (i + 1) * cols] for i in range(rows)]


def dot(left, right):
    return sum(a * b for a, b in zip(left, right, strict=True))


def matvec(matrix, vector):
    return [dot(row, vector) for row in matrix]


def coordinate_map(A, B, terminal_stage, plane, direction):
    # Propagate each action column forward to the requested state plane.
    # The native certificate producer instead pulls a direction backward.
    directions = [[Fraction(0) for _ in B[0]] for _ in range(3)]
    impulses = list(zip(*B, strict=True))
    for k in range(terminal_stage - 1, -1, -1):
        directions[k] = [dot([v[i] for i in plane], direction) for v in impulses]
        impulses = [matvec(A, column) for column in impulses]
    return directions


def prepare(data):
    A, B, G = (matrix(data[key]) for key in ("A", "B", "G"))
    offset = list(map(Fraction, data["offset"]))
    initial = list(map(Fraction, data["initial"]))
    external = [list(map(Fraction, item)) for item in data["external"]]
    drift = [
        [x + y for x, y in zip(offset, matvec(G, stage), strict=True)]
        for stage in external
    ]
    bounds = data["constraints"]
    assert bounds["terminal"] == []
    assert all(not budget for budget in bounds["positive_part"])
    actions = [
        [tuple(map(Fraction, pair)) for pair in stage] for stage in bounds["control"]
    ]
    budgets = []
    for stage in bounds["stage"]:
        Hx, Hu, Hw = (matrix(stage[key]) for key in ("state", "control", "external"))
        assert not any(entry for row in Hx + Hw for entry in row)
        if not Hu:
            assert not stage["bounds"]
            budgets.append(None)
            continue
        [weights] = Hu
        [(lower, upper)] = stage["bounds"]
        assert lower is None and upper is not None and all(w >= 0 for w in weights)
        budgets.append((weights, Fraction(upper)))
    if not budgets:
        budgets = [None] * len(actions)
    assert len(actions) == len(budgets) == len(drift) == 3
    return A, B, initial, drift, actions, budgets, bounds["state"]


def verify_one(input_sample, candidate, profile, plane, model):
    A, B, initial, drift, bounds, budgets, state_bounds = model
    assert input_sample["status"] == candidate["prior_native_status"] == "unsupported"
    k = input_sample["stage"]
    assert k == candidate["stage"] and 0 <= k <= 3
    assert input_sample["direction"] == candidate["direction"]
    direction = list(map(Fraction, input_sample["direction"]))
    coefficients = coordinate_map(A, B, k, plane, direction)
    fixed = initial
    for stage in range(k):
        fixed = [a + b for a, b in zip(matvec(A, fixed), drift[stage], strict=True)]
    upper_bound = dot([fixed[i] for i in plane], direction)
    objective = Fraction(candidate["relaxed_support"])
    states = [initial]
    active_budgets = 0
    claimed = candidate["budget_multipliers"]
    for stage, (limits, controls, coeff, multiplier) in enumerate(
        zip(bounds, candidate["controls"], coefficients, claimed, strict=True)
    ):
        u = list(map(Fraction, controls))
        lam = Fraction(multiplier)
        assert all(
            low <= value <= high for value, (low, high) in zip(u, limits, strict=True)
        )
        budget = budgets[stage] if profile == "full_history" else None
        if budget is None:
            assert lam == 0
        else:
            weights, cap = budget
            assert lam >= 0
            slack = cap - dot(weights, u)
            assert slack >= 0 and lam * slack == 0
            active_budgets += lam > 0
            upper_bound += lam * cap
            coeff = [c - lam * w for c, w in zip(coeff, weights, strict=True)]
        upper_bound += sum(
            max(c * low, c * high) for c, (low, high) in zip(coeff, limits, strict=True)
        )
        states.append(
            [
                a + b + off
                for a, b, off in zip(
                    matvec(A, states[-1]), matvec(B, u), drift[stage], strict=True
                )
            ]
        )
    assert dot([states[k][i] for i in plane], direction) == objective == upper_bound
    violations = []
    if profile == "full_history":
        for stage, (state, limits) in enumerate(zip(states, state_bounds, strict=True)):
            for coord, (value, (lower, upper)) in enumerate(
                zip(state, limits, strict=True)
            ):
                if lower is not None and value < Fraction(lower):
                    violations.append(
                        {"stage": stage, "coordinate": coord, "side": "lower"}
                    )
                if upper is not None and value > Fraction(upper):
                    violations.append(
                        {"stage": stage, "coordinate": coord, "side": "upper"}
                    )
    assert candidate["state_violations"] == violations
    assert candidate["status"] == ("inconclusive" if violations else "exact-optimal")
    return objective, active_budgets


def main():
    root = Path(__file__).resolve().parent
    previous = json.loads((root / "input/independent-audit.json").read_bytes())
    result = {}
    seeded = False
    seeded_budget = False
    for id in MODELS:
        data = json.loads((root / f"input/raw/{id}.json").read_bytes())
        certificate = json.loads((root / f"results/{id}.json").read_bytes())
        assert certificate["model_id"] == data["model_id"]
        model = prepare(data)
        summary = {}
        supports_by_profile = {}
        for profile in PROFILES:
            outcomes = Counter()
            scaled_gaps = []
            exact_budget_uses = 0
            supports = []
            for index, (source, candidate, numeric) in enumerate(
                zip(
                    data[profile]["samples"],
                    certificate[profile],
                    previous[str(id)][profile]["samples"],
                    strict=True,
                )
            ):
                objective, active = verify_one(
                    source, candidate, profile, data["plane"], model
                )
                supports.append(objective)
                status = candidate["status"]
                outcomes[status] += 1
                if status == "exact-optimal":
                    exact_budget_uses += active
                    x = numeric["reference_support"]
                    scaled_gaps.append(abs(float(objective) - x) / max(1, abs(x)))
                if not seeded and index == 1:
                    bad = copy.deepcopy(candidate)
                    bad["relaxed_support"] = str(objective + 1)
                    try:
                        verify_one(source, bad, profile, data["plane"], model)
                    except AssertionError:
                        seeded = True
                    else:
                        raise AssertionError("checker accepted a tampered support")
                if not seeded_budget and active:
                    bad = copy.deepcopy(candidate)
                    bad["budget_multipliers"] = ["0"] * 3
                    try:
                        verify_one(source, bad, profile, data["plane"], model)
                    except AssertionError:
                        seeded_budget = True
                    else:
                        raise AssertionError(
                            "checker accepted a missing budget multiplier"
                        )
            assert sum(outcomes.values()) == 32
            supports_by_profile[profile] = supports
            summary[profile] = {
                "statuses": dict(outcomes),
                "nonzero_stage_budget_multipliers": exact_budget_uses,
                "max_scaled_gap_to_previous_condensed_reference": max(
                    scaled_gaps, default=None
                ),
            }
        gaps = [
            loose - full
            for loose, full in zip(
                *(supports_by_profile[p] for p in PROFILES), strict=True
            )
        ]
        assert min(gaps) >= 0
        summary["budget_effect"] = {
            "strict_support_reductions": sum(gap > 0 for gap in gaps),
            "max_support_reduction": str(max(gaps)),
            "max_support_reduction_decimal": float(max(gaps)),
        }
        result[str(id)] = summary
    assert seeded and seeded_budget
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
