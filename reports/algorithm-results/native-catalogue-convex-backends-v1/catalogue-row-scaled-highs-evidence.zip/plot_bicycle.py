import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("episode", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    capture = json.loads(args.episode.read_bytes())
    assert capture["model_id"] == "catalogue-2026/model-23/1"
    matplotlib.rcParams.update({"svg.hashsalt": "csl-catalogue-row-scale", "svg.fonttype": "none"})
    fig, (plane, action) = plt.subplots(1, 2, figsize=(8.5, 4.1))
    for name, label, color, marker, style in (
        ("open_loop", "Held sequence", "#08695e", "o", "-"),
        ("closed_loop", "Observed-state MPC", "#54337e", "D", "--"),
    ):
        saved = capture[name]
        assert saved["status"] == "complete"
        path = saved["states"]
        plane.plot([1e6 * x[0] for x in path], [1e6 * x[3] for x in path],
                   color=color, linestyle=style, marker=marker, markerfacecolor="white",
                   label=label, markersize=6, linewidth=1.7)
        values = [1e3 * u[1] for u in saved["controls"]]
        action.step(range(len(values) + 1), [*values, values[-1]], where="post",
                    color=color, linestyle=style, linewidth=1.7)
        action.scatter(range(len(values)), values, facecolor="white", edgecolor=color,
                       marker=marker, zorder=4)
    for k, point in enumerate(capture["closed_loop"]["states"]):
        plane.annotate(f"$k={k}$", (1e6 * point[0], 1e6 * point[3]),
                       xytext=(-4, 8) if k == 3 else (4, 8),
                       ha="right" if k == 3 else "left",
                       textcoords="offset points", fontsize=9)
    plane.margins(x=0.14, y=0.16)
    plane.set(xlabel=r"$10^6x_1$", ylabel=r"$10^6x_4$")
    action.set(xlabel="Stage", ylabel=r"$10^3u_2$", xticks=range(4))
    action.axhline(0, color="#9ca7b3", linewidth=0.8)
    for axes in (plane, action):
        axes.grid(color="#dde2e8", linewidth=0.65)
    fig.suptitle("Bicycle car with actuators", fontsize=15, weight="bold")
    handles, labels = plane.get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False)
    fig.subplots_adjust(left=0.095, right=0.98, bottom=0.23, top=0.87, wspace=0.37)
    fig.savefig(args.output.with_suffix(".svg"), metadata={"Date": None})
    fig.savefig(args.output.with_suffix(".png"), dpi=210)


if __name__ == "__main__":
    main()

