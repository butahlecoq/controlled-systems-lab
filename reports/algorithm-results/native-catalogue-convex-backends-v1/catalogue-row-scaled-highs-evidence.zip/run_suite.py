import argparse
from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("executable", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    exe = args.executable.resolve()
    dest = args.destination
    dest.mkdir(exist_ok=True)
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")

    def run(number):
        stem = dest / str(number)
        with stem.with_suffix(".json").open("wb") as out:
            with stem.with_suffix(".stderr").open("wb") as err:
                result = subprocess.run(["timeout", "45s", str(exe), str(number)],
                                        stdout=out, stderr=err, env=env, check=False)
        stem.with_suffix(".exit").write_text(f"{result.returncode}\n")
        return number, result.returncode

    with ThreadPoolExecutor(max_workers=3) as pool:
        for number, code in pool.map(run, range(1, 36)):
            print(number, code)
            if code != 0:
                raise SystemExit(1)


if __name__ == "__main__":
    main()

