from collections import Counter
from pathlib import Path
from sys import argv
import json

old_root, new_root = map(Path, argv[1:])
variants = ("open_loop", "closed_loop")
keys = ("status", "controls", "states", "realized_cost")
updates, matches = [], 0
counts = {mode: Counter() for mode in variants}

for i in range(1, 36):
    old, new = (json.loads((p / f"{i}.json").read_bytes()) for p in (old_root, new_root))
    assert new["backend"] == "csl.convex.highs.row-scaled"
    source_fields = set(old) - {"backend", *variants}
    assert source_fields == set(new) - {"backend", *variants}
    assert all(old[field] == new[field] for field in source_fields), i
    for mode in variants:
        a, b = old[mode], new[mode]
        counts[mode][b["status"]] += 1
        if all(a[key] == b[key] for key in keys):
            matches += 1
        else:
            updates.append([i, mode, a["status"], b["status"]])
        if i in (27, 28):
            assert b["decisions"][0]["solve_diagnostics"][0]["field"] == "highs.convex.matrix"
            assert "row exceeds exact scaling limits" in b["decisions"][0]["solve_diagnostics"][0]["explanation"]

assert matches == 68, updates
assert updates == [
    [23, "open_loop", "solver-unsupported", "complete"],
    [23, "closed_loop", "solver-unsupported", "complete"],
]
print(json.dumps({"unchanged_physical_outcomes": matches, "recovered": updates,
                  "policy_outcomes": counts}, indent=2))

