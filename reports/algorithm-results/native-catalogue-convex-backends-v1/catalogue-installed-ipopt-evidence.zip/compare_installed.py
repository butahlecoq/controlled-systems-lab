import argparse
import json
from pathlib import Path

POLICIES = ("open_loop", "closed_loop")
OBSERVABLES = ("status", "states", "controls", "realized_cost")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source_reference", type=Path)
    parser.add_argument("direct_probe", type=Path)
    parser.add_argument("installed", type=Path)
    args = parser.parse_args()
    prior_cost_gaps = []
    recovered = []
    for i in range(1, 36):
        name = f"{i}.json"
        source, probe, installed = (
            json.loads((root / name).read_bytes())
            for root in (args.source_reference, args.direct_probe, args.installed)
        )
        fields = set(source) - {"backend", "backend_version", *POLICIES}
        assert all(source[key] == probe[key] == installed[key] for key in fields), i
        assert installed["backend"] == "csl.convex.ipopt"
        assert installed["backend_version"] == "1.0.0+ipopt.3.14.19"
        for mode in POLICIES:
            prior, experiment, actual = (packet[mode] for packet in (source, probe, installed))
            assert all(experiment[key] == actual[key] for key in OBSERVABLES), (i, mode)
            if prior["status"] != actual["status"]:
                recovered.append([i, mode])
            if prior["status"] == "complete":
                prior_cost_gaps.append(abs(prior["realized_cost"] - actual["realized_cost"]))
    assert len(prior_cost_gaps) == 61 and len(recovered) == 7
    output = {"matched_scratch_policy_records": 70, "recovered": recovered,
              "largest_cost_gap_to_released_highs": max(prior_cost_gaps)}
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

