import argparse
from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("driver", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    out = args.output
    out.mkdir()
    executable = str(args.driver.resolve())
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")

    def run(model):
        base = out / str(model)
        with base.with_suffix(".json").open("wb") as stdout, base.with_suffix(".kkt").open("wb") as stderr:
            result = subprocess.run(["timeout", "40s", executable, str(model)],
                                    env=env, stdout=stdout, stderr=stderr, check=False)
        base.with_suffix(".exit").write_text(f"{result.returncode}\n")
        if result.returncode:
            base.with_suffix(".stderr").write_bytes(base.with_suffix(".kkt").read_bytes())
        return model, result.returncode

    with ThreadPoolExecutor(max_workers=3) as pool:
        for case, code in pool.map(run, range(1, 36)):
            print(case, code)
            if code != 0:
                raise SystemExit(1)


if __name__ == "__main__":
    main()

