cmake_minimum_required(VERSION 3.31)
project(CSLIpoptInstalledProbe LANGUAGES CXX)
find_package(CSL 0.1.1 EXACT CONFIG REQUIRED)
enable_testing()
add_executable(ipopt_client ipopt_convex_client.cpp)
target_link_libraries(ipopt_client PRIVATE CSL::ipopt_convex)
add_executable(catalogue installed_catalogue_ipopt.cpp)
target_include_directories(catalogue SYSTEM PRIVATE "${JSON_INCLUDE}")
target_link_libraries(catalogue PRIVATE CSL::ipopt_convex CSL::model_catalogue CSL::controllers)
add_test(NAME ipopt_client COMMAND ipopt_client)
set_tests_properties(ipopt_client PROPERTIES ENVIRONMENT
  "OPENBLAS_NUM_THREADS=1;OMP_NUM_THREADS=1;MKL_NUM_THREADS=1")

