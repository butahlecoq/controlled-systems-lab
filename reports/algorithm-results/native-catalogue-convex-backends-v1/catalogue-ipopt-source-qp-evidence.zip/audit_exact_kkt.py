"""Independent exact-on-binary64 check of source QP witnesses from the C++ probe."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path

TOLERANCE = Q("1e-8")


def bound_violation(value, interval):
    low, high = (None if x is None else Q(x) for x in interval)
    return max(Q(0), low - value if low is not None else 0,
               value - high if high is not None else 0)


def evaluate(witness):
    x = tuple(map(Q, witness["primal"]))
    lg = tuple(map(Q, witness["lambda"]))
    zl = tuple(map(Q, witness["z_lower"]))
    zu = tuple(map(Q, witness["z_upper"]))
    linear = tuple(map(Q, witness["linear"]))
    assert len(x) == len(zl) == len(zu) == len(linear) == witness["variables"]
    assert len(lg) == len(witness["row_bounds"]) == witness["constraints"]
    ax = [Q(0)] * len(lg)
    hessian = list(zip(witness["H_rows"], witness["H_columns"],
                       map(Q, witness["H_values"]), strict=True))
    matrix = list(zip(witness["A_rows"], witness["A_columns"],
                      map(Q, witness["A_values"]), strict=True))
    gradient = list(linear)
    objective = Q(witness["offset"]) + sum(c * v for c, v in zip(linear, x, strict=True))
    for i, j, h in hessian:
        assert i >= j
        gradient[i] += h * x[j]
        if i != j:
            gradient[j] += h * x[i]
        objective += h * x[i] * x[j] / (2 if i == j else 1)
    stationarity = [g - lo + hi for g, lo, hi in zip(gradient, zl, zu, strict=True)]
    scales = [abs(g) + abs(lo) + abs(hi) for g, lo, hi in zip(gradient, zl, zu, strict=True)]
    for i, j, a in matrix:
        ax[i] += a * x[j]
        stationarity[j] += a * lg[i]
        scales[j] += abs(a * lg[i])

    feasibility = Q(0)
    feasibility_scaled = Q(0)
    complementarity = Q(0)
    complementarity_scale = Q(1)
    signs = Q(0)
    for values, bounds, lower, upper in (
        (ax, witness["row_bounds"], [max(0, -a) for a in lg], [max(0, a) for a in lg]),
        (x, witness["variable_bounds"], zl, zu),
    ):
        for value, bound, lo, hi in zip(values, bounds, lower, upper, strict=True):
            excess = bound_violation(value, bound)
            scale = max(Q(1), abs(value), *(abs(Q(b)) for b in bound if b is not None))
            feasibility = max(feasibility, excess)
            feasibility_scaled = max(feasibility_scaled, excess / scale)
            for endpoint, multiplier in zip(bound, (lo, hi), strict=True):
                signs = max(signs, -multiplier)
                if endpoint is None:
                    assert multiplier == 0
                    continue
                complementarity = max(complementarity, abs((value - Q(endpoint)) * multiplier))
                complementarity_scale = max(complementarity_scale,
                                           abs(multiplier) * max(1, abs(value), abs(Q(endpoint))))
    stationary = max(map(abs, stationarity), default=Q(0))
    value_difference = abs(objective - Q(witness["native_objective"]))
    assert feasibility_scaled <= 2 * TOLERANCE
    assert stationary <= TOLERANCE * (1 + max(1, *scales))
    assert complementarity <= TOLERANCE * (1 + complementarity_scale)
    assert signs == 0
    assert value_difference <= TOLERANCE * (1 + max(1, abs(objective)))
    return {
        "primal": float(feasibility),
        "stationarity": float(stationary),
        "complementarity": float(complementarity),
        "objective_error": float(value_difference),
        "tiny_matrix_entries": sum(0 < abs(a) <= Q(1e-12) for _, _, a in matrix),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("capture", type=Path)
    parser.add_argument("models", type=int, nargs="+")
    args = parser.parse_args()
    output = {}
    for model in args.models:
        records = [json.loads(line) for line in (args.capture / f"{model}.kkt").read_text().splitlines()]
        checks = [evaluate(record) for record in records if record["accepted"]]
        entry = {"attempts": len(records), "accepted": len(checks),
                 "statuses": [record["status"] for record in records]}
        if checks:
            entry["worst"] = {key: max(result[key] for result in checks) for key in checks[0]}
        output[model] = entry
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

