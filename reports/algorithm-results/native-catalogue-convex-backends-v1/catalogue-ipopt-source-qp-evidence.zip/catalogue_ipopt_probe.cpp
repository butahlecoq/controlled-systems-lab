#include <csl/adapters/convex/highs.hpp>
#include <csl/controllers/discrete_mpc.hpp>
#include <csl/registry/registry.hpp>

#include <nlohmann/json.hpp>
#include <coin-or/IpStdCInterface.h>

#include <algorithm>
#include <cmath>
#include <chrono>
#include <iostream>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <variant>

namespace {
using namespace csl;
using namespace csl::controllers;
using namespace csl::optimization;
using Json = nlohmann::json;
constexpr std::size_t horizon = 3;

Json diagnostics(const Diagnostics &values) {
  auto result = Json::array();
  for (const auto &value : values)
    result.push_back(
        {{"field", value.field}, {"explanation", value.explanation}});
  return result;
}

Json optional_scalar(const std::optional<double> &value) {
  return value ? Json(*value) : Json(nullptr);
}

Json matrix(const Matrix &value) {
  return {{"rows", value.rows}, {"cols", value.cols}, {"values", value.values}};
}

Json intervals(const std::vector<Interval> &values) {
  auto result = Json::array();
  for (const auto &value : values)
    result.push_back(Json::array(
        {optional_scalar(value.lower), optional_scalar(value.upper)}));
  return result;
}

Json constraints(const NominalMpcTask &task) {
  auto result = Json{{"state", Json::array()},
                     {"control", Json::array()},
                     {"stage", Json::array()},
                     {"positive_part", Json::array()},
                     {"terminal", Json::array()}};
  for (const auto &bounds : task.state_bounds)
    result["state"].push_back(intervals(bounds));
  for (const auto &bounds : task.control_bounds)
    result["control"].push_back(intervals(bounds));
  for (const auto &rows : task.stage_constraints)
    result["stage"].push_back({{"state", matrix(rows.state_map)},
                               {"control", matrix(rows.control_map)},
                               {"external", matrix(rows.external_map)},
                               {"bounds", intervals(rows.bounds)}});
  for (const auto &budgets : task.control_positive_part_budgets) {
    auto entries = Json::array();
    for (const auto &budget : budgets)
      entries.push_back(
          {{"indices", budget.control_indices}, {"upper", budget.upper_bound}});
    result["positive_part"].push_back(std::move(entries));
  }
  for (const auto &row : task.terminal_state_constraints)
    result["terminal"].push_back(
        {{"state", matrix(row.state_map)}, {"bounds", intervals(row.bounds)}});
  return result;
}


struct IpoptData {
  numeric::CsrInput rows;
  numeric::MatrixView hessian;
  numeric::VectorView linear;
  double offset;
  const ExecutionContext& context;
  std::vector<ipindex> jacobian_rows, jacobian_columns, hessian_rows, hessian_columns;
  Vector hessian_values;
};

bool gradient(ipindex n, double* x, bool, double* out, void* opaque) {
  const auto& problem=*static_cast<IpoptData*>(opaque);
  for(ipindex i=0;i<n;++i) {
    out[i]=problem.linear[i];
    for(ipindex j=0;j<n;++j)
      out[i]+=problem.hessian(i,j)*x[j];
  }
  return true;
}

bool objective(ipindex n, double* x, bool, double* out, void* opaque) {
  const auto& problem=*static_cast<IpoptData*>(opaque);
  *out=problem.offset;
  for(ipindex i=0;i<n;++i) {
    double row=0;
    for(ipindex j=0;j<n;++j)
      row+=problem.hessian(i,j)*x[j];
    *out+=0.5*x[i]*row+problem.linear[i]*x[i];
  }
  return std::isfinite(*out);
}

bool constraints(ipindex, double* x, bool, ipindex m, double* out, void* opaque) {
  const auto& a=static_cast<IpoptData*>(opaque)->rows;
  for(ipindex i=0;i<m;++i) {
    out[i]=0;
    for(auto j=a.row_offsets[i];j<a.row_offsets[i+1];++j)
      out[i]+=a.values[j]*x[a.column_indices[j]];
  }
  return true;
}

bool jacobian(ipindex, double*, bool, ipindex, ipindex, ipindex* i, ipindex* j,
              double* values, void* opaque) {
  const auto& a=*static_cast<IpoptData*>(opaque);
  if(values)
    std::copy(a.rows.values.begin(),a.rows.values.end(),values);
  else {
    std::copy(a.jacobian_rows.begin(),a.jacobian_rows.end(),i);
    std::copy(a.jacobian_columns.begin(),a.jacobian_columns.end(),j);
  }
  return true;
}

bool hessian(ipindex, double*, bool, double factor, ipindex, double*, bool, ipindex,
             ipindex* i, ipindex* j, double* values, void* opaque) {
  const auto& a=*static_cast<IpoptData*>(opaque);
  if(values)
    std::transform(a.hessian_values.begin(),a.hessian_values.end(),values,
                   [factor](auto x){return factor*x;});
  else {
    std::copy(a.hessian_rows.begin(),a.hessian_rows.end(),i);
    std::copy(a.hessian_columns.begin(),a.hessian_columns.end(),j);
  }
  return true;
}

bool iterate(ipindex, ipindex, double, double, double, double, double, double,
             double, double, ipindex, void* opaque) {
  const auto& c=static_cast<IpoptData*>(opaque)->context;
  return !c.cancellation.stop_requested() &&
         (!c.deadline || std::chrono::steady_clock::now()<*c.deadline);
}

class IpoptProbeWorkspace final : public ConvexWorkspace {
  ProgramOutcome do_solve(const ConvexProgram& p, const ExecutionContext& c) override {
    const auto authored=p.original_objective().coefficients();
    const auto* q=std::get_if<QuadraticCoefficients>(&authored);
    const auto& qp=p.quadratic_program();
    if(!q) return Unsupported{{{DiagnosticCode::unsupported,"trial.objective","A quadratic is required."}}};
    auto descriptor=qp.constraints().descriptor();
    IpoptData data{std::get<numeric::CsrInput>(descriptor),q->Q,q->linear,q->offset,c,
                   {},{},{},{},{}};
    const auto n=static_cast<ipindex>(data.rows.cols), m=static_cast<ipindex>(data.rows.rows);
    for(ipindex i=0;i<m;++i)
      for(auto j=data.rows.row_offsets[i];j<data.rows.row_offsets[i+1];++j) {
        data.jacobian_rows.push_back(i);
        data.jacobian_columns.push_back(static_cast<ipindex>(data.rows.column_indices[j]));
      }
    for(ipindex i=0;i<n;++i)
      for(ipindex j=0;j<=i;++j) {
        if(q->Q(i,j)!=q->Q(j,i))
          return Unsupported{{{DiagnosticCode::unsupported,"trial.hessian","An exactly symmetric Hessian is required."}}};
        if(q->Q(i,j)!=0) {
          data.hessian_rows.push_back(i);
          data.hessian_columns.push_back(j);
          data.hessian_values.push_back(q->Q(i,j));
        }
      }
    const auto bounds=[](std::span<const Interval> source) {
      std::pair<Vector,Vector> out;
      for(const auto& row:source) {
        if((row.lower && std::abs(*row.lower)>=1e19) || (row.upper && std::abs(*row.upper)>=1e19))
          throw std::runtime_error("A finite bound collides with an Ipopt infinity convention.");
        out.first.push_back(row.lower.value_or(-1e19));
        out.second.push_back(row.upper.value_or(1e19));
      }
      return out;
    };
    auto [xl,xu]=bounds(qp.variables());
    auto [gl,gu]=bounds(qp.rows());
    const auto native=CreateIpoptProblem(n,xl.data(),xu.data(),m,gl.data(),gu.data(),
      static_cast<ipindex>(data.jacobian_rows.size()), static_cast<ipindex>(data.hessian_rows.size()),0,
      objective,constraints,gradient,jacobian,hessian);
    if(!native) throw std::runtime_error("Ipopt failed to construct the problem.");
    std::unique_ptr<IpoptProblemInfo,decltype(&FreeIpoptProblem)> hold(native,&FreeIpoptProblem);
    const auto integer=[&](std::string name, ipindex value) {
      return AddIpoptIntOption(native,name.data(),value);
    };
    const auto string=[&](std::string name, std::string value) {
      return AddIpoptStrOption(native,name.data(),value.data());
    };
    const auto number=[&](std::string name, double value) {
      return AddIpoptNumOption(native,name.data(),value);
    };
    if(!integer("print_level",0) || !string("sb","yes") ||
       !string("nlp_scaling_method","none") ||
       !string("fixed_variable_treatment","make_constraint") ||
       !number("bound_relax_factor",0) ||
       !number("tol",1e-10) || !number("dual_inf_tol",1e-10) ||
       !number("constr_viol_tol",1e-10) || !number("compl_inf_tol",1e-10) ||
       !integer("acceptable_iter",0) || !integer("max_iter",250) ||
       !SetIntermediateCallback(native,iterate)) throw std::runtime_error("Ipopt rejected a probe option.");
    Vector x(n), g(m), lambda(m), zl(n), zu(n);
    if(const auto hint=p.primal_start()) std::copy(hint->begin(),hint->end(),x.begin());
    for(ipindex i=0;i<n;++i) if(!p.primal_start()) x[i]=std::clamp(0.0,xl[i],xu[i]);
    double f{};
    const auto status=IpoptSolve(native,x.data(),g.data(),&f,lambda.data(),zl.data(),zu.data(),&data);
    ProgramResult result{Termination::numerical_failure,
        {p.identity(),MathematicalOutcome::undetermined,Unestablished{},{}},{},{},
        "ipopt_status="+std::to_string(static_cast<int>(status)),{}};
    if(c.cancellation.stop_requested()) result.termination=Termination::cancelled;
    else if(c.deadline && std::chrono::steady_clock::now()>=*c.deadline) result.termination=Termination::deadline_expired;
    else if(status==Maximum_Iterations_Exceeded) result.termination=Termination::resource_limit;
    if(std::all_of(x.begin(),x.end(),[](double v){return std::isfinite(v);})) result.primal=x;
    const auto pe=evaluate_primal(p,x,c.numerical,{{"trial.ipopt.primal"},"1"});
    DualMultipliers multipliers{Vector(m),Vector(m),zl,zu};
    for(ipindex i=0;i<m;++i) {
      multipliers.row_lower[i]=std::max(0.0,-lambda[i]);
      multipliers.row_upper[i]=std::max(0.0,lambda[i]);
    }
    const auto de=evaluate_dual(p,x,multipliers,c.numerical,{{"trial.ipopt.kkt"},"1"});
    if(const auto* ev=std::get_if<ConvexPrimalEvaluation>(&pe)) result.residuals.primal=ev->residuals;
    if(const auto* ev=std::get_if<DualResiduals>(&de)) result.residuals.dual=*ev;
    const auto* source_value=std::get_if<ConvexPrimalEvaluation>(&pe);
    if(status==Solve_Succeeded && result.termination==Termination::numerical_failure &&
        result.residuals.primal && result.residuals.dual && source_value &&
        std::abs(source_value->original_objective-f)<=c.numerical.absolute_tolerance+
            c.numerical.relative_tolerance*std::max(1.0,std::abs(f))) {
      const auto& r=*result.residuals.primal;
      const auto& d=*result.residuals.dual;
      const auto passes=[&](const ResidualMeasure& metric) {
        return metric.violation<=c.numerical.absolute_tolerance+c.numerical.relative_tolerance*metric.scale;
      };
      if(d.stationarity && d.signs && d.complementarity &&
          passes(r.rows) && passes(r.variables) && passes(*d.stationarity) &&
          passes(*d.signs) && passes(*d.complementarity)) {
        result.termination=Termination::completed;
        result.outcome.value=MathematicalOutcome::optimal;
      }
    }
    Json summary{{"program",p.identity().program.value},{"status",static_cast<int>(status)},
      {"accepted",result.outcome.value==MathematicalOutcome::optimal},
      {"variables",n},{"constraints",m},{"native_objective",f},{"primal",x},
      {"lambda",lambda},{"z_lower",zl},{"z_upper",zu},
      {"A_rows",data.jacobian_rows},{"A_columns",data.jacobian_columns},
      {"A_values",std::vector<double>(data.rows.values.begin(),data.rows.values.end())},
      {"H_rows",data.hessian_rows},{"H_columns",data.hessian_columns},{"H_values",data.hessian_values},
      {"linear",std::vector<double>(q->linear.values().begin(),q->linear.values().end())},
      {"offset",q->offset},{"row_bounds",intervals({qp.rows().begin(),qp.rows().end()})},
      {"variable_bounds",intervals({qp.variables().begin(),qp.variables().end()})}};
    std::cerr<<summary.dump()<<'\n';
    return result;
  }
};


struct Fixture {
  AuthoredTaskChoices choices;
  Vector target, state_weights, control_weights;
};

Fixture make_fixture(const model::catalogue::DiscreteModelData &model, int id) {
  const auto nx = model.coefficients.A.rows;
  const auto nu = model.coefficients.B.cols;
  const auto nw = model.coefficients.E.cols;
  Fixture fixture;
  auto &choices = fixture.choices;
  const std::string prefix =
      "catalogue-model-" + std::to_string(id) + "-matched-three";
  choices.problem_id = {prefix + "/1"};
  choices.program_id = {prefix + "-nominal-qp/1"};
  choices.profile_id = prefix + "/1";
  choices.objective_id = "authored-scale-relative-quadratic/1";
  choices.horizon_id = "authored-fixed-three-transitions/1";
  choices.final_stage = horizon;
  fixture.target = model.initial_state;
  fixture.target[0] += .1 * std::max(1., std::abs(fixture.target[0]));
  fixture.control_weights.assign(nu, .05);
  Matrix q{nx, nx, Vector(nx * nx, 0.)};
  Matrix r{nu, nu, Vector(nu * nu, 0.)};
  Vector linear(nx);
  double offset = 0.;
  for (std::size_t i = 0; i < nx; ++i) {
    const double scale = std::max(1., std::abs(model.initial_state[i]));
    const double weight = 1. / (scale * scale);
    fixture.state_weights.push_back(weight);
    q.values[i * nx + i] = weight;
    linear[i] = -weight * fixture.target[i];
    offset += .5 * weight * fixture.target[i] * fixture.target[i];
  }
  for (std::size_t i = 0; i < nu; ++i)
    r.values[i * nu + i] = fixture.control_weights[i];
  choices.running_costs.assign(horizon, {q, Matrix{nx, nu, Vector(nx * nu, 0.)},
                                         r, linear, Vector(nu, 0.), offset});
  for (std::size_t i = 0; i < nx; ++i) {
    q.values[i * nx + i] *= 2.;
    linear[i] *= 2.;
  }
  choices.terminal_cost = {q, linear, 2. * offset};
  const auto external = model.nominal_external.value_or(Vector(nw, 0.));
  choices.forecast_external.assign(horizon, external);
  choices.replay_external = choices.forecast_external;
  choices.forecast_id = model.nominal_external ? "catalogue-nominal-external/1"
                                               : "authored-zero-external/1";
  choices.replay_id = "forecast-matched-replay/1";
  if (id == 4 || id == 9 || id == 10)
    choices.domain_choice = DomainChoice::explicit_continuous_relaxation;
  if (id == 3 || id == 11 || id == 18 || id == 31)
    choices.arrival_availability = ArrivalAvailability::before_decision;
  if (id == 24 || id == 25 || id == 27) {
    choices.domain_choice = DomainChoice::authored_continuous_domain;
    choices.authored_state_bounds = std::vector<Interval>(nx);
    for (std::size_t i = 0; i < nx; ++i) {
      const double limit = 10. * std::max(1., std::abs(model.initial_state[i]));
      choices.authored_state_bounds->at(i) = {-limit, limit};
    }
    choices.authored_control_bounds =
        std::vector<Interval>(nu, Interval{-1., 1.});
  }
  return fixture;
}

Json episode(const MpcEpisodeEvidence &value) {
  const char *status = "unknown";
  switch (value.stop) {
  case EpisodeStop::completed:
    status = "complete";
    break;
  case EpisodeStop::compilation_rejected:
    status = "compilation-rejected";
    break;
  case EpisodeStop::solver_unsupported:
    status = "solver-unsupported";
    break;
  case EpisodeStop::solver_not_optimal:
    status = "solver-not-optimal";
    break;
  case EpisodeStop::simulation_stopped:
    status = "simulation-stopped";
    break;
  }
  auto decisions = Json::array();
  for (const auto &decision : value.decisions) {
    Json stage{{"attempted", decision.attempt.has_value()},
               {"solver_receipt", decision.solve.has_value()},
               {"observed_state", decision.observed_state},
               {"predicted_states", decision.predicted_states},
               {"predicted_controls", decision.predicted_controls},
               {"replay_diagnostics",
                diagnostics(decision.replay_constraint_diagnostics)}};
    if (decision.solve) {
      if (const auto *result = std::get_if<ProgramResult>(&*decision.solve)) {
        stage["termination"] = static_cast<int>(result->termination);
        stage["raw_diagnostics"] = result->raw_diagnostics;
      } else if (const auto *errors =
                     std::get_if<Diagnostics>(&*decision.solve)) {
        stage["solve_diagnostics"] = diagnostics(*errors);
      } else if (const auto *unsupported =
                     std::get_if<Unsupported>(&*decision.solve)) {
        stage["solve_diagnostics"] = diagnostics(unsupported->diagnostics);
      } else if (const auto *stopped =
                     std::get_if<OperationStopped>(&*decision.solve)) {
        stage["raw_diagnostics"] = stopped->diagnostics;
      }
    }
    decisions.push_back(std::move(stage));
  }
  return {{"status", status},
          {"states", value.realized_states},
          {"controls", value.applied_controls},
          {"realized_cost", optional_scalar(value.realized_objective)},
          {"terminal_diagnostics",
           diagnostics(value.terminal_constraint_diagnostics)},
          {"decisions", std::move(decisions)}};
}

Json run_model(int id) {
  const auto key = "catalogue-2026/model-" + std::to_string(id) + "/1";
  const auto data = model::catalogue::make_discrete_model(key);
  if (const auto *errors = std::get_if<Diagnostics>(&data))
    return {{"model_id", key},
            {"status", "catalogue-rejected"},
            {"diagnostics", diagnostics(*errors)}};
  const auto &model = std::get<model::catalogue::DiscreteModelData>(data);
  const auto fixture = make_fixture(model, id);
  const auto admitted = make_source_task_profile(key, fixture.choices);
  if (const auto *errors = std::get_if<Diagnostics>(&admitted))
    return {{"model_id", key},
            {"status", "task-rejected"},
            {"diagnostics", diagnostics(*errors)}};
  if (const auto *deferred = std::get_if<DeferredTask>(&admitted))
    return {{"model_id", key},
            {"status", "deferred"},
            {"reason", deferred->reason}};
  const auto &task = std::get<NominalMpcTask>(admitted);
  const auto probe =
      compile_mpc_decision(task, StageIndex{0}, task.initial.point);
  if (const auto *errors = std::get_if<Diagnostics>(&probe))
    return {{"model_id", key},
            {"status", "probe-rejected"},
            {"diagnostics", diagnostics(*errors)}};
  const ExecutionContext context{
      std::make_shared<const ResourcePolicy>(ResourcePolicy{1, 1, 1, {}}),
      {},
      {},
      {1e-8, 1e-8},
      "catalogue-matched-three"};
  auto open_workspace = std::make_unique<IpoptProbeWorkspace>();
  auto feedback_workspace = std::make_unique<IpoptProbeWorkspace>();
  if (!open_workspace || !feedback_workspace)
    throw std::runtime_error("HiGHS workspace construction failed");
  return {
      {"model_id", key},
      {"title", model.info.title},
      {"status", "attempted"},
      {"profile", task.provenance.profile_id},
      {"domain", task.provenance.domain_choice},
      {"forecast", task.provenance.forecast_id},
      {"source", task.provenance.source_reference},
      {"backend", "trial.convex.ipopt-direct"},
      {"backend_version", "3.14.19"},
      {"horizon", horizon},
      {"A", matrix(model.coefficients.A)},
      {"B", matrix(model.coefficients.B)},
      {"G", matrix(model.coefficients.E)},
      {"offset", model.coefficients.offset},
      {"initial", task.initial.point},
      {"target", fixture.target},
      {"state_weights", fixture.state_weights},
      {"control_weights", fixture.control_weights},
      {"external", task.replay_external},
      {"constraints", constraints(task)},
      {"open_loop",
       episode(execute_nominal_episode(task, EpisodePolicy::nominal_open_loop,
                                       *open_workspace, context))},
      {"closed_loop",
       episode(execute_nominal_episode(task, EpisodePolicy::observed_state_mpc,
                                       *feedback_workspace, context))}};
}
} // namespace

int main(int argc, char **argv) try {
  if (argc != 2)
    throw std::runtime_error("Usage: catalogue_episode MODEL_NUMBER");
  std::cout << run_model(std::stoi(argv[1])).dump() << '\n';
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
