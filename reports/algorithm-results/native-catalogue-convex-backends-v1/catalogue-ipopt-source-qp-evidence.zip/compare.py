"""Compare independent route outcomes and prove the archived infeasibility."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path

POLICIES = ("open_loop", "closed_loop")


def verify_bikes(route):
    assert route["A"]["values"][:3] == [1, 0, 0]
    assert route["B"]["values"][:2] == [-1, 0]
    assert route["G"]["values"][:3] == [1, 0, 0]
    assert not any(route["offset"])
    assert all(bounds[0][0] == 0 for bounds in route["constraints"]["control"])
    target_minimum = Q(route["constraints"]["state"][3][0][0])
    upper = Q(route["initial"][0]) + sum(Q(row[0]) for row in route["external"])
    assert upper == -3 and target_minimum == 0
    return {"coordinate": "x1", "terminal_upper_bound": int(upper),
            "required_terminal_minimum": int(target_minimum)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("previous", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("kkt", type=Path)
    args = parser.parse_args()
    kkt = json.loads(args.kkt.read_bytes())
    matched = 0
    max_cost_gap = 0.0
    recovered = []
    terminal_infeasibility = None
    for i in range(1, 36):
        old, new = (json.loads((root / f"{i}.json").read_bytes())
                    for root in (args.previous, args.candidate))
        fields = set(old) - {"backend", "backend_version", *POLICIES}
        assert fields == set(new) - {"backend", "backend_version", *POLICIES}
        assert all(old[key] == new[key] for key in fields), i
        if i == 9:
            terminal_infeasibility = verify_bikes(new)
            assert kkt[str(i)]["statuses"] == [2, 2] and kkt[str(i)]["accepted"] == 0
            assert all(new[mode]["status"] == "solver-not-optimal" for mode in POLICIES)
            continue
        assert kkt[str(i)]["accepted"] == 4
        for mode in POLICIES:
            assert new[mode]["status"] == "complete", (i, mode)
            if old[mode]["status"] == "complete":
                matched += 1
                max_cost_gap = max(max_cost_gap, abs(
                    old[mode]["realized_cost"] - new[mode]["realized_cost"]))
            else:
                recovered.append([i, mode])
    assert matched == 61
    assert recovered == [[i, mode] for i in (23, 27, 28) for mode in POLICIES] + [[30, "closed_loop"]]
    assert max_cost_gap < 1e-7
    print(json.dumps({"matched_completed_routes": matched, "recovered_routes": recovered,
                      "paired_completions": 34, "max_matched_original_cost_gap": max_cost_gap,
                      "model_9_exact_source_infeasibility": terminal_infeasibility}, indent=2))


if __name__ == "__main__":
    main()

