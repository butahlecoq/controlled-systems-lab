import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("episode", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    record = json.loads(args.episode.read_bytes())
    assert record["model_id"] == "catalogue-2026/model-28/1"
    matplotlib.rcParams.update({"svg.hashsalt": "csl-ipopt-rc-building", "svg.fonttype": "none"})
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 4.2))
    for mode, label, color, marker, line in (
        ("open_loop", "Held sequence", "#08736a", "o", "-"),
        ("closed_loop", "Observed-state MPC", "#653789", "D", "--"),
    ):
        route = record[mode]
        assert route["status"] == "complete"
        states = route["states"]
        for plane, (a, b) in zip(axes, ((0, 1), (2, 3)), strict=True):
            plane.plot([x[a] for x in states], [x[b] for x in states],
                       color=color, label=label, marker=marker, markersize=6,
                       markerfacecolor="white", linestyle=line, linewidth=1.6)
    for plane, (a, b) in zip(axes, ((0, 1), (2, 3)), strict=True):
        for k, point in enumerate(record["closed_loop"]["states"]):
            plane.annotate(f"$k={k}$", (point[a], point[b]), xytext=(0, 9),
                           ha="center", textcoords="offset points", fontsize=9)
        plane.set(xlabel=f"$x_{a+1}$", ylabel=f"$x_{b+1}$")
        plane.margins(x=0.14, y=0.16)
        plane.grid(color="#dde2e8", linewidth=0.65)
    fig.suptitle("Twenty-zone RC building", fontsize=16, weight="bold")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False)
    fig.subplots_adjust(left=0.10, right=0.98, bottom=0.23, top=0.87, wspace=0.39)
    fig.savefig(args.output.with_suffix(".svg"), metadata={"Date": None})
    fig.savefig(args.output.with_suffix(".png"), dpi=210)


if __name__ == "__main__":
    main()

