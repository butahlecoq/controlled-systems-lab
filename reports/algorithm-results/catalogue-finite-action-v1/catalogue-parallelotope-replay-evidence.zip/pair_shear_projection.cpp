#include <csl/reachability/finite_plan_parallelotope.hpp>
#include <nlohmann/json.hpp>

#include <iostream>
#include <variant>

using namespace csl;
using nlohmann::json;

template <class T, class... Errors>
T require(std::variant<T, Errors...> value) {
    return std::get<T>(std::move(value));
}

int main() {
    constexpr std::size_t n = 3;
    const SystemModel source{
        {{n, 1, 1},
         TimeDomain::discrete,
         LinearStage{{n, n, {1, 0.25, 0, 0, 1, 0.25, 0.25, 0, 0.5}},
                     {n, 1, {0.25, 0.25, -0.25}},
                     {n, 1, {0.125, -0.25, 0.125}},
                     {0, 0, 0}}},
        {}};
    const auto system = require(model::snapshot(source, Vector{0, 1, 2}));
    const std::vector<Vector> points{
        {-1, -0.75, 0}, {1, 0.75, 0.25}, {-0.5, 0.5, -0.5}, {0.5, -0.5, 0.5}};
    Vector packed;
    for (const auto &point : points)
        packed.insert(packed.end(), point.begin(), point.end());
    const auto initial = require(sets::make_v(
        {{"projection-initial"}, n, {}},
        {require(numeric::snapshot(Matrix{points.size(), n, packed})),
         require(numeric::snapshot(Matrix{0, n, {}}))}));
    const auto disturbances = require(sets::make_v(
        {{"projection-disturbances"}, 1, {}},
        {require(numeric::snapshot(Matrix{2, 1, {-1, 1}})),
         require(numeric::snapshot(Matrix{0, 1, {}}))}));
    const auto safe = require(sets::make_universal({{"projection-domain"}, n, {}}));
    const std::vector<Vector> controls{{1}, {-1}};
    const reachability::FixedPlanRequest request{system,
                                                 initial,
                                                 controls,
                                                 {disturbances, disturbances},
                                                 {safe, safe, safe},
                                                 {"projection-plan"}};
    const auto trace = require(reachability::finite_plan_parallelotope(request));
    json samples = json::array();
    auto current = points;
    for (std::size_t stage = 0; stage < trace.stages.size(); ++stage) {
        const auto &bounds = trace.stages[stage];
        samples.push_back({{"time", stage}, {"lower", bounds.lower},
                           {"upper", bounds.upper}, {"exact_vertices", current}});
        if (stage == controls.size())
            break;
        std::vector<Vector> next;
        for (const auto &x : current)
            for (double w : {-1.0, 1.0})
                next.push_back(require(system.step({stage}, x, controls[stage], Vector{w})));
        current = std::move(next);
    }
    std::cout << json{{"frame", trace.frame.values}, {"samples", samples}}.dump(2) << '\n';
}

