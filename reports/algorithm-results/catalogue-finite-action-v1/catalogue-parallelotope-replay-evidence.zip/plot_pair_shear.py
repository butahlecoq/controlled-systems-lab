"""Render native fixed-plan parallelotopes and physical reachable hulls."""
import argparse
from fractions import Fraction
from itertools import product
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


def hull(points):
    points = sorted(set(points))

    def half(ordered):
        boundary = []
        for c in ordered:
            while len(boundary) >= 2:
                a, b = boundary[-2:]
                area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
                if area > 0:
                    break
                boundary.pop()
            boundary.append(c)
        return boundary[:-1]

    return half(points) + half(reversed(points))


def projected(points, x, y):
    boundary = hull((p[x], p[y]) for p in points)
    return tuple(zip(*(boundary + boundary[:1]), strict=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output_prefix", type=Path)
    args = parser.parse_args()
    raw = json.loads(args.input.read_text())
    frame = raw["frame"]
    assert frame == [1, 1, 0, 0, 1, 0, 0, 0, 1]
    matplotlib.rcParams.update({"svg.hashsalt": "csl-pair-shear-1", "svg.fonttype": "none"})
    fig, axes = plt.subplots(1, 2, figsize=(8.7, 4.6))
    colors = ["#5b6472", "#00695c", "#63369a"]
    for sample, color in zip(raw["samples"], colors, strict=True):
        lo = sample["lower"]
        hi = sample["upper"]
        exact = sample["exact_vertices"]
        for x, y, z in exact:
            coordinates = (Fraction(x) - Fraction(y), Fraction(y), Fraction(z))
            assert all(Fraction(a) <= v <= Fraction(b)
                       for a, v, b in zip(lo, coordinates, hi, strict=True))
        corners = [
            [sum(frame[3 * row + col] * u[col] for col in range(3)) for row in range(3)]
            for u in product(*zip(lo, hi, strict=True))
        ]
        for ax, (x, y) in zip(axes, ((0, 1), (1, 2)), strict=True):
            ax.plot(*projected(corners, x, y), color=color, linewidth=1.35)
            ax.plot(*projected(exact, x, y), color=color, linestyle="--", linewidth=1.5)
            ax.set(xlabel=f"$x_{x + 1}$", ylabel=f"$x_{y + 1}$", aspect="equal")
            ax.grid(True, color="#dde2e8", linewidth=0.65, zorder=0)
    handles = [Line2D([], [], color=color, linewidth=2, label=f"$k={k}$")
               for k, color in enumerate(colors)]
    handles += [
        Line2D([], [], color="#1b2432", linewidth=1.4, label="Outer parallelotope"),
        Line2D([], [], color="#1b2432", linewidth=1.5, linestyle="--", label="Reachable hull"),
    ]
    fig.suptitle("The first coordinate pair is sheared", y=0.95, fontsize=16, weight="semibold")
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 0.035),
               ncol=5, frameon=False)
    fig.subplots_adjust(left=0.085, right=0.98, bottom=0.24, top=0.87, wspace=0.32)
    fig.savefig(args.output_prefix.with_suffix(".svg"), metadata={"Date": None})
    fig.savefig(args.output_prefix.with_suffix(".png"), dpi=220)


if __name__ == "__main__":
    main()

