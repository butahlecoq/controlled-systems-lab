"""Exact reference for fixed frames and finite-action parallelotope scores."""
import argparse
from fractions import Fraction as Q
import hashlib
from itertools import product
import json
from pathlib import Path
import random

from verify import matrix, dot, cross_match


def add(a, b):
    return tuple(x + y for x, y in zip(a, b, strict=True))


def image(a, x):
    return tuple(dot(row, x) for row in a)


def frame(n, block):
    return tuple(
        tuple(Q(i == j or (j == i + 1 and j % block != 0)) for j in range(n))
        for i in range(n)
    )


def inverse(n, block):
    return tuple(
        tuple(Q((-1) ** (j - i)) if i <= j and i // block == j // block else Q(0)
              for j in range(n))
        for i in range(n)
    )


def compose(a, b):
    columns = tuple(zip(*b, strict=True))
    return tuple(tuple(dot(row, col) for col in columns) for row in a)


def score_path(lo, hi, f, diagonal, linear, constant):
    endpoints = tuple(zip(lo, hi, strict=True))

    def cost(i, value):
        return diagonal[i] * value * value / 2 + linear[i] * value

    scores = (constant, constant)
    for i, (left, right) in enumerate(zip(endpoints, endpoints[1:])):
        scores = tuple(
            max(scores[p] + cost(i, left[p] + f[i][i + 1] * value)
                for p in range(2))
            for value in right
        )
    return max(s + cost(len(lo) - 1, x)
               for s, x in zip(scores, endpoints[-1], strict=True))


def objective_value(x, diagonal, linear, constant):
    return constant + sum(h * v * v / 2 + l * v
                          for h, l, v in zip(diagonal, linear, x, strict=True))


def exhaustive(lo, hi, f, diag, linear, constant):
    return max(objective_value(image(f, corner), diag, linear, constant)
               for corner in product(*zip(lo, hi, strict=True)))


def scoring_checks():
    rng = random.Random(1012)
    count = 0
    for n in range(1, 10):
        for block in (1, 2, n):
            f = frame(n, block)
            assert compose(f, inverse(n, block)) == frame(n, 1)
            for _ in range(10):
                lo = tuple(Q(rng.randrange(-20, 21), 8) for _ in range(n))
                hi = tuple(v + Q(rng.randrange(0, 10), 8) for v in lo)
                h = tuple(Q(rng.randrange(0, 10), 8) for _ in lo)
                linear = tuple(Q(rng.randrange(-20, 21), 4) for _ in lo)
                c = Q(rng.randrange(-20, 21), 4)
                assert score_path(lo, hi, f, h, linear, c) == exhaustive(
                    lo, hi, f, h, linear, c
                )
                count += 1
    return count


def verify_catalogue(packet):
    n = len(packet["x0"])
    a, b, e = (matrix(packet[name]) for name in ("A", "B", "E"))
    x0 = tuple(map(Q, packet["x0"]))
    actions = tuple(tuple(map(Q, u)) for u in packet["actions"])
    external = tuple(map(Q, packet["external"]))
    shifts = tuple(add(add(image(b, u), image(e, external)), tuple(map(Q, packet["c"])))
                   for u in actions)
    objective = packet["objective"]
    h = matrix(objective["Q"])
    diag = tuple(h[i][i] for i in range(n))
    assert all(value == (diag[i] if i == j else 0)
               for i, row in enumerate(h) for j, value in enumerate(row))
    assert min(diag) >= 0
    linear = tuple(map(Q, objective["linear"]))
    constant = Q(objective["constant"])

    def check_frame(block):
        f = frame(n, block)
        fi = inverse(n, block)
        assert compose(f, fi) == frame(n, 1)
        af = compose(compose(fi, a), f)
        shifts_f = tuple(image(fi, shift) for shift in shifts)
        count = 0
        baseline_error = Q(0)

        def verify_paths(physical, length, archived):
            nonlocal count, baseline_error
            start_f = image(fi, physical)
            candidates = []
            for route in product(range(len(actions)), repeat=length):
                x, y = physical, start_f
                for action in route:
                    x = add(image(a, x), shifts[action])
                    y = add(image(af, y), shifts_f[action])
                    assert image(f, y) == x
                cost = score_path(y, y, f, diag, linear, constant)
                assert cost == objective_value(x, diag, linear, constant)
                if archived:
                    historical = next(
                        attempt for attempt in archived["attempts"]
                        if tuple(attempt["action_indices"]) == route
                    )
                    assert historical["status"] == "scored"
                    scaled = abs(cost - Q(historical["score"])) / max(Q(1), abs(cost))
                    assert scaled <= Q("5e-12")
                    baseline_error = max(baseline_error, scaled)
                candidates.append((cost, route, x))
                count += 1
            return min(candidates)

        old = packet["outcomes"]["parallelotope"]
        supported = old["open_loop"]["status"] == "selected"
        cost, route, _ = verify_paths(x0, 2, old["open_loop"] if supported else None)
        observed = add(image(a, x0), shifts[route[0]])
        tail, tail_route, _ = verify_paths(observed, 1, None)
        if supported:
            prior_observation = tuple(map(Q, old["feedback"]["observed_states"][1]))
            verify_paths(prior_observation, 1, old["feedback"]["replan"])

        # Sensitivity experiment only. Start with a common physical unit box
        # centred on the same x0 and retain the same singleton disturbances.
        radius = tuple(sum(map(abs, row)) for row in fi)
        for _ in range(2):
            radius = tuple(dot(tuple(map(abs, row)), radius) for row in af)
        projected = tuple(dot(tuple(map(abs, row)), radius) for row in f)
        exact_projected = tuple(sum(map(abs, row)) for row in compose(a, a))
        assert all(bound >= sharp for bound, sharp in zip(projected, exact_projected, strict=True))
        return count - 3 * supported, [route[0], tail_route[0]], cost, tail, projected, baseline_error

    box, pair, chain = (check_frame(block) for block in (1, 2, n))
    assert box[:4] == pair[:4] == chain[:4]
    ratios = [sum(test[4]) / sum(box[4]) if sum(box[4]) else Q(0) for test in (pair, chain)]
    return {
        "model": packet["model_id"],
        "dimension": n,
        "archived_status": packet["outcomes"]["parallelotope"]["open_loop"]["status"],
        "paths_per_frame": chain[0],
        "feedback_indices": chain[1],
        "max_archived_score_scaled_delta": float(max(x[5] for x in (box, pair, chain))),
        "unit_box_sum_physical_width_ratio": dict(
            zip(("pair_shears", "chain_shear"), map(float, ratios), strict=True)
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("evidence", type=Path)
    args = parser.parse_args()
    files = [args.evidence / "raw" / f"{i}.json" for i in range(1, 36)]
    refs = json.loads((args.evidence / "reference.json").read_text())
    rows = []
    for path in files:
        packet = json.loads(path.read_text())
        cross_match(packet, refs[path.stem])
        result = verify_catalogue(packet)
        result["input_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append(result)
    print(json.dumps({"exact_exhaustive_cases": scoring_checks(), "models": rows}, indent=2))


if __name__ == "__main__":
    main()

