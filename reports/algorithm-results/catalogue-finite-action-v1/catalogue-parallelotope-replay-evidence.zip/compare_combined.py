from pathlib import Path
import json
import sys

old, new = map(Path, sys.argv[1:])
recovered = []
matched = 0
for i in range(1, 36):
    a, b = (json.loads((root / f"{i}.json").read_text()) for root in (old, new))
    before, after = (packet.pop("outcomes") for packet in (a, b))
    assert a == b
    for profile, outcome in before.items():
        now = after[profile]
        assert now["open_loop"]["status"] == now["feedback"]["status"] == "selected"
        if profile == "parallelotope" and outcome["feedback"]["status"] != "selected":
            recovered.append({"model": i, "dimension": len(a["x0"])})
        else:
            assert outcome == now, (i, profile)
            matched += 1
assert matched == 155 and len(recovered) == 20
print(json.dumps({"unchanged_rows": matched, "recovered": recovered}, indent=2))

