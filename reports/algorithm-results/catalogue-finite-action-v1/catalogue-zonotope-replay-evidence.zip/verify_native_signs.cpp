#include "zonotope_corner_certificate.hpp"
#include <nlohmann/json.hpp>

#include <fstream>
#include <iostream>
#include <stdexcept>
#include <utility>

namespace {
using namespace csl;
using namespace csl::optimization;
using Json = nlohmann::json;

Json witness(const Json &raw, const Objective &objective) {
  reachability::FinitePlanZonotopeTrace::Stage stage{
      raw.at("center").get<Vector>(),
      {raw.at("rows").get<std::size_t>(), raw.at("columns").get<std::size_t>(),
       raw.at("G").get<Vector>()},
      {}};
  for (const auto &name : raw.at("factors"))
    stage.factors.push_back({name.get<std::string>()});
  const auto result = csl::optimization::detail::certify_zonotope_corner(stage, objective, {});
  if (const auto *signs = std::get_if<std::vector<int>>(&result))
    return *signs;
  if (const auto *stop = std::get_if<OperationStopped>(&result))
    return {{"stopped", stop->diagnostics}};
  return nullptr;
}
} // namespace

int main(int argc, char **argv) {
  try {
    if (argc != 2)
      throw std::invalid_argument("one factor record is required");
    std::ifstream input(argv[1]);
    const auto raw = Json::parse(input);
    const auto diagonal = raw.at("Q_diagonal").get<Vector>();
    const auto n = diagonal.size();
    Matrix Q{n, n, Vector(n * n)};
    for (std::size_t i = 0; i < n; ++i)
      Q.values[i * n + i] = diagonal[i];
    const auto objective = std::get<Objective>(
        snapshot(QuadraticTerminal{std::move(Q), raw.at("linear").get<Vector>(),
                                   raw.at("constant").get<double>()}));
    Json output = Json::array();
    for (const auto &plan : raw.at("plans"))
      output.push_back({{"actions", plan.at("actions")},
                        {"open", witness(plan.at("open"), objective)},
                        {"tail", witness(plan.at("tail"), objective)}});
    std::cout << output.dump() << '\n';
    return 0;
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
