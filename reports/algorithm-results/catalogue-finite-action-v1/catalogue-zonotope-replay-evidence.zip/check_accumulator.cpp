#include "exact_dyadic_sum.hpp"
#include <gmpxx.h>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <random>

using csl::optimization::detail::ExactDyadicSum;
using csl::optimization::detail::ExactTripleSum;

int main() {
    std::mt19937_64 random(537219);
    auto finite = [&] {
        std::uint64_t bits = random();
        if ((bits & (std::uint64_t{0x7ff} << 52)) == (std::uint64_t{0x7ff} << 52))
            bits ^= std::uint64_t{1} << 52;
        return std::bit_cast<double>(bits);
    };
    const auto actual_sign = [](const auto& accumulator) {
        return int(accumulator.positive()) - int(accumulator.negative());
    };
    for (int trial = 0; trial < 2048; ++trial) {
        ExactTripleSum left, right;
        ExactDyadicSum pairs;
        mpq_class exact_left, exact_right, exact_pairs;
        for (int k = 0; k < 12; ++k) {
            const std::array values{finite(), finite(), finite()};
            const auto& [a, b, c] = values;
            pairs.add_product(a, b);
            exact_pairs += mpq_class(a) * mpq_class(b);
            if (k % 2 == 0) {
                left.add_triple(a, b, c);
                exact_left += mpq_class(a) * mpq_class(b) * mpq_class(c);
            } else {
                right.add_triple(a, b, c);
                exact_right += mpq_class(a) * mpq_class(b) * mpq_class(c);
            }
        }
        const bool subtract = trial % 2 == 0;
        left.add_sum(right, subtract);
        if (subtract) exact_left -= exact_right;
        else exact_left += exact_right;
        if (actual_sign(left) != sgn(exact_left) || actual_sign(pairs) != sgn(exact_pairs))
            return 1;
    }
    ExactTripleSum self;
    self.add_triple(1, 1, -1);
    self.add_sum(self, true);
    if (!self.zero()) return 2;
    std::cout << "2,048 two-product and 2,048 mixed three-product sums agree with GMP\n";
}
