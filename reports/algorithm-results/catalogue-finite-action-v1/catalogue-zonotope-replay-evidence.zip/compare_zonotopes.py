"""Check the unchanged release outcomes and the recovered native routes."""
import argparse
import json
from pathlib import Path


def load(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    audit = load(args.candidate / "audit.json")["models"]
    unchanged, unchanged_other = [], 0
    recovered = []
    changed_replan = []
    max_error = 0.0
    for i in range(1, 36):
        before = load(args.baseline / "raw" / f"{i}.json")
        after = load(args.candidate / "raw" / f"{i}.json")
        older, newer = before.pop("outcomes"), after.pop("outcomes")
        assert before == after
        old_zone, new_zone = older.pop("zonotope"), newer.pop("zonotope")
        assert older == newer
        unchanged_other += len(older)
        row = audit[str(i)]["profiles"]["zonotope"]
        assert row["first"]["exact_finite_optimum"] and row["second"]["exact_finite_optimum"]
        if row["replanned_control_changed"]:
            changed_replan.append(i)
        max_error = max(max_error, *(row[stage]["max_scaled_score_error"] for stage in ("first", "second")))
        if old_zone["feedback"]["status"] == "selected":
            assert old_zone == new_zone
            unchanged.append(i)
        else:
            assert old_zone["open_loop"]["status"] == "no-scored-candidate"
            assert all(attempt["status"] == "unsupported" and
                       attempt["diagnostics"][0]["field"] == "finite_zonotope_minimax.corners"
                       for attempt in old_zone["open_loop"]["attempts"])
            recovered.append(i)
        assert new_zone["open_loop"]["coverage"] == "complete"
        assert new_zone["feedback"]["status"] == "selected"
    assert recovered == list(range(21, 36))
    result = {
        "models": 35,
        "recovered_zonotope_models": recovered,
        "unchanged_zonotope_models": unchanged,
        "matching_other_outcomes": unchanged_other,
        "replanned_control_changes": changed_replan,
        "max_scaled_zonotope_score_error": max_error,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
