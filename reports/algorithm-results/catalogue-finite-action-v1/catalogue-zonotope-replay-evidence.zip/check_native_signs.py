"""Verify production native witnesses directly in physical coordinates."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
import subprocess


def load(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("native_sign_executable", type=Path)
    parser.add_argument("prototype_capture", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    reference = load(args.prototype_capture / "native-certificates.json")
    receipts = {}
    for case, certificates in reference.items():
        raw = args.prototype_capture / "factors" / f"{case}.json"
        source = load(raw)
        trial = json.loads(subprocess.check_output(
            [args.native_sign_executable.resolve(), raw], timeout=30
        ))
        diagonal = list(map(Q, source["Q_diagonal"]))
        linear = list(map(Q, source["linear"]))
        base = Q(source["constant"])
        for plan, expected, result in zip(source["plans"], certificates, trial, strict=True):
            assert plan["actions"] == result["actions"] == expected["actions"]
            for mode in ("open", "tail"):
                stage = plan[mode]
                signs = result[mode]
                width = stage["columns"]
                assert len(signs) == width and set(signs) <= {-1, 1}
                state = []
                for row, center in enumerate(stage["center"]):
                    generator = stage["G"][row * width:(row + 1) * width]
                    state.append(Q(center) + sum(s * Q(g) for s, g in zip(signs, generator, strict=True)))
                value = base + sum(x * (q*x/2 + b)
                                   for x, q, b in zip(state, diagonal, linear, strict=True))
                assert value == Q(expected[mode]["exact_maximum"]), (case, plan["actions"], mode)
        receipts[case] = trial
    args.output.write_text(json.dumps(receipts, separators=(",", ":")) + "\n")
    print("Production signs attain all 630 independently certified maxima exactly")


if __name__ == "__main__":
    main()
