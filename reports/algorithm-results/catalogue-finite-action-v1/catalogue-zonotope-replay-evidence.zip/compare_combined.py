"""Reconcile the joint replay with the two isolated module substitutions."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("combined", type=Path)
    parser.add_argument("zonotope", type=Path)
    parser.add_argument("box", type=Path)
    args = parser.parse_args()
    for i in range(1, 36):
        case = f"raw/{i}.json"
        joined = json.loads((args.combined / case).read_bytes())["outcomes"]
        zone = json.loads((args.zonotope / case).read_bytes())["outcomes"]
        box = json.loads((args.box / case).read_bytes())["outcomes"]
        assert joined == dict(zone, box=box["box"])
    audit = json.loads((args.combined / "audit.json").read_bytes())
    count = sum(v.get("selected", 0) for v in audit["feedback_counts"].values())
    assert count == 155
    print("Combined replay reconciled all 175 outcomes; 155 completed both decisions")


if __name__ == "__main__":
    main()
