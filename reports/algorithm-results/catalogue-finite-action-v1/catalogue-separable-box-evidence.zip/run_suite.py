import argparse
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("executable", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    executable = args.executable.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    reference = json.loads((ROOT / "reference.json").read_bytes())
    results = {}
    for number, fixture in sorted(reference.items(), key=lambda row: int(row[0])):
        try:
            result = subprocess.run(
                [executable, fixture["model_id"]],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=30,
                check=False,
            )
            state = "completed" if result.returncode == 0 else "failed"
            stdout, stderr, code = result.stdout, result.stderr, result.returncode
        except subprocess.TimeoutExpired as timeout:
            state, code = "wall-time-limit", None
            stdout, stderr = timeout.stdout or b"", timeout.stderr or b""
        (args.output / f"{number}.json").write_bytes(stdout)
        (args.output / f"{number}.stderr").write_bytes(stderr)
        results[number] = {"model_id": fixture["model_id"], "status": state, "exit": code}
        print(number, state, flush=True)
    (args.output / "process-outcomes.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
