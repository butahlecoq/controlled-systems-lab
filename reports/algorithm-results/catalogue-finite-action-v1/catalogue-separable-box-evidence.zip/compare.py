import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    audit = json.loads((args.candidate / "audit.json").read_bytes())["models"]
    recovered, retained = [], []
    unchanged_nonbox = 0
    score_gap = 0
    for number in range(1, 36):
        name = f"{number}.json"
        baseline = json.loads((args.baseline / "raw" / name).read_bytes())
        candidate = json.loads((args.candidate / "raw" / name).read_bytes())
        before, after = baseline.pop("outcomes"), candidate.pop("outcomes")
        assert baseline == candidate
        old_box, new_box = before.pop("box"), after.pop("box")
        assert before == after
        unchanged_nonbox += len(before)
        assert new_box["open_loop"]["coverage"] == "complete"
        assert new_box["feedback"]["status"] == "selected"
        report = audit[str(number)]["profiles"]["box"]
        assert report["first"]["exact_finite_optimum"] and report["second"]["exact_finite_optimum"]
        score_gap = max(
            score_gap,
            report["first"]["max_scaled_score_error"],
            report["second"]["max_scaled_score_error"],
        )
        if old_box["feedback"]["status"] == "selected":
            assert old_box["open_loop"]["controls"] == new_box["open_loop"]["controls"]
            assert old_box["feedback"]["applied_controls"] == new_box["feedback"]["applied_controls"]
            assert old_box["feedback"]["observed_states"] == new_box["feedback"]["observed_states"]
            retained.append(number)
        else:
            assert old_box["open_loop"]["status"] == "no-scored-candidate"
            assert all(
                row["status"] == "unsupported"
                and row["diagnostics"][0]["field"] == "finite_box_minimax.corners"
                for row in old_box["open_loop"]["attempts"]
            )
            recovered.append(number)
    result = {
        "models": 35,
        "recovered_box_models": recovered,
        "retained_box_models": retained,
        "matching_nonbox_outcomes": unchanged_nonbox,
        "max_scaled_box_score_error": score_gap,
    }
    assert recovered == list(range(26, 36))
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
