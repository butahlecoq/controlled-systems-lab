import argparse
from collections import Counter
from fractions import Fraction as Q
from functools import cache
from itertools import product
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILES = ("polytope", "box", "zonotope", "parallelotope", "ellipsoid")
TOLERANCE = Q("5e-12")


def dot(row, values):
    return sum((a * b for a, b in zip(row, values, strict=True) if a and b), Q(0))


def matrix(source):
    packed = source["row_major"]
    rows, columns = source["rows"], source["columns"]
    assert len(packed) == rows * columns
    return tuple(
        tuple(map(Q, packed[i * columns : (i + 1) * columns])) for i in range(rows)
    )


def cross_match(packet, reference):
    assert packet["model_id"] == reference["model_id"]
    assert packet["x0"] == reference["initial"]
    assert packet["c"] == reference["offset"]
    assert packet["external"] == reference["external"]
    assert packet["supplied_nominal_external"] == (
        reference["forecast"] == "catalogue-nominal-external/1"
    )
    for field, prior in (("A", "A"), ("B", "B"), ("E", "G")):
        old = reference[prior]
        assert packet[field] == {
            "rows": old["rows"],
            "columns": old["cols"],
            "row_major": old["values"],
        }


def scaled(delta, base):
    return abs(delta) / max(Q(1), abs(base))


def audit(packet, reference):
    cross_match(packet, reference)
    assert packet["horizon"] == 2
    assert set(packet["outcomes"]) == set(PROFILES)
    a, b, e = (matrix(packet[name]) for name in ("A", "B", "E"))
    x0 = tuple(map(Q, packet["x0"]))
    external = tuple(map(Q, packet["external"]))
    actions = tuple(tuple(map(Q, action)) for action in packet["actions"])
    assert len(actions) == 3
    m = len(actions[0])
    assert actions == ((Q(0),) * m, (Q(-0.1),) + (Q(0),) * (m - 1),
                       (Q(0.1),) + (Q(0),) * (m - 1))
    external_offset = tuple(Q(c) + dot(row, external) for c, row in zip(packet["c"], e, strict=True))
    objective = packet["objective"]
    hessian, linear = matrix(objective["Q"]), tuple(map(Q, objective["linear"]))
    constant = Q(objective["constant"])
    intended_scale = tuple(max(Q(1), abs(x)) for x in x0)

    @cache
    def step(state, action):
        return tuple(
            dot(a_row, state) + dot(b_row, actions[action]) + offset
            for a_row, b_row, offset in zip(a, b, external_offset, strict=True)
        )

    @cache
    def cost(state):
        return constant + dot(linear, state) + sum(
            x * dot(row, state) / 2 for x, row in zip(state, hessian, strict=True)
        )

    def intended_cost(state):
        return sum(
            ((value - target) / scale) ** 2
            for value, target, scale in zip(state, x0, intended_scale, strict=True)
        )

    def cost_gap_for_all_paths(traces):
        return max(
            scaled(cost(path[-1]) - intended_cost(path[-1]), intended_cost(path[-1]))
            for path in traces.values()
        )

    def paths(state, length):
        result = {}
        for indexes in product(range(3), repeat=length):
            trace = [state]
            for index in indexes:
                trace.append(step(trace[-1], index))
            result[indexes] = trace
        return result

    def state_error(captured, trace):
        return max(
            scaled(Q(value) - expected, expected)
            for left, right in zip(captured, trace, strict=True)
            for value, expected in zip(left, right, strict=True)
        )

    def verify_attempts(decision, traces):
        seen = set()
        scored_gaps = []
        for attempt in decision["attempts"]:
            indices = tuple(attempt["action_indices"])
            assert indices in traces and indices not in seen
            seen.add(indices)
            if attempt["status"] == "scored":
                expected = cost(traces[indices][-1])
                gap = scaled(Q(attempt["score"]) - expected, expected)
                assert gap <= TOLERANCE, (packet["model_id"], indices, float(gap))
                assert attempt["running_cost"] == 0
                assert attempt["terminal_score"] == attempt["score"]
                scored_gaps.append(gap)
            else:
                assert attempt["status"] == "unsupported" and attempt["diagnostics"]
        assert seen == set(traces)
        if decision["status"] != "selected":
            assert decision["status"] == "no-scored-candidate" and not scored_gaps
            assert decision["coverage"] == "incomplete"
            return None, {"attempts_checked": len(seen)}
        assert decision["coverage"] == "complete" and len(scored_gaps) == len(traces)
        chosen = decision["attempts"][decision["selected_attempt"]]
        indices = tuple(chosen["action_indices"])
        assert chosen["score"] == decision["score"]
        assert chosen["score"] == min(row["score"] for row in decision["attempts"])
        assert decision["controls"] == [list(map(float, actions[index])) for index in indices]
        assert decision["disturbances"] == [packet["external"]] * len(indices)
        state_gap = state_error(decision["states"], traces[indices])
        expected = cost(traces[indices][-1])
        terminal_gap = scaled(Q(decision["terminal_cost"]) - expected, expected)
        assert decision["terminal_cost"] == decision["total_cost"]
        optimum = min(cost(trace[-1]) for trace in traces.values())
        suboptimality = expected - optimum
        assert scaled(suboptimality, optimum) <= TOLERANCE
        assert max(state_gap, terminal_gap) <= TOLERANCE
        return indices, {
            "attempts_checked": len(seen),
            "max_scaled_score_error": float(max(scored_gaps)),
            "max_scaled_replay_error": float(state_gap),
            "scaled_terminal_cost_error": float(terminal_gap),
            "exact_finite_optimum": suboptimality == 0,
            "finite_optimum_gap": float(suboptimality),
        }

    result = {}
    initial_traces = paths(x0, 2)
    objective_gap = cost_gap_for_all_paths(initial_traces)
    assert objective_gap <= TOLERANCE
    for profile in PROFILES:
        data = packet["outcomes"][profile]
        open_loop = data["open_loop"]
        feedback = data["feedback"]
        first, first_audit = verify_attempts(open_loop, initial_traces)
        item = {
            "open_loop": open_loop["status"],
            "feedback": feedback["status"],
            "first": first_audit,
        }
        if first is None:
            assert feedback["status"] == "initial-solve-unavailable"
            assert not feedback["applied_controls"]
            item["diagnostics"] = sorted(
                {d["field"] for row in open_loop["attempts"] for d in row["diagnostics"]}
            )
        else:
            assert feedback["applied_controls"][0] == open_loop["controls"][0]
            observed = tuple(map(Q, feedback["observed_states"][1]))
            assert state_error(feedback["observed_states"][:2], initial_traces[first][:2]) <= TOLERANCE
            tail_traces = paths(observed, 1)
            final, tail_audit = verify_attempts(feedback["replan"], tail_traces)
            assert final is not None and feedback["status"] == "selected"
            assert feedback["applied_controls"][1:] == feedback["replan"]["controls"]
            assert feedback["terminal_cost"] == feedback["replan"]["terminal_cost"]
            mismatch = state_error(feedback["observed_states"][1:], tail_traces[final])
            assert mismatch <= TOLERANCE
            item["second"] = tail_audit
            item["replanned_control_changed"] = final[0] != first[1]
            item["executed_indices"] = [first[0], final[0]]
        result[profile] = item
    return {"dimension": len(x0), "max_scaled_objective_formula_error": float(objective_gap),
            "profiles": result}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("raw", type=Path)
    parser.add_argument("audit", type=Path)
    args = parser.parse_args()
    reference = json.loads((ROOT / "reference.json").read_bytes())
    processes = json.loads((args.raw / "process-outcomes.json").read_bytes())
    assert len(reference) == len(processes) == 35
    results = {}
    for number, item in reference.items():
        assert processes[number]["status"] == "completed"
        packet = json.loads((args.raw / f"{number}.json").read_bytes())
        results[number] = audit(packet, item)
    counts = {
        profile: dict(Counter(item["profiles"][profile]["feedback"] for item in results.values()))
        for profile in PROFILES
    }
    args.audit.write_text(json.dumps({"models": results, "feedback_counts": counts}, indent=2) + "\n")
    print(json.dumps(counts, sort_keys=True))


if __name__ == "__main__":
    main()
