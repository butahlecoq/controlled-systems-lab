"""Plot the planar section of the native SDK regression."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    plt.rcParams.update(
        {"font.family": "DejaVu Sans", "font.size": 12, "svg.hashsalt": "sdk26-diagonal-box"}
    )
    fig, ax = plt.subplots(figsize=(8.4, 5.5), layout="constrained")
    fig.patch.set_facecolor("#faf9f4")
    x, y = np.meshgrid(np.linspace(-2.25, 1.25, 240), np.linspace(-1.26, 1.26, 200))
    values = x**2 + 3*x + 2*y**2 - 1
    contours = ax.contourf(x, y, values, levels=np.arange(-3.5, 8.1, 0.5), cmap="viridis")
    colors = fig.colorbar(contours, ax=ax, pad=0.03)
    colors.set_label("Terminal objective")
    ax.plot([-2, 1, 1, -2, -2], [-1, -1, 1, 1, -1], c="#202a32", lw=2, label="Terminal box")
    ax.scatter([-2, -2, 1], [-1, 1, 1], s=80, facecolor="#faf9f4",
               edgecolor="#202a32", zorder=3)
    ax.scatter([1], [-1], marker="*", s=245, color="#ffbe3c",
               edgecolor="#202a32", zorder=4, label="Selected maximizing corner")
    annotations = (
        (-2, -1, "−1", (9, 7)),
        (-2, 1, "−1", (9, -18)),
        (1, 1, "5 · tied", (-63, -18)),
        (1, -1, "5 · selected", (-83, 10)),
    )
    for px, py, value, shift in annotations:
        ax.annotate(value, (px, py), shift, textcoords="offset points",
                    bbox={"facecolor": "#fcfbf8", "alpha": 0.93, "edgecolor": "none", "pad": 1.5})
    ax.set(
        xlabel="State coordinate x₁",
        ylabel="State coordinate x₂",
        title="A diagonal objective needs one terminal corner",
        xlim=(-2.25, 1.25),
        ylim=(-1.28, 1.28),
    )
    ax.legend(loc="center left", framealpha=0.96)
    fig.supxlabel("Planar section x₃ = 3. Both right-hand corners attain the maximum.", fontsize=11)
    root = Path(__file__).resolve().parent
    fig.savefig(root / "terminal-box-corner.svg", metadata={"Date": None})
    fig.savefig(root / "terminal-box-corner.png", dpi=145)


if __name__ == "__main__":
    main()
