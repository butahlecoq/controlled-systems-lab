"""Independently verify exact witnesses and support upper bounds from archived models."""

import copy
import json
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HORIZON = 3


def parse_vector(data):
    return tuple(map(Fraction, data))


def parse_matrix(data):
    rows, cols = data["rows"], data["cols"]
    values = parse_vector(data["values"])
    assert len(values) == rows * cols
    return tuple(values[i * cols : (i + 1) * cols] for i in range(rows))


def dot(row, vector):
    return sum(
        coefficient * value
        for coefficient, value in zip(row, vector, strict=True)
        if coefficient and value
    )


def matvec(A, vector):
    return tuple(dot(row, vector) for row in A)


def vector_sum(*parts):
    return tuple(map(sum, zip(*parts, strict=True)))


def prepare(data):
    A, B, G = (parse_matrix(data[key]) for key in ("A", "B", "G"))
    assert len(data["external"]) == HORIZON
    drift = [
        vector_sum(parse_vector(data["offset"]), matvec(G, parse_vector(w)))
        for w in data["external"]
    ]
    center = [parse_vector(data["initial"])]
    for step in drift:
        center.append(vector_sum(matvec(A, center[-1]), step))
    radius = tuple(max(Fraction(1), abs(x)) / 10 for x in center[-1])
    return A, B, drift, center, radius


def check_case(row, expected, model, plane, basis):
    A, B, drift, center, radius = model
    Bt = tuple(zip(*B, strict=True))
    k = row["stage"]
    assert 0 <= k <= HORIZON
    assert (k, row["direction"]) == (expected["stage"], expected["direction"])
    first, second = parse_vector(row["direction"])
    d = [Fraction(0)] * len(A)
    d[plane[0]], d[plane[1]] = first, second
    alpha = [
        tuple(first * x + second * y for x, y in zip(left, right, strict=True))
        for left, right in zip(*basis, strict=True)
    ]
    assert tuple(d) == alpha[0]
    steps = HORIZON - k
    terminal_gain = sum(r * abs(y) for r, y in zip(radius, alpha[steps], strict=True))
    action_gain = sum(sum(map(abs, matvec(Bt, alpha[j]))) for j in range(1, steps + 1))
    upper = dot(d, center[k]) + terminal_gain + action_gain
    assert len(row["controls"]) == steps
    start = parse_vector(row["state"])
    state = start
    for j, action in enumerate(row["controls"], k):
        u = parse_vector(action)
        assert len(u) == len(Bt) and all(-1 <= x <= 1 for x in u)
        state = vector_sum(matvec(A, state), matvec(B, u), drift[j])
    assert all(
        abs(x - c) <= r for x, c, r in zip(state, center[-1], radius, strict=True)
    )
    assert dot(d, start) == Fraction(row["support"]) == upper


def verify(data, certificate):
    assert certificate["model_id"] == data["model_id"]
    assert certificate["schema"] == "csl.archived-exact-predecessor-certificate/1"
    assert certificate["status"] == "certificate-candidate"
    assert certificate["plane"] == data["plane"]
    model = prepare(data)
    A, _, _, center, radius = model
    assert parse_vector(certificate["target_center"]) == center[-1]
    assert parse_vector(certificate["target_radius"]) == radius
    At = tuple(zip(*A, strict=True))
    basis = tuple(
        tuple(map(parse_vector, series)) for series in certificate["dual_basis"]
    )
    assert len(basis) == len(data["plane"]) == 2
    for axis, series in zip(data["plane"], basis, strict=True):
        assert len(series) == HORIZON + 1
        assert series[0] == tuple(Fraction(int(j == axis)) for j in range(len(A)))
        for left, right in zip(series[:-1], series[1:], strict=True):
            assert matvec(At, right) == left
    expected = data["full_history"]["samples"]
    assert len(certificate["samples"]) == len(expected) == 32
    for row, original in zip(certificate["samples"], expected, strict=True):
        check_case(row, original, model, data["plane"], basis)
    return model, basis


def main():
    # Exact factors for dense transitions can exceed Python's default decimal limit.
    sys.set_int_max_str_digits(12000)
    records = {}
    mutation_detected = False
    for number in range(1, 36):
        source = json.loads((ROOT / f"input/raw/{number}.json").read_bytes())
        exit_code = int((ROOT / f"results/{number}.exit").read_text())
        assert exit_code == 0, (number, exit_code)
        certificate = json.loads((ROOT / f"results/{number}.json").read_bytes())
        model, basis = verify(source, certificate)
        if number == 28:
            row = copy.deepcopy(certificate["samples"][0])
            row["support"] = str(Fraction(row["support"]) + 1)
            try:
                check_case(
                    row,
                    source["full_history"]["samples"][0],
                    model,
                    source["plane"],
                    basis,
                )
            except AssertionError:
                mutation_detected = True
            else:
                raise AssertionError("checker accepted a tampered support")
        records[str(number)] = {
            "model_id": source["model_id"],
            "states": source["A"]["rows"],
            "status": "all-sampled-supports-exact",
            "count": len(certificate["samples"]),
        }
    assert mutation_detected
    print(
        json.dumps(
            {
                "models": len(records),
                "checked_supports": sum(row["count"] for row in records.values()),
                "tampered_support_rejected": mutation_detected,
                "records": records,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
