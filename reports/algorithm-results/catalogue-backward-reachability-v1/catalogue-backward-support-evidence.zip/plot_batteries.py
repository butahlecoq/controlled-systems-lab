"""Plot all four exact battery projections and a terminal-optimal witness."""

import json
from fractions import Fraction
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle

from verify_predecessor import matvec, prepare, vector_sum

ROOT = Path(__file__).resolve().parent
COLORS = {"forward": "#278D98", "backward": "#AA5830", "intersection": "#8F68B6"}


def radii(case, axes, center):
    supports = {tuple(row["direction"]): Fraction(row["support"]) for row in case}
    for axis, d in enumerate(axes):
        assert (
            supports[d] - center[axis] == supports[tuple(-x for x in d)] + center[axis]
        )
    return tuple(supports[d] - x for d, x in zip(axes, center, strict=True))


def draw_box(ax, center, radius, **options):
    x, y = map(float, center)
    dx, dy = map(float, radius)
    ax.add_patch(Rectangle((x - dx, y - dy), 2 * dx, 2 * dy, **options))


def main():
    raw = json.loads((ROOT / "input/raw/5.json").read_bytes())
    report = json.loads((ROOT / "results/5.json").read_bytes())
    A, B, drift, center, target_radius = prepare(raw)
    axes = ((1, 0), (0, 1))
    assert A == axes and raw["plane"] == [0, 1]
    assert all(not any(step) for step in drift)
    assert all(not (a and b) for a, b in zip(*B, strict=True))
    increments = tuple(sum(map(abs, row)) for row in B)
    forward = [tuple(k * value for value in increments) for k in range(4)]
    backward = []
    intersections = []
    for k in range(4):
        samples = [row for row in report["samples"] if row["stage"] == k]
        b = radii(samples, axes, center[k])
        closed_form = tuple(
            r + (3 - k) * h for r, h in zip(target_radius, increments, strict=True)
        )
        assert b == closed_form
        backward.append(b)
        intersections.append(tuple(map(min, forward[k], b)))

    # The coordinates are independently controllable. The upper corner maximizes x1+x2.
    goal = vector_sum(center[-1], intersections[-1])
    controls = tuple(
        sum(
            (int(b > 0) - int(b < 0)) * radius / (3 * increment)
            for b, radius, increment in zip(
                col, intersections[-1], increments, strict=True
            )
        )
        for col in zip(*B, strict=True)
    )
    assert all(-1 <= u <= 1 for u in controls)
    states = [center[0]]
    for k in range(3):
        states.append(vector_sum(matvec(A, states[-1]), matvec(B, controls), drift[k]))
    assert states[-1] == goal
    for k, state in enumerate(states):
        assert all(
            abs(x - c) <= r
            for x, c, r in zip(state, center[k], intersections[k], strict=True)
        )

    fig, panels = plt.subplots(
        2, 2, figsize=(9.6, 8.2), sharex=True, sharey=True, layout="constrained"
    )
    xs, ys = zip(*(tuple(map(float, state)) for state in states), strict=True)
    for k, ax in enumerate(panels.flat):
        draw_box(
            ax,
            center[-1],
            target_radius,
            fill=False,
            linewidth=1.0,
            linestyle=":",
            edgecolor="#333944",
            zorder=1,
        )
        draw_box(
            ax,
            center[k],
            backward[k],
            fill=False,
            linewidth=2,
            linestyle="--",
            edgecolor=COLORS["backward"],
            zorder=2,
        )
        if k:
            draw_box(
                ax,
                center[k],
                intersections[k],
                linewidth=0.0,
                facecolor=COLORS["intersection"],
                alpha=0.28,
                zorder=3,
            )
            draw_box(
                ax,
                center[k],
                forward[k],
                fill=False,
                linewidth=1.8,
                edgecolor=COLORS["forward"],
                zorder=4,
            )
        ax.plot(xs, ys, color="#232933", linewidth=1.15, alpha=0.55, zorder=5)
        ax.scatter(xs[k], ys[k], color="#232933", zorder=6)
        ax.set(title=f"Stage {k}", xlim=(19.75, 40.25), ylim=(55.75, 84.25))
        ax.grid(alpha=0.2)
    fig.suptitle(
        "Battery pair · forward and backward reachable sets", fontweight="bold"
    )
    for ax in panels[-1]:
        ax.set_xlabel("Battery 1 energy (MWh)")
    fig.supylabel("Battery 2 energy (MWh)")
    fig.legend(
        handles=[
            Line2D([], [], color=COLORS["forward"], label="Forward"),
            Line2D([], [], color=COLORS["backward"], linestyle="--", label="Backward"),
            Patch(color=COLORS["intersection"], alpha=0.28, label="Intersection"),
            Line2D([], [], color="#333944", linestyle=":", label="Terminal target"),
            Line2D(
                [], [], color="#232933", marker="o", label="Terminal-optimal trajectory"
            ),
        ],
        ncols=3,
        loc="outside lower center",
        fontsize=9,
    )
    matplotlib.rcParams["svg.hashsalt"] = "csl-battery-exact-predecessor"
    fig.savefig(ROOT / "battery-forward-backward.svg", metadata={"Date": None})
    fig.savefig(ROOT / "battery-forward-backward.png", dpi=155)
    print(
        json.dumps(
            {
                "terminal_linear_objective": "maximize x1+x2",
                "terminal_state": [str(x) for x in goal],
                "terminal_value": str(sum(goal)),
                "per_stage_control": [str(u) for u in controls],
                "stages": [
                    {
                        "k": k,
                        "center": [str(x) for x in center[k]],
                        "forward_halfwidth": [str(x) for x in forward[k]],
                        "backward_halfwidth": [str(x) for x in backward[k]],
                        "intersection_halfwidth": [str(x) for x in intersections[k]],
                        "optimal_state": [str(x) for x in states[k]],
                    }
                    for k in range(4)
                ],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
