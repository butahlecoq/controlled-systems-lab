"""Plot verified support witness hulls for the two battery charge states."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from scipy.spatial import ConvexHull

root = Path(__file__).parent
record = json.loads((root / "raw/5.json").read_bytes())
assert record["title"] == "Battery pair" and record["plane"] == [0, 1]
fig, ax = plt.subplots(figsize=(7.4, 5.5), layout="constrained")
palette = ["#278185", "#7956a5", "#bf492b"]
for k, colour in enumerate(palette, start=1):
    for profile, dashed in (("intervals_only", True), ("full_history", False)):
        points = np.asarray(
            [
                sample["primal"][k * 2 : (k + 1) * 2]
                for sample in record[profile]["samples"]
                if sample["stage"] == k and sample["status"] == "optimal"
            ]
        )
        hull = ConvexHull(points)
        x, y = points[np.r_[hull.vertices, hull.vertices[0]]].T
        ax.plot(x, y, color=colour, ls="--" if dashed else "-", lw=1.8)
        if not dashed:
            ax.fill(x, y, color=colour, alpha=0.11)
ax.scatter(*record["initial"], zorder=5, color="#222735", s=35)
handles = [
    Line2D([], [], color=colour, label=f"Stage {k}")
    for k, colour in enumerate(palette, start=1)
]
handles += [
    Line2D([], [], color="#222735", marker="o", linestyle="", label="Initial state"),
    Line2D([], [], color="#222735", label="Full constraints"),
    Line2D([], [], color="#222735", linestyle="--", label="Control intervals only"),
]
fig.legend(handles=handles, ncols=3, loc="outside lower center", frameon=False)
ax.set_title("Battery pair · feasible history projections", loc="left", weight="bold")
ax.set_xlabel("Battery 1 energy (MWh)")
ax.set_ylabel("Battery 2 energy (MWh)")
ax.grid(alpha=0.2)
matplotlib.rcParams["svg.hashsalt"] = "csl-catalogue-history-projection"
fig.savefig(root / "battery-history-projections.svg", metadata={"Date": None})
fig.savefig(root / "battery-history-projections.png", dpi=145)
