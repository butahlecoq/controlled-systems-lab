"""Verify a literal upper bound contradicts the station-one floor at stage three."""

import json
from fractions import Fraction
from pathlib import Path

root = Path(__file__).parent
record = json.loads((root / "raw/9.json").read_bytes(), parse_float=Fraction)
assert record["model_id"] == "catalogue-2026/model-9/1"
assert record["A"]["values"][:3] == [1, 0, 0]
assert record["G"]["values"][:3] == [1, 0, 0]
assert record["B"]["values"][:2] == [-1, 0]
x0 = record["initial"][0]
offset = record["offset"][0]
maximum = x0 + sum(
    offset + w[0] - bounds[0][0]
    for w, bounds in zip(
        record["external"], record["constraints"]["control"], strict=True
    )
)
minimum = record["constraints"]["state"][3][0][0]
assert (maximum, minimum) == (-3, 0)
print(
    json.dumps(
        {
            "model": record["model_id"],
            "stage": 3,
            "coordinate": 0,
            "upper_from_dynamics": int(maximum),
            "required_lower": int(minimum),
        },
        indent=2,
    )
)
