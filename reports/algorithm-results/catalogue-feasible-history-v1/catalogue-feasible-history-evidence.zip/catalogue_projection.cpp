#include <array>
#include <csl/adapters/convex/highs.hpp>
#include <csl/adapters/lp/highs.hpp>
#include <csl/controllers/discrete_mpc.hpp>
#include <csl/optimization/linear_program.hpp>
#include <csl/registry/registry.hpp>

#include <nlohmann/json.hpp>

#include <algorithm>
#include <cmath>
#include <iostream>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <variant>

namespace {
using namespace csl;
using namespace csl::controllers;
using namespace csl::optimization;
using Json = nlohmann::json;
constexpr std::size_t horizon = 3;

Json diagnostics(const Diagnostics &values) {
  auto result = Json::array();
  for (const auto &value : values)
    result.push_back(
        {{"field", value.field}, {"explanation", value.explanation}});
  return result;
}

Json optional_scalar(const std::optional<double> &value) {
  return value ? Json(*value) : Json(nullptr);
}

Json matrix(const Matrix &value) {
  return {{"rows", value.rows}, {"cols", value.cols}, {"values", value.values}};
}

Json intervals(const std::vector<Interval> &values) {
  auto result = Json::array();
  for (const auto &value : values)
    result.push_back(Json::array(
        {optional_scalar(value.lower), optional_scalar(value.upper)}));
  return result;
}

Json constraints(const NominalMpcTask &task) {
  auto result = Json{{"state", Json::array()},
                     {"control", Json::array()},
                     {"stage", Json::array()},
                     {"positive_part", Json::array()},
                     {"terminal", Json::array()}};
  for (const auto &bounds : task.state_bounds)
    result["state"].push_back(intervals(bounds));
  for (const auto &bounds : task.control_bounds)
    result["control"].push_back(intervals(bounds));
  for (const auto &rows : task.stage_constraints)
    result["stage"].push_back({{"state", matrix(rows.state_map)},
                               {"control", matrix(rows.control_map)},
                               {"external", matrix(rows.external_map)},
                               {"bounds", intervals(rows.bounds)}});
  for (const auto &budgets : task.control_positive_part_budgets) {
    auto entries = Json::array();
    for (const auto &budget : budgets)
      entries.push_back(
          {{"indices", budget.control_indices}, {"upper", budget.upper_bound}});
    result["positive_part"].push_back(std::move(entries));
  }
  for (const auto &row : task.terminal_state_constraints)
    result["terminal"].push_back(
        {{"state", matrix(row.state_map)}, {"bounds", intervals(row.bounds)}});
  return result;
}

struct Fixture {
  AuthoredTaskChoices choices;
  Vector target, state_weights, control_weights;
};

Fixture make_fixture(const model::catalogue::DiscreteModelData &model, int id) {
  const auto nx = model.coefficients.A.rows;
  const auto nu = model.coefficients.B.cols;
  const auto nw = model.coefficients.E.cols;
  Fixture fixture;
  auto &choices = fixture.choices;
  const std::string prefix =
      "catalogue-model-" + std::to_string(id) + "-matched-three";
  choices.problem_id = {prefix + "/1"};
  choices.program_id = {prefix + "-nominal-qp/1"};
  choices.profile_id = prefix + "/1";
  choices.objective_id = "authored-scale-relative-quadratic/1";
  choices.horizon_id = "authored-fixed-three-transitions/1";
  choices.final_stage = horizon;
  fixture.target = model.initial_state;
  fixture.target[0] += .1 * std::max(1., std::abs(fixture.target[0]));
  fixture.control_weights.assign(nu, .05);
  Matrix q{nx, nx, Vector(nx * nx, 0.)};
  Matrix r{nu, nu, Vector(nu * nu, 0.)};
  Vector linear(nx);
  double offset = 0.;
  for (std::size_t i = 0; i < nx; ++i) {
    const double scale = std::max(1., std::abs(model.initial_state[i]));
    const double weight = 1. / (scale * scale);
    fixture.state_weights.push_back(weight);
    q.values[i * nx + i] = weight;
    linear[i] = -weight * fixture.target[i];
    offset += .5 * weight * fixture.target[i] * fixture.target[i];
  }
  for (std::size_t i = 0; i < nu; ++i)
    r.values[i * nu + i] = fixture.control_weights[i];
  choices.running_costs.assign(horizon, {q, Matrix{nx, nu, Vector(nx * nu, 0.)},
                                         r, linear, Vector(nu, 0.), offset});
  for (std::size_t i = 0; i < nx; ++i) {
    q.values[i * nx + i] *= 2.;
    linear[i] *= 2.;
  }
  choices.terminal_cost = {q, linear, 2. * offset};
  const auto external = model.nominal_external.value_or(Vector(nw, 0.));
  choices.forecast_external.assign(horizon, external);
  choices.replay_external = choices.forecast_external;
  choices.forecast_id = model.nominal_external ? "catalogue-nominal-external/1"
                                               : "authored-zero-external/1";
  choices.replay_id = "forecast-matched-replay/1";
  if (id == 4 || id == 9 || id == 10)
    choices.domain_choice = DomainChoice::explicit_continuous_relaxation;
  if (id == 3 || id == 11 || id == 18 || id == 31)
    choices.arrival_availability = ArrivalAvailability::before_decision;
  if (id == 24 || id == 25 || id == 27) {
    choices.domain_choice = DomainChoice::authored_continuous_domain;
    choices.authored_state_bounds = std::vector<Interval>(nx);
    for (std::size_t i = 0; i < nx; ++i) {
      const double limit = 10. * std::max(1., std::abs(model.initial_state[i]));
      choices.authored_state_bounds->at(i) = {-limit, limit};
    }
    choices.authored_control_bounds =
        std::vector<Interval>(nu, Interval{-1., 1.});
  }
  return fixture;
}

template <class T, class... Errors> T take(std::variant<T, Errors...> value) {
  if (auto *result = std::get_if<T>(&value))
    return std::move(*result);
  throw std::runtime_error("Unexpected operation refusal");
}

const char *label(MathematicalOutcome outcome) {
  switch (outcome) {
  case MathematicalOutcome::optimal:
    return "optimal";
  case MathematicalOutcome::infeasible:
    return "infeasible";
  case MathematicalOutcome::unbounded:
    return "unbounded";
  case MathematicalOutcome::infimum_not_attained:
    return "infimum-not-attained";
  case MathematicalOutcome::undetermined:
    return "undetermined";
  }
  return "unknown";
}

Json solve_profiles(const NominalMpcTask &task,
                    std::array<std::size_t, 2> plane,
                    const registry::Registration<registry::LPPort> &provider,
                    const ExecutionContext &context) {
  auto compiled = compile_mpc_decision(task, StageIndex{0}, task.initial.point);
  if (const auto *errors = std::get_if<Diagnostics>(&compiled))
    return {{"status", "compile-refused"},
            {"diagnostics", diagnostics(*errors)}};
  if (const auto *stop = std::get_if<OperationStopped>(&compiled))
    return {{"status", "compile-stopped"}, {"diagnostics", stop->diagnostics}};
  const auto &result = std::get<CompiledNominalQuadraticHistory>(compiled);
  const auto &qp = result.program.quadratic_program();
  const auto descriptor = qp.constraints().descriptor();
  const auto &csr = std::get<numeric::CsrInput>(descriptor);
  LinearProgramInput input{
      result.program.identity(),
      Vector(result.layout.total_variable_count),
      0.,
      {csr.rows,
       csr.cols,
       {csr.row_offsets.begin(), csr.row_offsets.end()},
       {csr.column_indices.begin(), csr.column_indices.end()},
       {csr.values.begin(), csr.values.end()}},
      {qp.variables().begin(), qp.variables().end()},
      {qp.rows().begin(), qp.rows().end()}};
  auto samples = Json::array();
  constexpr std::array<std::array<double, 2>, 8> directions{{{1., 0.},
                                                             {1., 1.},
                                                             {0., 1.},
                                                             {-1., 1.},
                                                             {-1., 0.},
                                                             {-1., -1.},
                                                             {0., -1.},
                                                             {1., -1.}}};
  for (std::size_t k = 0; k <= task.final_stage; ++k) {
    const auto first = result.layout.state_index(k, plane[0]).value();
    const auto second = result.layout.state_index(k, plane[1]).value();
    for (const auto &d : directions) {
      input.objective[first] = -d[0];
      input.objective[second] = -d[1];
      const auto lp = take(make_linear_program(input));
      auto work = provider.factory(lp);
      if (!work)
        throw std::runtime_error("LP workspace construction returned empty");
      const auto outcome = work->solve(lp, context);
      auto row = Json{{"stage", k}, {"direction", d}};
      if (const auto *refusal = std::get_if<Unsupported>(&outcome)) {
        row["status"] = "unsupported";
        row["diagnostics"] = diagnostics(refusal->diagnostics);
      } else {
        const auto &solved = std::get<ProgramResult>(outcome);
        row["status"] = label(solved.outcome.value);
        row["termination"] = static_cast<int>(solved.termination);
        row["diagnostics"] = solved.raw_diagnostics;
        if (solved.outcome.value == MathematicalOutcome::optimal &&
            solved.primal) {
          const auto &x = *solved.primal;
          row["support"] = d[0] * x[first] + d[1] * x[second];
          row["primal"] = x;
        }
      }
      samples.push_back(std::move(row));
      input.objective[first] = input.objective[second] = 0.;
    }
  }
  return {{"status", "attempted"},
          {"rows", csr.rows},
          {"cols", csr.cols},
          {"auxiliary_variables", result.layout.auxiliary_variable_count},
          {"samples", samples}};
}

Json run(int id) {
  const auto key = "catalogue-2026/model-" + std::to_string(id) + "/1";
  const auto model = take(model::catalogue::make_discrete_model(key));
  auto fixture = make_fixture(model, id);
  const auto suffix = std::to_string(id) + "-three/1";
  fixture.choices.problem_id = {"catalogue-feasible-history-" + suffix};
  fixture.choices.program_id = {"catalogue-feasible-history-projection-" +
                                suffix};
  fixture.choices.profile_id = "catalogue-feasible-history-" + suffix;
  const auto admitted = make_source_task_profile(key, fixture.choices);
  if (const auto *errors = std::get_if<Diagnostics>(&admitted))
    return {{"model_id", key},
            {"status", "profile-refused"},
            {"diagnostics", diagnostics(*errors)}};
  if (const auto *deferred = std::get_if<DeferredTask>(&admitted))
    return {{"model_id", key},
            {"status", "profile-deferred"},
            {"diagnostics", deferred->reason}};
  const auto &task = std::get<NominalMpcTask>(admitted);
  auto intervals_only = task;
  intervals_only.program_id = {
      "catalogue-control-interval-history-projection-" + suffix};
  intervals_only.state_bounds.assign(task.final_stage + 1, {});
  intervals_only.stage_constraints.clear();
  intervals_only.control_positive_part_budgets.clear();
  intervals_only.terminal_state_constraints.clear();
  const auto provider = take(adapters::lp::make_highs_registration());
  const ExecutionContext ctx{
      std::make_shared<const ResourcePolicy>(ResourcePolicy{1, 1, 1, {}}),
      {},
      {},
      {1e-8, 1e-8},
      "catalogue-feasible-history"};
  const std::array<std::size_t, 2> plane =
      id == 26 ? std::array<std::size_t, 2>{27, 28}
               : std::array<std::size_t, 2>{0, 1};
  return {
      {"model_id", key},
      {"status", "attempted"},
      {"title", model.info.title},
      {"plane", plane},
      {"profile", task.provenance.profile_id},
      {"domain", task.provenance.domain_choice},
      {"forecast", task.provenance.forecast_id},
      {"source", task.provenance.source_reference},
      {"backend", provider.identity.id.value},
      {"backend_version", provider.identity.version},
      {"A", matrix(model.coefficients.A)},
      {"B", matrix(model.coefficients.B)},
      {"G", matrix(model.coefficients.E)},
      {"offset", model.coefficients.offset},
      {"initial", task.initial.point},
      {"external", task.forecast_external},
      {"constraints", constraints(task)},
      {"intervals_only", solve_profiles(intervals_only, plane, provider, ctx)},
      {"full_history", solve_profiles(task, plane, provider, ctx)}};
}
} // namespace

int main(int argc, char **argv) try {
  if (argc != 2)
    throw std::runtime_error("Usage: catalogue_projection MODEL_NUMBER");
  std::cout << run(std::stoi(argv[1])).dump() << '\n';
} catch (const std::exception &e) {
  std::cerr << e.what() << '\n';
  return 1;
}
