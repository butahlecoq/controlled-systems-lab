"""Bound all 36 added platoon rows over the control intervals in exact arithmetic."""

import json
from fractions import Fraction
from itertools import chain
from pathlib import Path

path = Path(__file__).resolve().parent / "raw/26.json"
data = json.loads(path.read_bytes(), parse_float=lambda value: Fraction(float(value)))


def matrix(meta):
    return [
        meta["values"][i : i + meta["cols"]]
        for i in range(0, len(meta["values"]), meta["cols"])
    ]


def dot(a, b):
    return sum(x * y for x, y in zip(a, b, strict=True))


def left_apply(left, block):
    return [
        sum(row[j] * coef for coef, row in zip(left, block, strict=True))
        for j in range(len(block[0]))
    ]


assert data["model_id"] == "catalogue-2026/model-26/1"
assert all(not row for row in data["constraints"]["positive_part"])
assert all(
    bound == [None, None] for row in data["constraints"]["state"] for bound in row
)
A, B, G = (matrix(data[key]) for key in ("A", "B", "G"))
control = data["constraints"]["control"]
intervals = list(chain.from_iterable(control))
assert len(intervals) == 30 and all(bound == [-3, 2] for bound in intervals)
m = len(B[0])
drift = data["initial"]
from_input = [[0] * len(intervals) for _ in drift]
minimum_slacks = []
stages = [
    (
        matrix(row["state"]),
        matrix(row["control"]),
        matrix(row["external"]),
        row["bounds"],
    )
    for row in data["constraints"]["stage"]
]
last = data["constraints"]["terminal"]
assert len(last) == 1
stages.append(
    (matrix(last[0]["state"]), [[0] * m] * 9, [[0] * len(G[0])] * 9, last[0]["bounds"])
)
external = [*data["external"], [0] * len(G[0])]
for stage, (Hx, Hu, Hw, bounds) in enumerate(stages):
    assert len(bounds) == 9
    slacks = []
    for x, u, w, (lower, upper) in zip(Hx, Hu, Hw, bounds, strict=True):
        assert lower is not None and upper is None
        coeffs = left_apply(x, from_input)
        for i, weight in enumerate(u):
            if weight:
                coeffs[stage * m + i] += weight
        smallest = (
            dot(x, drift)
            + dot(w, external[stage])
            + sum(
                value * (lo if value >= 0 else hi)
                for value, (lo, hi) in zip(coeffs, intervals, strict=True)
            )
        )
        slacks.append(smallest - lower)
    minimum_slacks.append(min(slacks))
    if stage < len(control):
        drift = [
            dot(a, drift) + dot(g, external[stage]) + c
            for a, g, c in zip(A, G, data["offset"], strict=True)
        ]
        from_input = [left_apply(a, from_input) for a in A]
        for row, b in zip(from_input, B, strict=True):
            row[stage * m : (stage + 1) * m] = b
assert all(s > 0 for s in minimum_slacks)
print(
    json.dumps(
        {
            "model": data["model_id"],
            "checked_rows": sum(len(s[-1]) for s in stages),
            "minimum_slack_by_stage_m": [float(x) for x in minimum_slacks],
            "exact_minimum_slack_m": str(min(minimum_slacks)),
        },
        indent=2,
    )
)
