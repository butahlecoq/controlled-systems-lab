"""Independently condense state dynamics and check every native support witness."""

import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

HORIZON = 3
TOL = 1e-7


def matrix(mat):
    return np.array(mat["values"], dtype=float).reshape(mat["rows"], mat["cols"])


def independent_history(model, full):
    A, B, G = (matrix(model[key]) for key in ("A", "B", "G"))
    nx, nu = B.shape
    external = np.asarray(model["external"])
    constraints = model["constraints"]
    budgets = constraints["positive_part"] if full else [[] for _ in range(HORIZON)]
    control_count = HORIZON * nu
    total = control_count + sum(
        len(group["indices"]) for stage in budgets for group in stage
    )
    fixed = [np.array(model["initial"], dtype=float)]
    map_to_state = [np.zeros((nx, total))]
    variable_bounds = []
    rows, upper = [], []

    def add(lhs, drift, interval):
        low, high = interval
        if low is not None:
            rows.append(-lhs)
            upper.append(drift - low)
        if high is not None:
            rows.append(lhs)
            upper.append(high - drift)

    next_aux = control_count
    for k in range(HORIZON):
        control = np.zeros((nu, total))
        control[:, k * nu : (k + 1) * nu] = np.eye(nu)
        variable_bounds.extend(constraints["control"][k])
        if full and constraints["stage"]:
            stage = constraints["stage"][k]
            Hx, Hu, Hw = (
                matrix(stage[key]) for key in ("state", "control", "external")
            )
            F = Hx @ map_to_state[k] + Hu @ control
            known = Hx @ fixed[k] + Hw @ external[k]
            for lhs, drift, limits in zip(F, known, stage["bounds"], strict=True):
                add(lhs, drift, limits)
        for budget in budgets[k]:
            group = np.zeros(total)
            for i in budget["indices"]:
                epigraph = np.zeros(total)
                epigraph[next_aux] = 1.0
                add(control[i] - epigraph, 0.0, (None, 0.0))
                group[next_aux] = 1.0
                next_aux += 1
            add(group, 0.0, (None, budget["upper"]))
        fixed.append(A @ fixed[k] + G @ external[k] + model["offset"])
        map_to_state.append(A @ map_to_state[k] + B @ control)
    if full:
        for k, intervals in enumerate(constraints["state"]):
            for lhs, drift, limits in zip(
                map_to_state[k], fixed[k], intervals, strict=True
            ):
                add(lhs, drift, limits)
        for terminal in constraints["terminal"]:
            F = matrix(terminal["state"])
            for lhs, drift, limits in zip(
                F @ map_to_state[-1], F @ fixed[-1], terminal["bounds"], strict=True
            ):
                add(lhs, drift, limits)
    variable_bounds.extend([(0.0, None)] * (total - control_count))
    return (
        np.asarray(fixed),
        np.asarray(map_to_state),
        np.array(rows).reshape(len(rows), total),
        np.asarray(upper),
        variable_bounds,
    )


def verify(model):
    result = {}
    plane = model["plane"]
    for profile in ("full_history", "intervals_only"):
        source = model[profile]
        if source["status"] != "attempted":
            raise ValueError(f"unexpected profile refusal: {source}")
        fixed, transfer, rows, upper, bounds = independent_history(
            model, profile == "full_history"
        )
        sparse = csr_matrix(rows) if rows.shape[0] else None
        rhs = upper if rows.shape[0] else None
        nx = fixed.shape[1]
        base_count = (HORIZON + 1) * nx
        expected = [
            (k, list(d))
            for k in range(HORIZON + 1)
            for d in (
                (1, 0),
                (1, 1),
                (0, 1),
                (-1, 1),
                (-1, 0),
                (-1, -1),
                (0, -1),
                (1, -1),
            )
        ]
        native_counts, reference_counts = Counter(), Counter()
        samples = []
        for sample, (k, direction) in zip(source["samples"], expected, strict=True):
            assert [sample["stage"], sample["direction"]] == [k, direction]
            objective = np.array(direction) @ transfer[k, plane]
            origin = np.array(direction) @ fixed[k, plane]
            ref = linprog(
                -objective, A_ub=sparse, b_ub=rhs, bounds=bounds, method="highs-ipm"
            )
            checked = {
                "stage": k,
                "direction": direction,
                "native": sample["status"],
                "reference": int(ref.status),
            }
            native_counts[sample["status"]] += 1
            reference_counts[str(ref.status)] += 1
            if ref.success:
                checked["reference_support"] = float(origin - ref.fun)
            if sample["status"] == "infeasible" and ref.status != 2:
                raise ValueError(
                    f"native infeasibility disagreed: {model['model_id']} {profile} {checked}"
                )
            if sample["status"] == "unbounded" and ref.status != 3:
                raise ValueError(
                    f"native unboundedness disagreed: {model['model_id']} {profile} {checked}"
                )
            if sample["status"] == "optimal":
                assert ref.success, (model["model_id"], profile, checked)
                primal = np.asarray(sample["primal"])
                x = primal[:base_count].reshape(HORIZON + 1, nx)
                controls_with_epigraph = primal[base_count:]
                assert len(controls_with_epigraph) == len(bounds)
                predicted = fixed + transfer @ controls_with_epigraph
                residual = np.max(
                    np.abs(predicted - x) / np.maximum(1.0, np.abs(predicted))
                )
                if len(upper):
                    violation = (rows @ controls_with_epigraph - upper) / np.maximum(
                        1.0,
                        np.maximum(
                            np.abs(upper), np.abs(rows) @ np.abs(controls_with_epigraph)
                        ),
                    )
                    residual = max(residual, np.max(violation))
                for u, (low, high) in zip(controls_with_epigraph, bounds, strict=True):
                    if low is not None:
                        residual = max(residual, (low - u) / max(1.0, abs(low)))
                    if high is not None:
                        residual = max(residual, (u - high) / max(1.0, abs(high)))
                err = abs(sample["support"] - checked["reference_support"]) / max(
                    1.0, abs(checked["reference_support"])
                )
                readback = np.array(direction) @ predicted[k, plane]
                residual = max(
                    residual,
                    abs(readback - sample["support"]) / max(1.0, abs(readback)),
                )
                checked.update(
                    native_support=sample["support"],
                    scaled_error=float(err),
                    scaled_witness_violation=float(residual),
                )
                if max(err, residual) > TOL:
                    raise ValueError(f"{model['model_id']} {profile}: {checked}")
            samples.append(checked)
        result[profile] = {
            "native_counts": native_counts,
            "reference_counts": reference_counts,
            "samples": samples,
        }
    return result


def main(root):
    output = {}
    for id in range(1, 36):
        raw = root / "raw"
        assert int((raw / f"{id}.exit").read_text()) == 0
        model = json.loads((raw / f"{id}.json").read_bytes())
        assert (
            model["status"] == "attempted"
            and model["model_id"] == f"catalogue-2026/model-{id}/1"
        )
        output[str(id)] = verify(model)
        print(f"Checked model {id}", flush=True, file=sys.stderr)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
