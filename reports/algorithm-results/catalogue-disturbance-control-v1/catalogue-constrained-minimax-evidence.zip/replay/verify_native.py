"""Independently check native graph results against the exact policy ledger."""

import argparse
import json
from fractions import Fraction as F
from pathlib import Path


def verify(exact_file, native_file):
    native = list(map(json.loads, native_file.read_text().splitlines()))
    exact = json.loads(exact_file.read_text())["models"]
    assert len(exact) == len(native) == 70
    maximum = F(0)
    for raw, certified in zip(native, exact, strict=True):
        key = (raw["model_id"], raw["profile"])
        assert key == (certified["model_id"], certified["profile"])
        for controller in ("fixed", "causal"):
            result, check = raw[controller], certified[controller]
            if result["status"] != check["status"]:
                raise ValueError(
                    f"{key} {controller} feasibility disagrees with exact replay"
                )
            if check["status"] != "feasible":
                continue
            assert result["actions"]
            expected = F(check["exact_value"])
            gap = abs(F(result["value"]) - expected)
            maximum = max(maximum, gap)
            assert gap <= F(1, 10**12) * max(F(1), abs(expected)), (
                key,
                controller,
                gap,
            )
    return {
        "models": 35,
        "constraint_profiles": 2,
        "policy_outcomes": 140,
        "maximum_absolute_value_error": float(maximum),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("exact", type=Path)
    parser.add_argument("native", type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.exact, args.native), indent=2))
