"""Draw the exact projected queue safety obstruction for the two-transition game."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from exact_causal_oracle import matrix_product, vector, vector_sum


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    data = json.loads((root.parent / "minimax-inputs.jsonl").read_text().splitlines()[0])
    assert data["model_id"] == "catalogue-2026/model-1/1"
    # The saved actuator intervals discard action 1. Propagate the other actions
    # and every disturbance vertex to expose the later safety failure.
    actions = [matrix_product(data["B"], vector(data["actions"][i])) for i in (0, 2)]
    external = [matrix_product(data["E"], vector(w)) for w in data["disturbance_vertices"]]
    offset = vector(data["c"])
    stages = [{vector(data["x0"])}]
    for _ in range(2):
        stages.append(
            {
                vector_sum(matrix_product(data["A"], x), offset, u, w)
                for x in stages[-1]
                for u in actions
                for w in external
            }
        )
    assert [{x[2] for x in stage} for stage in stages] == [{10}, {2}, {-6}]
    matplotlib.rcParams["svg.hashsalt"] = "catalogue-source-queue-safety"
    fig, axis = plt.subplots(figsize=(7.2, 4.7), layout="constrained")
    axis.axhspan(0, 12.4, facecolor="#c7e7cf", alpha=0.5, label="Admissible in q₃")
    axis.axhline(0, color="#4a6650", linewidth=1.2, linestyle="--")
    for i, (stage, color) in enumerate(zip(stages, ("#424d58", "#276f94", "#a94322"), strict=True)):
        x = sorted({point[0] for point in stage})
        q3 = next(iter(stage))[2]
        axis.scatter(
            [float(value) for value in x],
            [float(q3)] * len(x),
            s=24,
            color=color,
            label=f"Stage {i} reachable projection",
            zorder=4,
        )
    axis.set(
        title="IP/SDN queues · terminal safety obstruction",
        xlabel="Queue 1 content q₁ (Mbit)",
        ylabel="Queue 3 content q₃ (Mbit)",
        ylim=(-8, 12.4),
    )
    axis.legend(loc="upper right")
    axis.grid(alpha=0.22)
    fig.savefig(args.output, metadata={"Date": None})


if __name__ == "__main__":
    main()
