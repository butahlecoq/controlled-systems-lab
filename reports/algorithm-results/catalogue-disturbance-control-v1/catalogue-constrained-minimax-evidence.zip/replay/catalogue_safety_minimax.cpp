#include <csl/optimization/finite_causal_minimax.hpp>
#include <nlohmann/json.hpp>

#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>

namespace {
using nlohmann::json;
namespace solver = csl::optimization::finite_causal_minimax;

solver::Stage decode_stage(const json &source) {
    solver::Stage stage{source.at("state_count").get<std::size_t>(),
                        source.at("action_count").get<std::size_t>(),
                        source.at("disturbance_count").get<std::size_t>(),
                        source.at("safe_states").get<std::vector<bool>>(),
                        {}};
    for (const auto &state : source.at("next_state")) {
        auto &edges = stage.next_state.emplace_back();
        for (const auto &action : state) {
            auto &successors = edges.emplace_back();
            for (const auto &id : action)
                successors.push_back({id.get<std::size_t>()});
        }
    }
    return stage;
}

json evaluate(const json &source) {
    const auto &target = source.at("terminal");
    const auto costs = target.at("cost").get<std::vector<double>>();
    solver::Game game{{},
                      {costs.size(), target.at("safe_states").get<std::vector<bool>>(), costs},
                      {source.at("initial_state").get<std::size_t>()}};
    for (const auto &stage : source.at("stages"))
        game.stages.push_back(decode_stage(stage));

    const auto answer = solver::solve(game, {0, 0});
    if (const auto *refusal = std::get_if<csl::Diagnostic>(&answer))
        throw std::runtime_error(refusal->field + ": " + refusal->explanation);
    const auto &best = std::get<solver::Result>(answer).initial();
    if (!best.feasible)
        return {{"status", "infeasible"}};
    std::vector<std::size_t> actions;
    for (const auto action : best.optimal_actions)
        actions.push_back(action.value);
    return {{"status", "feasible"}, {"value", best.value}, {"actions", actions}};
}
} // namespace

int main(int argc, const char *argv[]) {
    if (argc != 3) {
        std::cerr << "usage: catalogue_safety_minimax graphs.jsonl output.jsonl\n";
        return 2;
    }
    std::ifstream input(argv[1]);
    std::ofstream output(argv[2]);
    if (!input || !output)
        return 2;
    std::string line;
    while (std::getline(input, line)) {
        try {
            const auto row = json::parse(line);
            const json result = {
                {"model_id", row.at("model_id")},
                {"profile", row.at("profile")},
                {"fixed", evaluate(row.at("fixed"))},
                {"causal", evaluate(row.at("causal"))},
            };
            output << result.dump() << '\n';
        } catch (const std::exception &error) {
            std::cerr << error.what() << '\n';
            return 1;
        }
    }
    return !input.eof() || !output;
}

