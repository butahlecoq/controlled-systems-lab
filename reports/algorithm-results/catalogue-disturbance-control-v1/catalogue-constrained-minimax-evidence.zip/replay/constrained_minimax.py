"""Exact two-step safety and cost replay of the saved catalogue profiles."""

import argparse
import hashlib
import json
from collections import Counter
from fractions import Fraction as F
from io import BytesIO
from itertools import product
from pathlib import Path
from zipfile import ZipFile

from exact_causal_oracle import matrix_product, quadratic_cost, vector, vector_sum

PROFILES = ("component-bounds", "all-retained-rows")
INPUT_SHA256 = "c8b3df57fa3f1f4f6dde4c13f5cd3c8d75ab673d68e9cad49e8eb2e6a4f41212"
CONSTRAINT_SHA256 = "b393255e8c91049363a8e718e2063e04fc2f31c0f56e69e4e587a99a5926c92a"
EXTERNAL_SHA256 = "6e4b9922036cb01789ad49634ad0ce1633c29839b7eed88f3123767cdc89f725"


def matrix(record):
    return {
        "rows": record["rows"],
        "columns": record["cols"],
        "row_major": record["values"],
    }


def require_data(path, digest):
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        raise ValueError(f"saved input hash mismatch: {path.name}")
    return data


def outside(bounds, values, name):
    for i, ((lo, hi), value) in enumerate(zip(bounds, values, strict=True)):
        if (lo is not None and value < F(lo)) or (hi is not None and value > F(hi)):
            return {
                "row": name,
                "index": i,
                "value": str(value),
                "lower": lo,
                "upper": hi,
            }
    return None


def safety(c, stage, x, u, w, successor, profile):
    result = outside(c["state"][stage], x, "state")
    if result is not None:
        return result
    result = outside(c["control"][stage], u, "control")
    if result is not None:
        return result
    if profile == "all-retained-rows":
        if c["stage"]:
            mixed = c["stage"][stage]
            lhs = vector_sum(
                *(
                    matrix_product(matrix(mixed[key]), value)
                    for key, value in (("state", x), ("control", u), ("external", w))
                )
            )
            result = outside(mixed["bounds"], lhs, "mixed")
            if result is not None:
                return result
        for budget in c["positive_part"][stage]:
            value = sum(max(F(0), u[i]) for i in budget["indices"])
            result = outside([[None, budget["upper"]]], [value], "positive-part")
            if result is not None:
                return result
    result = outside(c["state"][stage + 1], successor, "successor-state")
    if result is not None:
        return result
    if profile == "all-retained-rows" and stage == 1:
        for terminal in c["terminal"]:
            result = outside(
                terminal["bounds"],
                matrix_product(matrix(terminal["state"]), successor),
                "terminal",
            )
            if result is not None:
                return result
    return None


def self_test():
    free = [[None, None]]
    constraints = {
        "state": [free] * 3,
        "control": [free * 2] * 2,
        "stage": [],
        "terminal": [],
        "positive_part": [[{"indices": [0, 1], "upper": 0.25}], []],
    }
    state = (F(0),)
    signed = (F(1, 2), F(-1, 2))
    assert (
        safety(constraints, 0, state, signed, state, state, "all-retained-rows")["row"]
        == "positive-part"
    )
    assert (
        safety(constraints, 0, state, signed, state, state, "component-bounds") is None
    )

    constraints["positive_part"] = [[], []]
    stage = {
        "bounds": [[None, 0.25]],
        "state": {"rows": 1, "cols": 1, "values": [0]},
        "control": {"rows": 1, "cols": 2, "values": [0, 0]},
        "external": {"rows": 1, "cols": 1, "values": [1]},
    }
    constraints["stage"] = [stage, stage]
    assert (
        safety(constraints, 0, state, signed, (F(1, 4),), state, "all-retained-rows")
        is None
    )
    assert (
        safety(constraints, 0, state, signed, (F(1, 2),), state, "all-retained-rows")[
            "row"
        ]
        == "mixed"
    )


def terminal_layer():
    return {"safe_states": [False], "cost": [0.0]}, {}


def add_terminal(layer, ids, value, cost):
    if value not in ids:
        ids[value] = len(layer["cost"])
        layer["cost"].append(float(cost))
        layer["safe_states"].append(True)
    return ids[value]


def feasible_cost(value):
    return (
        {"status": "feasible", "exact_value": str(value), "value": float(value)}
        if value is not None
        else {"status": "infeasible"}
    )


def graph(stages, terminal):
    return {"stages": stages, "terminal": terminal, "initial_state": 0}


def stage_record(rows, actions, disturbances, unsafe=()):
    return {
        "state_count": len(rows),
        "action_count": actions,
        "disturbance_count": disturbances,
        "safe_states": [i not in unsafe for i in range(len(rows))],
        "next_state": rows,
    }


def compare(inputs, profile):
    row, saved = inputs
    c = saved["constraints"]
    menu = list(map(vector, row["actions"]))
    words = list(map(vector, row["disturbance_vertices"]))
    all_actions = range(len(menu))
    all_disturbances = range(len(words))
    nominal = vector(row["x0"])
    offset = vector(row["c"])
    shifts = [matrix_product(row["B"], u) for u in menu]
    external = [matrix_product(row["E"], w) for w in words]

    def step(k, x, a, w):
        successor = vector_sum(
            matrix_product(row["A"], x), offset, shifts[a], external[w]
        )
        warning = safety(c, k, x, menu[a], words[w], successor, profile)
        return successor, warning

    first = [[step(0, nominal, a, w) for w in all_disturbances] for a in all_actions]
    # State ID 0 is the explicit rejecting sink. Coalesce real observations by exact equality.
    observations = {
        x: i
        for i, x in enumerate(
            sorted({x for branch in first for x, warning in branch if warning is None}),
            start=1,
        )
    }
    suffix = {
        x: [[step(1, x, a, w) for w in all_disturbances] for a in all_actions]
        for x in observations
    }
    end, terminal_ids = terminal_layer()
    costs = {}

    def outcome(transition):
        successor, warning = transition
        if warning is not None:
            return 0, None
        if successor not in costs:
            costs[successor] = quadratic_cost(row["objective"], successor)
        cost = costs[successor]
        return add_terminal(end, terminal_ids, successor, cost), cost

    first_graph = [
        [observations[x] if warning is None else 0 for x, warning in branch]
        for branch in first
    ]
    second_graph = [[[0 for _ in all_disturbances] for _ in all_actions]]
    for x, index in observations.items():
        assert index == len(second_graph)
        second_graph.append(
            [[outcome(entry)[0] for entry in branch] for branch in suffix[x]]
        )

    def evaluate_plan(a, b):
        scores, targets = [], []
        certificate = None
        for w0, w1 in product(all_disturbances, repeat=2):
            x, first_warning = first[a][w0]
            terminal = (
                (x, first_warning) if first_warning is not None else suffix[x][b][w1]
            )
            target, cost = outcome(terminal)
            targets.append(target)
            if cost is None:
                if certificate is None:
                    certificate = {
                        "disturbances": [w0, w1],
                        "stage": int(first_warning is None),
                        **terminal[1],
                    }
            else:
                scores.append(cost)
        candidate = {
            "actions": [a, b],
            **feasible_cost(None if certificate else max(scores)),
        }
        if certificate:
            candidate["first_violating_word"] = certificate
        return candidate, targets

    plan_results, fixed_graph = zip(
        *(evaluate_plan(a, b) for a, b in product(all_actions, repeat=2)), strict=True
    )
    fixed = min(
        (F(c["exact_value"]) for c in plan_results if c["status"] == "feasible"),
        default=None,
    )
    direct_options = []
    exhaustive_options = []
    for a in all_actions:
        observed = {x for x, warning in first[a] if warning is None}
        if any(warning is not None for x, warning in first[a]):
            continue
        ordered = sorted(observed)
        viable = {
            x: [
                (b, max(outcome(transition)[1] for transition in branch))
                for b, branch in enumerate(suffix[x])
                if all(warning is None for _, warning in branch)
            ]
            for x in ordered
        }
        if all(viable.values()):
            chosen = [min(viable[x], key=lambda value: value[1]) for x in ordered]
            direct_options.append(
                (
                    max(value for _, value in chosen),
                    a,
                    list(zip(ordered, chosen, strict=True)),
                )
            )

        # Independent literal policy enumeration: one action per exact observed state.
        for choices in product(all_actions, repeat=len(ordered)):
            policy = dict(zip(ordered, choices, strict=True))
            values = [
                outcome(suffix[x][policy[x]][w])[1]
                for x, _ in first[a]
                for w in all_disturbances
            ]
            if None not in values:
                exhaustive_options.append(max(values))
    causal = min((candidate[0] for candidate in direct_options), default=None)
    assert causal == min(exhaustive_options, default=None)
    assert fixed is None or (causal is not None and causal <= fixed), (
        row["model_id"],
        profile,
        fixed,
        causal,
    )

    policy = None
    if causal is not None:
        _, action, selected = min(direct_options)
        policy = {
            "first_action": action,
            "states": [
                {"x": list(map(str, x)), "action": action, "exact_value": str(value)}
                for x, (action, value) in selected
            ],
        }
    result = {
        "model_id": row["model_id"],
        "domain": saved["domain"],
        "profile": profile,
        "fixed": feasible_cost(fixed),
        "causal": feasible_cost(causal),
        "selected_policy": policy,
        "fixed_candidates": list(plan_results),
        "exact_observations": len(observations),
    }
    graphs = {
        "model_id": row["model_id"],
        "profile": profile,
        "fixed": graph(
            [stage_record([fixed_graph], len(menu) ** 2, len(words) ** 2)], end
        ),
        "causal": graph(
            [
                stage_record([first_graph], len(menu), len(words)),
                stage_record(second_graph, len(menu), len(words), unsafe=(0,)),
            ],
            end,
        ),
    }
    return result, graphs


def load_inputs(paths):
    data = require_data(paths.inputs, INPUT_SHA256)
    constraint_bytes = require_data(paths.constraints, CONSTRAINT_SHA256)
    external_bytes = require_data(paths.external, EXTERNAL_SHA256)
    centres = {
        r["model_id"]: r["external_center"]
        for r in map(json.loads, external_bytes.splitlines())
    }
    inputs = list(map(json.loads, data.splitlines()))
    assert len(inputs) == len(centres) == len({row["model_id"] for row in inputs}) == 35
    with ZipFile(BytesIO(constraint_bytes)) as archive:
        for number, row in enumerate(inputs, start=1):
            raw = json.loads(archive.read(f"raw/{number}.json"))
            model = row["model_id"]
            assert model == raw["model_id"]
            for left, right in (("A", "A"), ("B", "B"), ("E", "G")):
                assert row[left] == matrix(raw[right]), (model, left)
            assert row["c"] == raw["offset"] and row["x0"] == raw["initial"]
            assert raw["external"] == [centres[model]] * 3
            c = raw["constraints"]
            assert len(c["state"]) == 4
            assert len(c["control"]) == len(c["positive_part"]) == 3
            assert len(c["stage"]) in (0, 3)
            yield row, raw


def main():
    self_test()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", type=Path)
    parser.add_argument("constraints", type=Path)
    parser.add_argument("external", type=Path)
    parser.add_argument("output", type=Path)
    options = parser.parse_args()
    checks = []
    graphs = []
    for row in load_inputs(options):
        for profile in PROFILES:
            exact, exported = compare(row, profile)
            checks.append(exact)
            graphs.append(exported)
    results = {}
    for profile in PROFILES:
        subset = [row for row in checks if row["profile"] == profile]
        results[profile] = {
            "status_pairs": dict(
                Counter(
                    f"{row['fixed']['status']}/{row['causal']['status']}"
                    for row in subset
                )
            ),
            "strict_causal_gain": [
                row["model_id"]
                for row in subset
                if row["fixed"]["status"] == "feasible"
                and F(row["fixed"]["exact_value"]) > F(row["causal"]["exact_value"])
            ],
            "retained_rejection_rows": dict(
                Counter(
                    c["first_violating_word"]["row"]
                    for row in subset
                    for c in row["fixed_candidates"]
                    if c["status"] == "infeasible"
                )
            ),
        }
    (options.output / "results.json").write_text(
        json.dumps({"summary": results, "models": checks}, indent=2) + "\n"
    )
    (options.output / "graphs.jsonl").write_text(
        "".join(json.dumps(row) + "\n" for row in graphs)
    )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
