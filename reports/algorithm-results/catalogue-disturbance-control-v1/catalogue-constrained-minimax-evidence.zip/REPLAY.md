# Finite minimax with saved catalogue constraints

This companion uses the 35-model disturbance lesson's two-transition action menu, external vertices and terminal quadratic. The first constraint profile uses state and actuator intervals. The second adds the saved mixed rows, positive-part actuator budgets and terminal rows. The reference uses the first two stages of the saved three-transition task and applies its terminal rows at the two-transition deadline. Domain labels remain attached to each record.

For the fixed policy, the graph chooses one action pair before either external vertex acts. For the causal policy, the first disturbance acts before the second decision. Exactly equal observed states share a decision node. Every unsafe branch leads to a rejected node. Both graphs use the same native finite minimax solver, core SDK only. The exact rational oracle also enumerates every second-action assignment for each first action and checks the dynamic program.

## Reproduce

Use CMake 3.31 or later, a C++20 compiler, Python 3.12 or later and, for the figure, Matplotlib 3.11.2. Resolve the exact [CSL SDK source](https://github.com/butahlecoq/csl-sdk/tree/806738c9d1c8f1d9ebd8885b7bb605b5a698b1af) commit and tree listed in `replay/sdk-source.txt`. The SDK configures the pinned JSON headers. Run these commands in the extracted directory.

```sh
sha256sum -c SHA256SUMS
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCSL_SOURCE_DIR=/path/to/csl-sdk
cmake --build build --target catalogue_safety_minimax
mkdir -p reproduced
PYTHONPATH=causal-oracle python -B replay/constrained_minimax.py minimax-inputs.jsonl feasible-history-source.zip records.jsonl reproduced
build/catalogue_safety_minimax reproduced/graphs.jsonl reproduced/native.jsonl
python -B replay/verify_native.py reproduced/results.json reproduced/native.jsonl
PYTHONPATH=causal-oracle python -B replay/plot_queue_safety.py reproduced/queue-safety-obstruction.svg
cmp replay/queue-safety-obstruction.svg reproduced/queue-safety-obstruction.svg
sha256sum -c SHA256SUMS
```

The exact checker authenticates all three input digests and matches the initial state, matrices, offset and nominal external forecast. It evaluates each mixed row with the actual external vertex. The native verifier checks all 140 feasibility statuses and the 132 costs for feasible policies against the exact ledger. Under the recorded toolchain the reproduced graphs, rational ledger, native outcomes and SVG match the stored copies. The numeric solver consumes a finite graph with binary64 terminal values.

Both policies were feasible on 33 models and infeasible on two, under both constraint profiles. The figure shows the IP/SDN queue state projection after filtering actions by their saved intervals. The third queue is always at −6 Mbit at stage two. The upper bound of 100 Mbit is outside the plot. The other infeasible fixture, warehouse/store, violates the lower stock bound for the word (120, 132), which reaches a second coordinate of −2 under the zero-control plan. The nominal word (120, 120) stays within the bound. The saved actuator bound removes the EV charging advantage. The thirty-bank ring retains its advantage. These outcomes apply to the stated finite fixture and carry no performance or physical-calibration claim.
