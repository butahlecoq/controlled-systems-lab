"""Compare every exact native interval against the exhaustive rational oracle."""

import argparse
import json
from pathlib import Path


def verify(native, oracle):
    rows = [json.loads(line) for line in native.read_text().splitlines()]
    audits = json.loads(oracle.read_text())["results"]
    count = 0
    for produced, expected in zip(rows, audits, strict=True):
        if produced["model_id"] != expected["model_id"]:
            raise ValueError("model ID mismatch")
        for profile, certified in zip(produced["profiles"], expected["profiles"], strict=True):
            for stage, check in zip(profile, certified["stages"], strict=True):
                for field in ("linear_map", "eroded_bounds"):
                    if stage[field] != check[field]:
                        raise ValueError(f"{produced['model_id']} stage {check['stage']} mismatched {field}")
                count += len(stage["linear_map"])
    print(f"{len(rows)} models, {count} exact interval certificates")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("native", type=Path)
    parser.add_argument("oracle", type=Path)
    args = parser.parse_args()
    verify(args.native, args.oracle)

