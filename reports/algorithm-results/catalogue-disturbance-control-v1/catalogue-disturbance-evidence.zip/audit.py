"""Exact exploratory check of a fixed-plan robust terminal predecessor."""

import hashlib
import json
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path

from finite_word_reference import matrix, rational, reference, dot


def advance(a, x, shift):
    return [dot(row, x) + c for row, c in zip(a, shift, strict=True)]


def pullback(a, row):
    return [dot(col, row) for col in zip(*a, strict=True)]


def endpoint_range(a, direction, shifts):
    lower = upper = F(0)
    for choices in reversed(shifts):
        increments = [dot(direction, shift) for shift in choices]
        lower += min(increments)
        upper += max(increments)
        direction = pullback(a, direction)
    return direction, lower, upper


def satisfies(box, value):
    return all(lo <= x <= hi for (lo, hi), x in zip(box, value, strict=True))


def audit_model(row):
    a, b, e = (matrix(row[key]) for key in ("A", "B", "E"))
    x0, offset, centre = (rational(row[key]) for key in ("x0", "offset", "external_center"))
    controls = list(map(rational, row["controls"]))
    disturbances = list(map(rational, row["disturbance_vertices"]))
    assert len(controls) == 2
    assert disturbances[0] == centre

    shifts = [
        [
            [dot(b_i, u) + dot(e_i, w) + c for b_i, e_i, c in zip(b, e, offset, strict=True)]
            for w in disturbances
        ]
        for u in controls
    ]
    nominal = [x0]
    for choices in shifts:
        nominal.append(advance(a, nominal[-1], choices[0]))

    forward = reference(row)
    axes = [[F(i == j) for j in range(len(a))] for i in range(len(a))]
    geometry = []
    zero = [F(0)] * len(a)
    for k in range(len(nominal)):
        # Literal word replay independently checks the additive bounds and action order.
        endpoint_perturbations = []
        for word in product(*shifts[k:]):
            x = zero
            for shift in word:
                x = advance(a, x, shift)
            endpoint_perturbations.append(x)
        columns = []
        for basis in axes:
            image = basis
            for _ in shifts[k:]:
                image = advance(a, image, zero)
            columns.append(image)
        coefficients = []
        extrema = []
        for i, direction in enumerate(axes):
            lhs, minimum, maximum = endpoint_range(a, direction, shifts[k:])
            replay = [x[i] for x in endpoint_perturbations]
            assert lhs == [col[i] for col in columns], (row["model_id"], k, i)
            assert (minimum, maximum) == (min(replay), max(replay)), (row["model_id"], k, i)
            coefficients.append(lhs)
            extrema.append((minimum, maximum))
        geometry.append((coefficients, extrema, endpoint_perturbations))
    results = []
    for denominator in (10, 100):
        target = [
            (x - max(F(1), abs(x)) / denominator, x + max(F(1), abs(x)) / denominator)
            for x in nominal[-1]
        ]
        stages = []
        for k, (coefficients, extrema, endpoint_perturbations) in enumerate(geometry):
            eroded = [(lo - minimum, hi - maximum)
                      for (lo, hi), (minimum, maximum) in zip(target, extrema, strict=True)]

            nominal_lhs = [dot(lhs, nominal[k]) for lhs in coefficients]
            robust = satisfies(eroded, nominal_lhs)
            if k == 0:
                assert robust == all(satisfies(target, endpoint) for endpoint in forward[-1])
            nominal_pass = satisfies(
                [(lo - shift, hi - shift) for (lo, hi), shift in zip(target, endpoint_perturbations[0], strict=True)],
                nominal_lhs,
            )
            assert nominal_pass
            contradictory_rows = [i + 1 for i, (lo, hi) in enumerate(eroded) if lo > hi]
            status = "empty" if contradictory_rows else "witnessed_nonempty" if robust else "unresolved"
            stages.append({
                "stage": k,
                "word_count": len(endpoint_perturbations),
                "nominal_state_guaranteed": robust,
                "status": status,
                "contradictory_state_coordinates": contradictory_rows,
                "linear_map": coefficients,
                "eroded_bounds": eroded,
                "additive_extrema": extrema,
            })
        results.append({"relative_half_width": F(1, denominator), "target": target, "stages": stages})
    return {"model_id": row["model_id"], "title": row["model_title"], "profiles": results}


def main():
    root = Path(__file__).resolve().parent
    evidence = (root / "records.jsonl").read_bytes()
    receipt = json.loads((root / "source-manifest.json").read_text())
    evidence_hash = hashlib.sha256(evidence).hexdigest()
    assert evidence_hash == receipt["files_sha256"]["records.jsonl"]
    rows = [json.loads(line) for line in evidence.splitlines()]
    assert len(rows) == len({row["model_id"] for row in rows}) == 35
    records = list(map(audit_model, rows))

    result = {"records_sha256": evidence_hash, "results": records}
    (root / "robust-predecessors.json").write_text(json.dumps(result, default=str, indent=2) + "\n")
    for i in range(len(records[0]["profiles"])):
        for stage in range(3):
            outcomes = [record["profiles"][i]["stages"][stage] for record in records]
            counts = Counter(outcome["status"] for outcome in outcomes)
            empty = [record["model_id"] for record, outcome in zip(records, outcomes, strict=True)
                     if outcome["status"] == "empty"]
            print(i, stage, dict(counts), empty)


if __name__ == "__main__":
    main()

