"""Draw the finite EV fixture from the saved native selected policies."""

import json
from fractions import Fraction as F
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from exact_causal_oracle import matrix_product, quadratic_cost, vector, vector_sum


def ev_record(path):
    return next(
        row
        for row in map(json.loads, path.read_text().splitlines())
        if row["model_id"] == "catalogue-2026/model-6/1"
    )


def trace(row, first_action, second_action):
    initial = vector(row["x0"])
    offset = vector(row["c"])
    controls = [matrix_product(row["B"], vector(u)) for u in row["actions"]]
    external = [
        matrix_product(row["E"], vector(w)) for w in row["disturbance_vertices"]
    ]

    def advance(x, u, w):
        return vector_sum(matrix_product(row["A"], x), offset, controls[u], w)

    first = sorted({advance(initial, first_action, w) for w in external})
    paths = [
        (initial, x, advance(x, second_action(x), w)) for x in first for w in external
    ]
    worst = max(paths, key=lambda path: quadratic_cost(row["objective"], path[-1]))
    return first, sorted({path[-1] for path in paths}), worst


def coordinates(points):
    return [[float(x[i]) for x in points] for i in range(2)]


def main():
    root = Path(__file__).resolve().parent
    row = ev_record(root / "minimax-inputs.jsonl")
    native = ev_record(root / "native-minimax.jsonl")
    fixed, causal = native["fixed"], native["causal"]
    a, b = fixed["plans"][fixed["minimizing_plan_indices"][0]]["actions"]
    selected = {
        tuple(map(F, item["state"])): item["actions"][0] for item in causal["policy"]
    }
    fixed_trace = trace(row, a, lambda _: b)
    causal_trace = trace(row, causal["initial"]["actions"][0], selected.__getitem__)
    assert fixed_trace[0] == causal_trace[0]
    for replay, value in (
        (fixed_trace, fixed["value"]),
        (causal_trace, causal["initial"]["value"]),
    ):
        exact = quadratic_cost(row["objective"], replay[-1][-1])
        assert abs(exact - F(value)) < F(1, 10**10)

    matplotlib.rcParams["svg.hashsalt"] = "catalogue-ev-finite-causal-minimax"
    fig, ax = plt.subplots(figsize=(8.2, 5.8), layout="constrained")
    ax.scatter(
        *coordinates(fixed_trace[0]),
        s=66,
        facecolors="none",
        edgecolors="#475561",
        marker="o",
        label="Step 1 observations (both)",
    )
    for replay, color, marker, line, label in (
        (fixed_trace, "#9f4626", "s", "--", "Fixed plan"),
        (causal_trace, "#23698c", "x", "-", "Causal feedback"),
    ):
        _, endpoints, worst = replay
        ax.scatter(
            *coordinates(endpoints),
            s=46,
            marker=marker,
            color=color,
            alpha=0.72,
            label=f"{label} terminal states",
        )
        ax.plot(
            *coordinates(worst),
            linestyle=line,
            linewidth=2,
            color=color,
            label=f"{label} worst-case path",
        )
    ax.scatter(
        *coordinates([fixed_trace[2][0]]),
        s=96,
        marker="*",
        color="#171c22",
        label="Initial state",
        zorder=6,
    )

    ax.set(
        title="EV charging · finite disturbance game",
        xlabel="Remaining energy e₁ (kWh)",
        ylabel="Remaining energy e₂ (kWh)",
    )
    ax.set_aspect("equal", adjustable="box")
    ax.ticklabel_format(useOffset=False)
    ax.grid(alpha=0.24)
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left")
    ax.text(
        1.02,
        0.04,
        f"Worst terminal cost\nFixed {fixed['value']:.8f}\nCausal {causal['initial']['value']:.8f}",
        transform=ax.transAxes,
        va="bottom",
    )
    fig.savefig(root / "ev-causal-minimax.svg", metadata={"Date": None})
    fig.savefig(root / "ev-causal-minimax.png", dpi=160)


if __name__ == "__main__":
    main()
