#include <gmpxx.h>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {
using Json = nlohmann::json;
using Scalar = mpq_class;
using Vector = std::vector<Scalar>;
using Matrix = std::vector<Vector>;
using Interval = std::array<Scalar, 2>;
static_assert(std::numeric_limits<double>::is_iec559 &&
              std::numeric_limits<double>::digits == 53);

Vector decode(const Json &input) {
  Vector result;
  for (const auto &entry : input) {
    const double value = entry.get<double>();
    if (!std::isfinite(value))
      throw std::runtime_error("expected a finite binary64 input");
    result.emplace_back(value);
  }
  return result;
}

Matrix matrix(const Json &input) {
  const auto rows = input.at("rows").get<std::size_t>();
  const auto cols = input.at("columns").get<std::size_t>();
  const auto values = decode(input.at("row_major"));
  if (values.size() != rows * cols)
    throw std::runtime_error("matrix shape mismatch");
  Matrix result(rows, Vector(cols));
  auto value = values.begin();
  for (auto &row : result)
    for (auto &entry : row)
      entry = *value++;
  return result;
}

Scalar dot(const Vector &left, const Vector &right) {
  if (left.size() != right.size())
    throw std::runtime_error("vector shape mismatch");
  Scalar result;
  for (std::size_t i = 0; i < left.size(); ++i)
    result += left[i] * right[i];
  return result;
}

Vector pullback(const Matrix &transition, const Vector &direction) {
  Vector result(direction.size());
  for (std::size_t i = 0; i < direction.size(); ++i)
    for (std::size_t j = 0; j < result.size(); ++j)
      result[j] += transition[i][j] * direction[i];
  return result;
}

Json encode(const Vector &vector) {
  auto result = Json::array();
  for (const auto &value : vector)
    result.push_back(value.get_str());
  return result;
}

Json encode(const Interval &interval) {
  return Json::array({interval[0].get_str(), interval[1].get_str()});
}

Json predecessor(const Json &record) {
  const auto transition = matrix(record.at("A"));
  const auto input = matrix(record.at("B"));
  const auto external = matrix(record.at("E"));
  const auto offset = decode(record.at("offset"));
  const auto centre = decode(record.at("external_center"));
  auto endpoint = decode(record.at("x0"));
  std::vector<Matrix> stage_shifts;

  for (const auto &action : record.at("controls")) {
    const auto control = decode(action);
    Matrix shifts;
    for (const auto &vertex : record.at("disturbance_vertices")) {
      const auto disturbance = decode(vertex);
      Vector shift(offset.size());
      for (std::size_t i = 0; i < shift.size(); ++i)
        shift[i] = offset[i] + dot(input[i], control) + dot(external[i], disturbance);
      shifts.push_back(std::move(shift));
    }
    if (shifts.empty() || decode(record.at("disturbance_vertices").at(0)) != centre)
      throw std::runtime_error("expected nominal vertex first");
    Vector next(endpoint.size());
    for (std::size_t i = 0; i < endpoint.size(); ++i)
      next[i] = dot(transition[i], endpoint) + shifts.front()[i];
    endpoint = std::move(next);
    stage_shifts.push_back(std::move(shifts));
  }

  auto profiles = Json::array();
  for (const auto denominator : {10UL, 100UL}) {
    std::vector<Json> states(stage_shifts.size() + 1);
    for (auto &stage : states)
      stage = {{"linear_map", Json::array()}, {"eroded_bounds", Json::array()}};

    for (std::size_t i = 0; i < endpoint.size(); ++i) {
      Vector direction(endpoint.size());
      direction[i] = 1;
      const Scalar magnitude = abs(endpoint[i]);
      const Scalar radius = std::max(Scalar(1), magnitude) / denominator;
      Interval bound{endpoint[i] - radius, endpoint[i] + radius};

      for (std::size_t stage = stage_shifts.size(); ; --stage) {
        states[stage]["linear_map"].push_back(encode(direction));
        states[stage]["eroded_bounds"].push_back(encode(bound));
        if (stage == 0)
          break;

        Vector values;
        for (const auto &shift : stage_shifts[stage - 1])
          values.push_back(dot(direction, shift));
        const auto [lower, upper] = std::minmax_element(values.begin(), values.end());
        bound[0] -= *lower;
        bound[1] -= *upper;
        direction = pullback(transition, direction);
      }
    }
    profiles.push_back(states);
  }
  return {{"model_id", record.at("model_id")}, {"profiles", profiles}};
}
} // namespace

int main(int argc, char **argv) {
  if (argc != 3) {
    std::cerr << "usage: predecessor recorded-input.jsonl output.jsonl\n";
    return 2;
  }
  try {
    std::ifstream input(argv[1]);
    std::ofstream output(argv[2]);
    if (!input || !output)
      throw std::runtime_error("cannot open input or output");
    std::string line;
    while (std::getline(input, line))
      output << predecessor(Json::parse(line)).dump() << '\n';
    if (!input.eof() || !output)
      throw std::runtime_error("input or output failed");
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}

