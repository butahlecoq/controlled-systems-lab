"""Compare two-step fixed plans and causal policies on frozen catalogue inputs."""

import io
import json
import os
import subprocess
import zipfile
from fractions import Fraction
from pathlib import Path

LAB = Path(os.environ.get("CSL_LAB_REPOSITORY", "."))
FINITE_PIN = "48583948d283594079903c83ee403e76d125489d"
EXTERNAL_PIN = "aa43ccdbc318d7703dbc78fd0ea9fe17c17bf5a3"
FINITE_ARCHIVE = "catalogue-finite-action-v1/catalogue-parallelotope-replay-evidence.zip"
EXTERNAL_RECORDS = "catalogue-external-fixed-plan-v1/records.jsonl"


def report_bytes(pin, artifact):
    return subprocess.check_output(
        ["git", "show", f"{pin}:reports/algorithm-results/{artifact}"], cwd=LAB
    )


def vector(values):
    return tuple(map(Fraction, values))


def matrix_product(matrix, values):
    columns = matrix["columns"]
    entries = matrix["row_major"]
    assert len(values) == columns
    return tuple(
        sum(Fraction(entry) * value for entry, value in zip(entries[i : i + columns], values)
            if entry and value)
        for i in range(0, len(entries), columns)
    )


def vector_sum(*values):
    return tuple(map(sum, zip(*values, strict=True)))


def quadratic_cost(objective, state):
    matrix = objective["Q"]
    linear = vector(objective["linear"])
    matrix_state = matrix_product(matrix, state)
    return Fraction(objective["constant"]) + sum(
        x * (qx / 2 + weight)
        for x, qx, weight in zip(state, matrix_state, linear, strict=True)
    )


def fixed_and_causal(suffix_worst):
    """Index order is first action, first disturbance, second action."""
    fixed = min(
        max(disturbance[second] for disturbance in first_action)
        for first_action in suffix_worst
        for second in range(len(first_action[0]))
    )
    causal = min(
        max(min(disturbance) for disturbance in first_action)
        for first_action in suffix_worst
    )
    return fixed, causal


def self_test():
    # One first action. The second action can answer the first disturbance.
    assert fixed_and_causal([[[0, 1], [1, 0]]]) == (1, 0)
    # One second action. Neither policy can observe the first disturbance
    # before choosing its first action. Reversing min/max yields a false zero.
    assert fixed_and_causal([[[0], [1]], [[1], [0]]]) == (1, 1)
    # Each controller decision is followed by a worst-case disturbance,
    # including the terminal transition, rather than a favourable outcome.
    second_disturbance = [[[[0, 4], [2, 1]]]]
    suffix = [
        [[max(payoffs) for payoffs in row] for row in first]
        for first in second_disturbance
    ]
    assert fixed_and_causal(suffix) == (2, 2)
    objective = {
        "Q": {"rows": 2, "columns": 2, "row_major": [4, 2, 2, 6]},
        "linear": [3, -2],
        "constant": 7,
    }
    assert quadratic_cost(objective, vector([2, -1])) == 22


def compare(plan, external):
    assert all(plan[key] == external[key] for key in ("model_id", "A", "B", "E", "x0"))
    assert plan["c"] == external["offset"]
    assert plan["external"] == external["external_center"]
    assert plan["horizon"] == len(external["controls"]) == 2
    actions = [matrix_product(plan["B"], vector(u)) for u in plan["actions"]]
    disturbances = [
        matrix_product(plan["E"], vector(w))
        for w in external["disturbance_vertices"]
    ]
    transition = plan["A"]
    offset = vector(plan["c"])
    initial_image = matrix_product(transition, vector(plan["x0"]))
    observed_policy = {}
    suffix_worst = []
    for first_action in actions:
        action_branch = []
        for first_disturbance in disturbances:
            observed = vector_sum(initial_image, offset, first_action, first_disturbance)
            observed_image = matrix_product(transition, observed)
            values = tuple(
                max(
                    quadratic_cost(
                        plan["objective"],
                        vector_sum(observed_image, offset, action, disturbance),
                    )
                    for disturbance in disturbances
                )
                for action in actions
            )
            best = min(values)
            optimal_actions = tuple(index for index, value in enumerate(values) if value == best)
            assert observed_policy.setdefault(observed, optimal_actions) == optimal_actions
            action_branch.append(values)
        suffix_worst.append(action_branch)
    fixed, causal = fixed_and_causal(suffix_worst)
    assert causal <= fixed
    return {
        "model_id": plan["model_id"],
        "model_title": plan["model_title"],
        "first_stage_observed_states": len(observed_policy),
        "fixed_cost": float(fixed),
        "causal_cost": float(causal),
        "causal_advantage": float(fixed - causal),
        "fixed_cost_exact": str(fixed),
        "causal_cost_exact": str(causal),
    }


def main():
    self_test()
    raw_external = report_bytes(EXTERNAL_PIN, EXTERNAL_RECORDS).splitlines()
    finite_zip = report_bytes(FINITE_PIN, FINITE_ARCHIVE)
    with zipfile.ZipFile(io.BytesIO(finite_zip)) as archive:
        by_id = {
            row["model_id"]: row for row in map(json.loads, raw_external)
        }
        assert len(by_id) == len(raw_external) == 35
        models = []
        for index in range(1, 36):
            plan = json.loads(archive.read(f"raw/{index}.json"))
            models.append(compare(plan, by_id[plan["model_id"]]))
    strict = [model["model_id"] for model in models if model["causal_advantage"] > 0]
    assert strict == ["catalogue-2026/model-6/1", "catalogue-2026/model-30/1"]
    print(json.dumps({
        "finite_action_commit": FINITE_PIN,
        "finite_action_archive": FINITE_ARCHIVE,
        "external_geometry_commit": EXTERNAL_PIN,
        "external_geometry_records": EXTERNAL_RECORDS,
        "finite_disturbance_vertices": True,
        "state_domain": "universal",
        "strict_causal_advantage_models": strict,
        "models": models,
    }, indent=2))


if __name__ == "__main__":
    main()
