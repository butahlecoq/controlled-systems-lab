#include <csl/optimization/finite_action_minimax.hpp>
#include <csl/optimization/finite_causal_minimax.hpp>
#include <gmpxx.h>
#include <nlohmann/json.hpp>

#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

namespace {
using nlohmann::json;
using namespace csl;
namespace opt = csl::optimization;
namespace game = csl::optimization::finite_causal_minimax;
using ExactState = std::vector<mpq_class>;
static_assert(std::numeric_limits<double>::is_iec559 && std::numeric_limits<double>::digits == 53);

template <class T, class... Errors> T take(std::variant<T, Errors...> result) {
    if (auto *value = std::get_if<T>(&result))
        return std::move(*value);
    if constexpr ((std::is_same_v<Diagnostic, Errors> || ...)) {
        if (const auto *error = std::get_if<Diagnostic>(&result))
            throw std::runtime_error(error->field + ": " + error->explanation);
    }
    throw std::runtime_error("unexpected native outcome");
}

Matrix matrix(const json &data) {
    return {data.at("rows").get<std::size_t>(), data.at("columns").get<std::size_t>(),
            data.at("row_major").get<Vector>()};
}

ExactState exact_state(const Vector &values) { return ExactState(values.begin(), values.end()); }

mpq_class row_product(const Matrix &matrix, std::size_t i, const ExactState &values) {
    if (matrix.cols != values.size() || matrix.rows * matrix.cols != matrix.values.size())
        throw std::runtime_error("invalid dynamics dimensions");
    mpq_class value;
    for (std::size_t j = 0; j < values.size(); ++j)
        value += mpq_class(matrix.values[i * matrix.cols + j]) * values[j];
    return value;
}

class StateLayer {
    std::map<ExactState, game::StateId> ids;

  public:
    std::vector<ExactState> states;

    game::StateId intern(ExactState state) {
        const auto [entry, inserted] = ids.try_emplace(state, game::StateId{states.size()});
        if (inserted)
            states.push_back(std::move(state));
        return entry->second;
    }
};

game::Stage build_stage(const StateLayer &current, StateLayer &next, const LinearStage &dynamics,
                        const std::vector<Vector> &controls, const std::vector<Vector> &external) {
    game::Stage layer{current.states.size(),
                      controls.size(),
                      external.size(),
                      std::vector<bool>(current.states.size(), true),
                      {}};
    for (const auto &state : current.states) {
        auto &by_action = layer.next_state.emplace_back();
        for (const auto &control : controls) {
            auto &by_disturbance = by_action.emplace_back();
            const auto u = exact_state(control);
            for (const auto &disturbance : external) {
                const auto w = exact_state(disturbance);
                ExactState successor(state.size());
                for (std::size_t i = 0; i < state.size(); ++i)
                    successor[i] = row_product(dynamics.A, i, state) +
                                   row_product(dynamics.B, i, u) + row_product(dynamics.E, i, w) +
                                   mpq_class(dynamics.offset[i]);
                by_disturbance.push_back(next.intern(std::move(successor)));
            }
        }
    }
    return layer;
}

sets::SetData disturbance_set(std::size_t dimension, const std::vector<Vector> &vertices) {
    Vector rows;
    for (const auto &vertex : vertices)
        rows.insert(rows.end(), vertex.begin(), vertex.end());
    return take(
        sets::make_v({{"external-vertices"}, dimension, {}},
                     {take(numeric::snapshot(Matrix{vertices.size(), dimension, std::move(rows)})),
                      take(numeric::snapshot(Matrix{0, dimension, {}}))}));
}

json fixed_plan(const opt::FiniteActionMinimaxRequest &request, std::size_t vertex_count) {
    const auto count = request.actions.catalogue.size();
    const auto outcome =
        opt::finite_action_minimax(request, {count * count, vertex_count * vertex_count, 0});
    if (const auto *optimal = std::get_if<opt::FiniteMinimaxOptimal>(&outcome)) {
        auto plans = json::array();
        for (const auto &row : optimal->plans) {
            const auto &candidate = std::get<opt::FinitePlanFeasible>(row);
            plans.push_back({{"actions", candidate.action_indices},
                             {"value", candidate.worst_value},
                             {"evaluated_vertices", candidate.evaluated_vertices}});
        }
        return {{"status", "optimal"},
                {"value", optimal->value},
                {"plans", plans},
                {"minimizing_plan_indices", optimal->minimizing_plan_indices}};
    }
    if (const auto *error = std::get_if<Unsupported>(&outcome)) {
        auto diagnostics = json::array();
        for (const auto &item : error->diagnostics)
            diagnostics.push_back({{"field", item.field}, {"explanation", item.explanation}});
        return {{"status", "unsupported"}, {"diagnostics", diagnostics}};
    }
    if (const auto *error = std::get_if<OperationStopped>(&outcome))
        return {{"status", "stopped"}, {"diagnostic", error->diagnostics}};
    return {{"status", "not-optimal"}, {"outcome_index", outcome.index()}};
}

json state_value(const game::StateValue &value) {
    std::vector<std::size_t> actions;
    for (const auto action : value.optimal_actions)
        actions.push_back(action.value);
    return {{"value", value.value}, {"actions", actions}, {"feasible", value.feasible}};
}

json causal(const LinearStage &dynamics, const Vector &initial, const std::vector<Vector> &actions,
            const std::vector<Vector> &disturbances, const opt::Objective &objective) {
    std::vector<StateLayer> catalogues(3);
    const auto initial_id = catalogues[0].intern(exact_state(initial));
    std::vector<game::Stage> stages;
    for (std::size_t k = 0; k < 2; ++k)
        stages.push_back(
            build_stage(catalogues[k], catalogues[k + 1], dynamics, actions, disturbances));
    const auto &terminal_states = catalogues.back().states;
    game::Terminal terminal{
        terminal_states.size(), std::vector<bool>(terminal_states.size(), true), {}};
    for (const auto &state : terminal_states) {
        Vector value;
        for (const auto &coordinate : state)
            value.push_back(coordinate.get_d());
        terminal.cost.push_back(take(opt::evaluate(objective, value)));
    }
    const auto result =
        take(game::solve({std::move(stages), std::move(terminal), initial_id}, {0, 0}));

    auto policy = json::array();
    for (std::size_t i = 0; i < catalogues[1].states.size(); ++i) {
        std::vector<std::string> observation;
        for (const auto &coordinate : catalogues[1].states[i])
            observation.push_back(coordinate.get_str());
        auto row = state_value(result.values_by_stage[1][i]);
        row["state"] = observation;
        policy.push_back(std::move(row));
    }
    return {{"status", "optimal"},
            {"initial", state_value(result.initial())},
            {"policy", policy},
            {"terminal_state_count", terminal_states.size()}};
}

json replay(const json &row) {
    const auto id = row.at("model_id").get<std::string>();
    const auto x0 = row.at("x0").get<Vector>();
    const auto actions = row.at("actions").get<std::vector<Vector>>();
    const auto external = row.at("disturbance_vertices").get<std::vector<Vector>>();
    const LinearStage dynamics{matrix(row.at("A")), matrix(row.at("B")), matrix(row.at("E")),
                               row.at("c").get<Vector>()};

    const Dimensions sizes{x0.size(), dynamics.B.cols, dynamics.E.cols};
    const auto dt = row.at("dt").get<double>();
    const auto system =
        take(model::snapshot({{sizes, TimeDomain::discrete, dynamics}, {}}, Vector{0, dt, 2 * dt}));
    const auto &cost = row.at("objective");
    const auto objective = take(opt::snapshot(QuadraticTerminal{
        matrix(cost.at("Q")), cost.at("linear").get<Vector>(), cost.at("constant").get<double>()}));

    const auto initial = take(
        sets::make_singleton({{"initial"}, sizes.state, {}}, take(numeric::snapshot_vector(x0))));
    const auto disturbance = disturbance_set(sizes.external, external);
    const auto safe = take(sets::make_universal({{"universal"}, sizes.state, {}}));
    const opt::FiniteActionMinimaxRequest request{{id},
                                                  {"fixed-plan"},
                                                  system,
                                                  initial,
                                                  {sizes.control, actions},
                                                  {disturbance, disturbance},
                                                  {safe, safe, safe},
                                                  objective};
    return {{"model_id", id},
            {"fixed", fixed_plan(request, external.size())},
            {"causal", causal(dynamics, x0, actions, external, objective)}};
}
} // namespace

int main(int argc, char **argv) {
    if (argc != 3) {
        std::cerr << "usage: catalogue_minimax input.jsonl output.jsonl\n";
        return 2;
    }
    std::ifstream input(argv[1]);
    std::ofstream output(argv[2]);
    if (!input || !output)
        return 2;
    std::string line;
    while (std::getline(input, line)) {
        try {
            output << replay(json::parse(line)).dump() << '\n';
        } catch (const std::exception &error) {
            std::cerr << error.what() << '\n';
            return 1;
        }
    }
    return !input.eof() || !output;
}
