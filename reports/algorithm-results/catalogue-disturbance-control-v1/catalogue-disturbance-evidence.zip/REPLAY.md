# Catalogue disturbance geometry and control

This bundle has two separate experiments on the 35 authored catalogue models. Both reuse source-bound affine inputs and two disturbance transitions. Intermediate state sets are universal. Neither experiment measures performance or asserts physical calibration.

- In the fixed-plan predecessor experiment, controls remain zero. The authored terminal target has half-widths of 10% or 1% of the greater of one and the absolute nominal endpoint coordinate. The exact checker enumerates 1,013 disturbance suffix words and verifies 2,334 native pulled-back intervals.
- The finite minimax experiment uses the three actions and terminal quadratic from the finite-action lesson. It compares selecting both actions initially with selecting the second action from the observed successor. Both models of information choose the first action before the first disturbance. The native fixed plan works on a V representation. For the convex terminal objective and affine dynamics its worst value is attained on the finite vertex words. The causal graph is defined on the finite vertices only. It does not establish a causal value for the entire convex hull.

## Replay

Use CMake 3.31 or later, a C++20 compiler, GMP headers and libraries, Python 3.12 or 3.13, and Matplotlib 3.11.2 for figures. Configure with the exact CSL SDK checkout at commit `806738c9d1c8f1d9ebd8885b7bb605b5a698b1af` from the [SDK repository](https://github.com/butahlecoq/csl-sdk). The build selects only the core facilities and the SDK's pinned JSON headers.

```sh
sha256sum -c SHA256SUMS
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCSL_SOURCE_DIR=/path/to/reviewed/csl-sdk
cmake --build build --target predecessor catalogue_minimax
python -B finite_word_reference.py records.jsonl prior-inputs.json > external-audit.json
build/predecessor records.jsonl replay-predecessor.jsonl
python -B audit.py
python -B compare.py replay-predecessor.jsonl robust-predecessors.json
build/catalogue_minimax minimax-inputs.jsonl replay-minimax.jsonl
PYTHONPATH=causal-oracle python -B verify_minimax.py minimax-inputs.jsonl --results replay-minimax.jsonl > replay-audit.json
MPLBACKEND=Agg python -B plot.py
MPLBACKEND=Agg PYTHONPATH=causal-oracle python -B plot_minimax.py
```

The native predecessor output is rational. The minimax solvers return binary64 objective and value data. The independent rational verifier accepts a scaled tolerance of 1e-9 and checks every selected decision by replay. The configured fixture achieved a largest absolute difference of 2.58e-14. The exact analogue of the native minimax output provides an oracle for different compiler or library builds.

The two source inputs are the finite-action bundle at Lab `48583948d283594079903c83ee403e76d125489d` and the external geometry bundle at Lab `aa43ccdbc318d7703dbc78fd0ea9fe17c17bf5a3`. A separate join command can reproduce `minimax-inputs.jsonl` from those Git objects. Set `CSL_LAB_REPOSITORY` to the local Lab checkout and run `PYTHONPATH=causal-oracle python -B verify_minimax.py joined.jsonl`.
