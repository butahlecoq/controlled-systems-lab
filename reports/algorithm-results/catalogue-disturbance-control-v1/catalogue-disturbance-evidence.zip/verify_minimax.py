"""Join source-pinned model inputs and verify the complete native minimax replay."""

import argparse
import hashlib
import io
import json
import zipfile
from fractions import Fraction as F
from pathlib import Path

from exact_causal_oracle import (
    EXTERNAL_PIN,
    EXTERNAL_RECORDS,
    FINITE_ARCHIVE,
    FINITE_PIN,
    matrix_product,
    quadratic_cost,
    report_bytes,
    self_test,
    vector,
    vector_sum,
)


def load_inputs():
    external_blob = report_bytes(EXTERNAL_PIN, EXTERNAL_RECORDS)
    finite_blob = report_bytes(FINITE_PIN, FINITE_ARCHIVE)
    by_id = {
        row["model_id"]: row for row in map(json.loads, external_blob.splitlines())
    }
    assert len(by_id) == len(external_blob.splitlines()) == 35
    with zipfile.ZipFile(io.BytesIO(finite_blob)) as archive:
        for index in range(1, 36):
            finite = json.loads(archive.read(f"raw/{index}.json"))
            disturbance = by_id[finite["model_id"]]
            for key in ("model_id", "A", "B", "E", "x0", "dt", "source_sha256"):
                assert finite[key] == disturbance[key], (index, key)
            assert finite["c"] == disturbance["offset"]
            assert finite["external"] == disturbance["external_center"]
            assert finite["horizon"] == len(disturbance["controls"]) == 2
            yield {
                key: finite[key]
                for key in (
                    "A",
                    "B",
                    "E",
                    "actions",
                    "c",
                    "dt",
                    "model_id",
                    "model_title",
                    "objective",
                    "x0",
                )
            } | {"disturbance_vertices": disturbance["disturbance_vertices"]}


def oracle(row):
    state = vector(row["x0"])
    offset = vector(row["c"])
    shifts = [matrix_product(row["B"], vector(u)) for u in row["actions"]]
    deviations = [
        matrix_product(row["E"], vector(w)) for w in row["disturbance_vertices"]
    ]

    def step(x, control, external):
        return vector_sum(matrix_product(row["A"], x), offset, control, external)

    first = [[step(state, u, w) for w in deviations] for u in shifts]
    terminal = set()
    continuation = {}
    for state in {x for branch in first for x in branch}:
        scores = []
        for u in shifts:
            endpoints = [step(state, u, w) for w in deviations]
            terminal.update(endpoints)
            scores.append(max(quadratic_cost(row["objective"], x) for x in endpoints))
        continuation[state] = scores

    fixed = {
        (a, b): max(continuation[state][b] for state in branch)
        for a, branch in enumerate(first)
        for b in range(len(shifts))
    }
    causal = [max(min(continuation[state]) for state in branch) for branch in first]
    return fixed, causal, first, continuation, len(terminal)


def verify(input_path, output):
    input_bytes = input_path.read_bytes()
    inputs = list(map(json.loads, input_bytes.splitlines()))
    native_rows = list(map(json.loads, output.read_text().splitlines()))
    rows = []
    largest_error = F(0)

    def agreed(actual, reference, label):
        nonlocal largest_error
        error = abs(F(actual) - reference)
        largest_error = max(error, largest_error)
        # Absolute floor for cancellation in 0.5*x'Q*x + l'x + c.
        assert error <= F(1, 10**9) * max(1, abs(reference)), (label, float(error))

    for inputs_row, native in zip(inputs, native_rows, strict=True):
        model = inputs_row["model_id"]
        assert native["model_id"] == model
        fixed, causal, branches, continuation, terminal_count = oracle(inputs_row)
        reported_fixed = native["fixed"]
        reported_causal = native["causal"]
        assert reported_fixed["status"] == reported_causal["status"] == "optimal", (
            native
        )
        assert reported_causal["terminal_state_count"] == terminal_count, model

        plans = {tuple(plan["actions"]): plan for plan in reported_fixed["plans"]}
        assert (
            len(plans) == len(reported_fixed["plans"]) and plans.keys() == fixed.keys()
        ), model
        for key, expected in fixed.items():
            agreed(plans[key]["value"], expected, (model, "fixed", key))
            assert (
                plans[key]["evaluated_vertices"]
                == len(inputs_row["disturbance_vertices"]) ** 2
            )
        chosen = [
            tuple(reported_fixed["plans"][i]["actions"])
            for i in reported_fixed["minimizing_plan_indices"]
        ]
        assert chosen
        for key in chosen:
            agreed(fixed[key], min(fixed.values()), (model, "chosen fixed plan", key))

        policy = {
            tuple(map(F, action["state"])): action
            for action in reported_causal["policy"]
        }
        assert (
            len(policy) == len(reported_causal["policy"])
            and policy.keys() == continuation.keys()
        )
        for state, costs in continuation.items():
            action = policy[state]
            assert action["feasible"] and action["actions"], model
            agreed(action["value"], min(costs), (model, "successor value", state))
            for index in action["actions"]:
                agreed(
                    costs[index],
                    min(costs),
                    (model, "successor decision", state, index),
                )
        initial = reported_causal["initial"]
        assert initial["feasible"] and initial["actions"], model
        for index in initial["actions"]:
            agreed(causal[index], min(causal), (model, "initial decision", index))
            policy_cost = max(
                continuation[state][action]
                for state in branches[index]
                for action in policy[state]["actions"]
            )
            agreed(policy_cost, min(causal), (model, "policy replay", index))
        fixed_value = min(fixed.values())
        causal_value = min(causal)
        agreed(reported_fixed["value"], fixed_value, (model, "fixed root"))
        agreed(initial["value"], causal_value, (model, "causal root"))
        rows.append(
            {
                "model_id": model,
                "fixed": reported_fixed["value"],
                "causal": initial["value"],
                "exact_advantage": str(fixed_value - causal_value),
                "observed_states": len(policy),
                "terminal_states": terminal_count,
            }
        )
    strict = [row["model_id"] for row in rows if F(row["exact_advantage"]) > 0]
    native_strict = [
        row["model_id"] for row in rows if row["fixed"] - row["causal"] > 1e-9
    ]
    assert (
        strict
        == native_strict
        == ["catalogue-2026/model-6/1", "catalogue-2026/model-30/1"]
    )
    return {
        "source_input_sha256": hashlib.sha256(input_bytes).hexdigest(),
        "largest_absolute_error": float(largest_error),
        "models": len(rows),
        "checked_fixed_plans": sum(len(row["fixed"]["plans"]) for row in native_rows),
        "checked_second_decision_states": sum(row["observed_states"] for row in rows),
        "strict_advantage": strict,
        "rows": rows,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", type=Path)
    parser.add_argument("--results", type=Path)
    args = parser.parse_args()
    if args.results is None:
        text = "".join(json.dumps(row, sort_keys=True) + "\n" for row in load_inputs())
        args.inputs.write_text(text)
    else:
        self_test()
        print(json.dumps(verify(args.inputs, args.results), indent=2))
