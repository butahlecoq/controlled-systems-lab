"""Plot the exactly checked Puffer fixture using its two physical coordinates."""

import json
from fractions import Fraction as F
from itertools import product
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from finite_word_reference import dot, reference


def turn(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def hull(points):
    points = sorted(set(map(tuple, points)))
    if len(points) < 3:
        return points

    def half(ordered):
        result = []
        for point in ordered:
            while len(result) > 1 and turn(*result[-2:], point) <= 0:
                result.pop()
            result.append(point)
        return result

    return half(points)[:-1] + half(reversed(points))[:-1]


def clip(polygon, row, bound):
    result = []
    for a, b in zip(polygon, polygon[1:] + polygon[:1], strict=True):
        da, db = dot(row, a) - bound, dot(row, b) - bound
        if (da < 0 < db) or (db < 0 < da):
            fraction = da / (da - db)
            result.append(tuple(p + fraction * (q - p) for p, q in zip(a, b, strict=True)))
        if db <= 0:
            result.append(b)
    return result


def inverse_vertices(rows, intervals):
    (a, b), (c, d) = rows
    determinant = a * d - b * c
    return hull([((d * r - b * s) / determinant, (a * s - c * r) / determinant)
                 for r, s in product(*intervals)])


def paint(axis, polygon, **style):
    if len(polygon) == 1:
        axis.plot(*polygon[0], marker="o", color=style["color"], markersize=4)
    elif polygon:
        x, y = zip(*(polygon + polygon[:1]), strict=True)
        axis.plot(x, y, **style)


def main():
    root = Path(__file__).resolve().parent
    model_id = "catalogue-2026/model-2/1"
    original = next(row for row in map(json.loads, (root / "records.jsonl").read_text().splitlines())
                    if row["model_id"] == model_id)
    audit = next(row for row in json.loads((root / "robust-predecessors.json").read_text())["results"]
                 if row["model_id"] == model_id)
    profile = audit["profiles"][0]
    stages = reference(original)
    matplotlib.rcParams["svg.hashsalt"] = "catalogue-fixed-plan-robust-puffer"
    fig, axis = plt.subplots(figsize=(9, 5.2), layout="constrained")
    colors = ("#394652", "#246698", "#9d391f")
    for record, paths, color in zip(profile["stages"], stages, colors, strict=True):
        k = record["stage"]
        forward = hull(paths)
        paint(axis, forward, color=color, linewidth=1.6)
        if record["status"] == "empty":
            continue
        rows = [list(map(F, row)) for row in record["linear_map"]]
        limits = [list(map(F, pair)) for pair in record["eroded_bounds"]]
        predecessor = inverse_vertices(rows, limits)
        paint(axis, predecessor, color=color, linestyle="--", linewidth=1.8)
        intersection = forward
        for row, (lo, hi) in zip(rows, limits, strict=True):
            intersection = clip(intersection, row, hi)
            intersection = clip(intersection, [-x for x in row], -lo)
        if intersection:
            x, y = zip(*intersection, strict=True)
            axis.fill(x, y, color=color, alpha=0.2)
    nominal = [stage[0] for stage in stages]
    x, y = zip(*nominal, strict=True)
    axis.plot(x, y, color="black", marker="o", markersize=4, linewidth=0.9, zorder=5)
    for k, (x, y) in enumerate(nominal):
        offset, horizontal = ((-8, -13), "right") if k == 0 else ((7, 9), "left")
        axis.annotate(f"k = {k}", (x, y), xytext=offset, textcoords="offset points", ha=horizontal)
    axis.set_title("Puffer playback buffer · two fixed-control transitions")
    axis.set_xlabel("Playback buffer x₁ (s)")
    axis.set_ylabel("Smoothed throughput error x₂ (Mbit)")
    axis.grid(alpha=0.24)
    axis.legend(handles=[
        Line2D([0], [0], color=colors[1], label="Stage 1"),
        Line2D([0], [0], color=colors[2], label="Stage 2"),
        Line2D([0], [0], color="black", label="Forward reachable boundary"),
        Line2D([0], [0], color="black", linestyle="--", label="Robust predecessor or terminal target"),
        Line2D([0], [0], color="black", marker="o", markersize=4, label="Nominal fixed-plan replay"),
        Patch(facecolor="grey", alpha=0.25, label="Same-stage intersection"),
    ], loc="upper left")
    axis.text(0.98, 0.03, "The robust predecessor at k = 0 is empty.",
              transform=axis.transAxes, ha="right", fontsize=9)
    fig.savefig(root / "puffer-robust-predecessor.svg", metadata={"Date": None})
    fig.savefig(root / "puffer-robust-predecessor.png", dpi=160)


if __name__ == "__main__":
    main()

