add_executable(model_tests tests/unit/model/linear_system_tests.cpp)
target_link_libraries(model_tests PRIVATE CSL::model doctest::doctest Threads::Threads)
add_test(NAME model_tests COMMAND model_tests)
csl_test_target(model_tests model)

add_executable(model_catalogue_tests tests/unit/model/catalogue_tests.cpp)
target_link_libraries(model_catalogue_tests PRIVATE CSL::model_catalogue doctest::doctest)
add_test(NAME model_catalogue_tests COMMAND model_catalogue_tests)
csl_test_target(model_catalogue_tests model)

add_executable(flexible_pitch_tests tests/unit/model/flexible_pitch_tests.cpp)
target_link_libraries(flexible_pitch_tests PRIVATE CSL::model_catalogue doctest::doctest)
add_test(NAME flexible_pitch_tests COMMAND flexible_pitch_tests)
csl_test_target(flexible_pitch_tests model)

add_executable(model_catalogue_reference examples/native_model_catalogue.cpp)
target_link_libraries(model_catalogue_reference PRIVATE CSL::model_catalogue CSL::generator_adapter CSL::quickhull_2d)
add_test(NAME model_catalogue_reference COMMAND model_catalogue_reference)
csl_test_target(model_catalogue_reference model)

add_executable(four_state_catalogue_reference examples/native_four_state_reachability.cpp)
target_link_libraries(four_state_catalogue_reference PRIVATE CSL::model_catalogue CSL::geometry_generators CSL::quickhull_2d)
add_test(NAME four_state_catalogue_reference COMMAND four_state_catalogue_reference)
csl_test_target(four_state_catalogue_reference model)

add_executable(affine_dynamics_tests tests/unit/model/affine_dynamics_test.cpp)
target_link_libraries(affine_dynamics_tests PRIVATE CSL::model CSL::sets doctest::doctest)
add_test(NAME affine_dynamics_tests COMMAND affine_dynamics_tests)
csl_test_target(affine_dynamics_tests model)

add_executable(observation_model_tests tests/unit/model/observation_model_test.cpp)
target_link_libraries(observation_model_tests PRIVATE CSL::model doctest::doctest)
add_test(NAME observation_model_tests COMMAND observation_model_tests)
csl_test_target(observation_model_tests model)

add_executable(hybrid_model_tests tests/unit/model/hybrid_system_test.cpp)
target_link_libraries(hybrid_model_tests PRIVATE CSL::model CSL::sets doctest::doctest)
add_test(NAME hybrid_model_tests COMMAND hybrid_model_tests)
csl_test_target(hybrid_model_tests model)

add_executable(model_public_client tests/installed/model_client.cpp)
target_link_libraries(model_public_client PRIVATE CSL::model)
add_test(NAME model_public_client COMMAND model_public_client)
csl_test_target(model_public_client model)

add_executable(continuous_discretization_tests tests/contract/model/continuous_discretization_tests.cpp)
target_link_libraries(continuous_discretization_tests PRIVATE CSL::model doctest::doctest)
add_test(NAME continuous_discretization_tests COMMAND continuous_discretization_tests)
csl_test_target(continuous_discretization_tests model)

add_executable(flexible_pitch_slew_tests tests/unit/model/flexible_pitch_slew_tests.cpp)
target_link_libraries(flexible_pitch_slew_tests PRIVATE CSL::model_catalogue CSL::resolved_problem doctest::doctest)
add_test(NAME flexible_pitch_slew_tests COMMAND flexible_pitch_slew_tests)
csl_test_target(flexible_pitch_slew_tests model)

add_executable(flexible_pitch_reference examples/native_flexible_pitch.cpp)
target_link_libraries(flexible_pitch_reference PRIVATE CSL::model_catalogue CSL::geometry_generators CSL::quickhull_2d)
add_test(NAME flexible_pitch_reference COMMAND flexible_pitch_reference)
csl_test_target(flexible_pitch_reference model)
