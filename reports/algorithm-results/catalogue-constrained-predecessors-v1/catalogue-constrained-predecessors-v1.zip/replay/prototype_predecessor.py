"""Compare nominal predecessor supports under three matched catalogue profiles."""

import argparse
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

import numpy as np
import scipy
from native.prepare_inputs import BACKWARD_SHA, HISTORY_SHA, checked_zip
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

REV = "e9c95871b7ec8ff31b16104919e6c93d79e1419f"
PROFILES = ("authored", "saved_controls", "full")
STATUS = {0: "optimal", 1: "limit", 2: "infeasible", 3: "unbounded", 4: "numerical"}


def open_capture(root, slug):
    filename, digest = {
        "feasible-history": ("history.zip", HISTORY_SHA),
        "backward-reachability": ("backward.zip", BACKWARD_SHA),
    }[slug]
    return checked_zip(Path(root) / filename, digest), digest


def matrix(data):
    return np.asarray(data["values"], dtype=float).reshape(data["rows"], data["cols"])


def build(model, terminal, start, profile, condensed):
    """Assemble direct dynamic rows or substitute a forward recurrence symbolically."""
    A, B, G = (matrix(model[name]) for name in ("A", "B", "G"))
    nx, nu = B.shape
    remaining = 3 - start
    state_count = nx if condensed else (remaining + 1) * nx
    control_count = nu * remaining
    con = model["constraints"]
    groups = con["positive_part"][start:] if profile == "full" else [[]] * remaining
    aux_count = sum(len(group["indices"]) for stage in groups for group in stage)
    total = state_count + control_count + aux_count
    free = (None, None)
    control_bounds = (
        [(-1.0, 1.0)] * control_count
        if profile == "authored"
        else [tuple(bound) for stage in con["control"][start:] for bound in stage]
    )
    bounds = [free] * state_count + control_bounds + [(0.0, None)] * aux_count
    H, upper, E, rhs = [], [], [], []

    def add(lhs, drift, interval):
        low, high = interval
        if low is not None:
            H.append(-lhs)
            upper.append(drift - low)
        if high is not None:
            H.append(lhs)
            upper.append(high - drift)

    lift = np.zeros((nx, total))
    lift[:, :nx] = np.eye(nx)
    offset = np.zeros(nx)
    next_aux = state_count + control_count
    for k in range(start, 4):
        if profile == "full":
            for row, shift, limit in zip(lift, offset, con["state"][k], strict=True):
                add(row, shift, limit)
        if k == 3:
            break
        ext = np.asarray(model["external"][k])
        controls = np.zeros((nu, total))
        column = state_count + (k - start) * nu
        controls[:, column : column + nu] = np.eye(nu)
        if profile == "full" and con["stage"]:
            stage = con["stage"][k]
            F, C, W = (matrix(stage[name]) for name in ("state", "control", "external"))
            for row, shift, limit in zip(
                F @ lift + C @ controls,
                F @ offset + W @ ext,
                stage["bounds"],
                strict=True,
            ):
                add(row, shift, limit)
        for group in groups[k - start]:
            budget = np.zeros(total)
            for i in group["indices"]:
                epigraph = np.zeros(total)
                epigraph[next_aux] = 1.0
                add(controls[i] - epigraph, 0.0, (None, 0.0))
                budget[next_aux] = 1.0
                next_aux += 1
            add(budget, 0.0, (None, group["upper"]))
        drift = G @ ext + model["offset"]
        next_lift, next_offset = A @ lift + B @ controls, A @ offset + drift
        if condensed:
            lift, offset = next_lift, next_offset
        else:
            lift = np.zeros((nx, total))
            column = (k - start + 1) * nx
            lift[:, column : column + nx] = np.eye(nx)
            E.extend(lift - next_lift)
            rhs.extend(next_offset)
    for row, shift, interval in zip(lift, offset, terminal, strict=True):
        add(row, shift, interval)
    if profile == "full":
        for rows in con["terminal"]:
            F = matrix(rows["state"])
            for row, shift, interval in zip(F @ lift, F @ offset, rows["bounds"], strict=True):
                add(row, shift, interval)
    assert next_aux == total
    return (
        np.reshape(H, (-1, total)),
        np.asarray(upper),
        np.reshape(E, (-1, total)),
        np.asarray(rhs),
        bounds,
    )


def solve(program, direction, plane, method, presolve=True):
    H, upper, E, rhs, bounds = program
    objective = np.zeros(len(bounds))
    objective[plane] = -np.asarray(direction)
    result = linprog(
        objective,
        A_ub=csr_matrix(H),
        b_ub=upper,
        A_eq=csr_matrix(E) if len(E) else None,
        b_eq=rhs if len(E) else None,
        bounds=bounds,
        method=method,
        options={"presolve": presolve},
    )
    review = {"status": STATUS.get(result.status, str(result.status))}
    if not result.success:
        review["solver_message"] = result.message
        return review
    x = result.x
    upper_scale = np.maximum.reduce([np.ones_like(upper), np.abs(upper), abs(H) @ abs(x)])
    slack = max(0.0, float(max((H @ x - upper) / upper_scale)))
    if len(E):
        scale = np.maximum.reduce([np.ones_like(rhs), np.abs(rhs), abs(E) @ abs(x)])
        slack = max(slack, float(max(np.abs(E @ x - rhs) / scale)))
    for value, (lower, high) in zip(x, bounds, strict=True):
        if lower is not None:
            slack = max(slack, (lower - value) / max(1.0, abs(lower)))
        if high is not None:
            slack = max(slack, (value - high) / max(1.0, abs(high)))
    if not np.isfinite(slack):
        raise ValueError("non-finite primal residual")
    review["scaled_primal_violation"] = float(slack)
    review["support"] = float(-objective @ x)
    review["projected_witness"] = x[plane].tolist()
    return review


def evaluate(history, backward):
    result = []
    for i in range(1, 36):
        name = f"raw/{i}.json"
        raw = history.read(name)
        assert raw == backward.read("input/" + name), i
        model = json.loads(raw)
        reference = json.loads(backward.read(f"results/{i}.json"))
        assert model["model_id"] == reference["model_id"] and model["plane"] == reference["plane"]
        center = list(map(Fraction, reference["target_center"]))
        radius = list(map(Fraction, reference["target_radius"]))
        target = [(x - r, x + r) for x, r in zip(center, radius, strict=True)]
        samples = []
        for k in range(4):
            programs = {
                (profile, method): build(
                    model,
                    [(float(lo), float(hi)) for lo, hi in target],
                    k,
                    profile,
                    condensed,
                )
                for profile in PROFILES
                for method, condensed in (("highs-ds", False), ("highs-ipm", True))
            }
            for expected in (row for row in reference["samples"] if row["stage"] == k):
                direction = expected["direction"]
                outcomes = {
                    profile: {
                        method: solve(programs[profile, method], direction, model["plane"], method)
                        for method in ("highs-ds", "highs-ipm")
                    }
                    for profile in PROFILES
                }
                samples.append(
                    {
                        "stage": k,
                        "direction": direction,
                        "authored_exact": expected["support"],
                        "profiles": outcomes,
                    }
                )
        result.append(
            {
                "model_id": model["model_id"],
                "title": model["title"],
                "domain": model["domain"],
                "forecast": model["forecast"],
                "plane": model["plane"],
                "target": [[str(lo), str(hi)] for lo, hi in target],
                "samples": samples,
            }
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path)
    args = parser.parse_args()
    root = str(args.archives.resolve())
    history, hsha = open_capture(root, "feasible-history")
    backward, bsha = open_capture(root, "backward-reachability")
    with history, backward:
        records = evaluate(history, backward)
    counts = {p: Counter() for p in PROFILES}
    for model in records:
        for sample in model["samples"]:
            for profile, solvers in sample["profiles"].items():
                counts[profile].update(["/".join(row["status"] for row in solvers.values())])
    print(
        json.dumps(
            {
                "revision": REV,
                "scope": "Scientific prototype, not a performance benchmark or a formal general certificate.",
                "history_archive_sha256": hsha,
                "backward_archive_sha256": bsha,
                "scipy": scipy.__version__,
                "numpy": np.__version__,
                "comparison_order": [
                    "full-space HiGHS dual simplex",
                    "condensed HiGHS interior point",
                ],
                "counts": counts,
                "records": records,
            },
            indent=2,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
