#include <gmpxx.h>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <utility>
#include <vector>

namespace {
using Json = nlohmann::json;
using Rational = mpq_class;
using Vector = std::vector<Rational>;
using Matrix = std::vector<Vector>;
constexpr std::size_t horizon = 3;
static_assert(std::numeric_limits<double>::is_iec559 &&
              std::numeric_limits<double>::digits == 53);

void require(bool condition, const char *message) {
  if (!condition)
    throw std::runtime_error(message);
}

Rational exact(const Json &entry) {
  const auto value = entry.get<double>();
  require(std::isfinite(value), "expected finite binary64 input");
  return Rational(value);
}

Vector decode_vector(const Json &input) {
  Vector output;
  for (const auto &entry : input)
    output.push_back(exact(entry));
  return output;
}

Matrix decode_matrix(const Json &input) {
  const auto rows = input.at("rows").get<std::size_t>();
  const auto cols = input.at("cols").get<std::size_t>();
  const auto values = decode_vector(input.at("values"));
  require(values.size() == rows * cols, "matrix shape mismatch");
  Matrix output(rows, Vector(cols));
  auto source = values.begin();
  for (auto &row : output)
    for (auto &value : row)
      value = *source++;
  return output;
}

Json encode(const Vector &input) {
  auto result = Json::array();
  for (const auto &entry : input)
    result.push_back(entry.get_str());
  return result;
}

Rational dot(const Vector &a, const Vector &b) {
  require(a.size() == b.size(), "dot product dimension mismatch");
  Rational result;
  for (std::size_t i = 0; i < a.size(); ++i)
    result += a[i] * b[i];
  return result;
}

Vector image(const Matrix &A, const Vector &x) {
  Vector result;
  for (const auto &row : A)
    result.push_back(dot(row, x));
  return result;
}

Matrix transpose(const Matrix &A) {
  require(!A.empty(), "empty matrix");
  Matrix result(A.front().size(), Vector(A.size()));
  for (std::size_t i = 0; i < A.size(); ++i)
    for (std::size_t j = 0; j < result.size(); ++j)
      result[j][i] = A[i][j];
  return result;
}

Vector add(Vector a, const Vector &b) {
  require(a.size() == b.size(), "vector sum dimension mismatch");
  for (std::size_t i = 0; i < a.size(); ++i)
    a[i] += b[i];
  return a;
}

class Factorization {
  Matrix lu;
  std::vector<std::size_t> row_order;
  bool nonsingular_{true};

public:
  explicit Factorization(Matrix A) : lu(std::move(A)), row_order(lu.size()) {
    require(
        std::all_of(lu.begin(), lu.end(),
                    [&](const auto &row) { return row.size() == lu.size(); }),
        "expected square transition matrix");
    std::iota(row_order.begin(), row_order.end(), std::size_t{0});
    for (std::size_t k = 0; k < lu.size(); ++k) {
      auto pivot = k;
      while (pivot < lu.size() && lu[pivot][k] == 0)
        ++pivot;
      if (pivot == lu.size()) {
        nonsingular_ = false;
        return;
      }
      std::swap(lu[k], lu[pivot]);
      std::swap(row_order[k], row_order[pivot]);
      for (std::size_t i = k + 1; i < lu.size(); ++i) {
        if (lu[i][k] == 0)
          continue;
        lu[i][k] /= lu[k][k];
        for (std::size_t j = k + 1; j < lu.size(); ++j)
          if (lu[k][j] != 0)
            lu[i][j] -= lu[i][k] * lu[k][j];
      }
    }
  }

  bool nonsingular() const { return nonsingular_; }

  Vector solve(const Vector &rhs) const {
    require(nonsingular_ && rhs.size() == lu.size(), "invalid linear solve");
    Vector x(rhs.size());
    for (std::size_t i = 0; i < x.size(); ++i) {
      x[i] = rhs[row_order[i]];
      for (std::size_t j = 0; j < i; ++j)
        if (lu[i][j] != 0)
          x[i] -= lu[i][j] * x[j];
    }
    for (std::size_t i = x.size(); i-- > 0;) {
      for (std::size_t j = i + 1; j < x.size(); ++j)
        if (lu[i][j] != 0)
          x[i] -= lu[i][j] * x[j];
      x[i] /= lu[i][i];
    }
    return x;
  }
};

Vector direction(const Vector &left, const Vector &right, const Rational &a,
                 const Rational &b) {
  Vector result;
  for (std::size_t i = 0; i < left.size(); ++i)
    result.push_back(a * left[i] + b * right[i]);
  return result;
}

Json run(const Json &data) {
  require(data.at("model_id") == "catalogue-2026/model-28/1", "expected building model");
  const auto A = decode_matrix(data.at("A"));
  const auto B = decode_matrix(data.at("B"));
  const auto G = decode_matrix(data.at("G"));
  const auto offset = decode_vector(data.at("offset"));
  const auto plane = data.at("plane").get<std::array<std::size_t, 2>>();
  const auto &constraints = data.at("constraints");
  require(constraints.at("terminal").empty(), "unsupported terminal rows");
  const Factorization primal(A), dual(transpose(A));
  require(primal.nonsingular() && dual.nonsingular(), "nonsingular A required");
  const auto Bt = transpose(B);
  auto center = decode_vector(data.at("initial"));
  std::array<Vector, horizon> drift;
  for (std::size_t k = 0; k < horizon; ++k) {
    require(constraints.at("positive_part").at(k).empty(), "unsupported budget rows");
    const auto &stage = constraints.at("stage").at(k);
    const auto weights = decode_matrix(stage.at("control"));
    require(weights.size() == 1 && weights[0] == Vector(Bt.size(), Rational{1}),
            "expected one unweighted control budget");
    for (const auto &name : {"state", "external"}) {
      for (const auto &value : stage.at(name).at("values"))
        require(exact(value) == 0, "expected no coupling in the budget row");
    }
    require(stage.at("bounds").at(0).at(0).is_null(), "expected upper budget only");
    drift[k] = add(offset, image(G, decode_vector(data.at("external").at(k))));
    center = add(image(A, center), drift[k]);
  }
  Vector lower, upper;
  for (std::size_t i = 0; i < center.size(); ++i) {
    const Rational radius = std::max(Rational{1}, Rational{abs(center[i])}) / 10;
    lower.push_back(center[i] - radius);
    upper.push_back(center[i] + radius);
    const auto &interval = constraints.at("state").at(horizon).at(i);
    if (!interval.at(0).is_null())
      lower[i] = std::max(lower[i], exact(interval.at(0)));
    if (!interval.at(1).is_null())
      upper[i] = std::min(upper[i], exact(interval.at(1)));
    require(lower[i] <= upper[i], "empty terminal intersection");
  }
  std::array<std::array<Vector, horizon + 1>, 2> basis;
  for (std::size_t coord = 0; coord < basis.size(); ++coord) {
    auto &sequence = basis[coord];
    sequence[0] = Vector(center.size());
    sequence[0].at(plane[coord]) = 1;
    for (std::size_t j = 0; j < horizon; ++j)
      sequence[j + 1] = dual.solve(sequence[j]);
  }
  Json samples = Json::array();
  for (const auto &input : data.at("full_history").at("samples")) {
    const auto k = input.at("stage").get<std::size_t>();
    const auto d = decode_vector(input.at("direction"));
    std::vector<Vector> actions(horizon - k);
    std::vector<Vector> states(horizon - k + 1);
    Vector multipliers(horizon - k);
    auto y = direction(basis[0][horizon - k], basis[1][horizon - k], d[0], d[1]);
    Vector x(center.size());
    for (std::size_t i = 0; i < x.size(); ++i)
      x[i] = y[i] >= 0 ? upper[i] : lower[i];
    Rational bound = dot(y, x);
    states.back() = x;
    for (std::size_t j = horizon; j > k; --j) {
      y = direction(basis[0][j - k], basis[1][j - k], d[0], d[1]);
      auto reward = image(Bt, y);
      for (auto &value : reward)
        value = -value;
      std::vector<std::size_t> order(Bt.size());
      std::iota(order.begin(), order.end(), std::size_t{0});
      std::stable_sort(order.begin(), order.end(), [&](auto i, auto h) { return reward[i] > reward[h]; });
      const auto &row = constraints.at("stage").at(j - 1);
      const auto capacity = exact(row.at("bounds").at(0).at(1));
      auto left = capacity;
      auto &u = actions[j - k - 1];
      u = Vector(Bt.size());
      Rational lambda{0};
      for (const auto axis : order) {
        const auto &interval = constraints.at("control").at(j - 1).at(axis);
        require(exact(interval.at(0)) == 0, "expected zero lower control bound");
        const auto maximum = exact(interval.at(1));
        if (reward[axis] > 0) {
          u[axis] = std::min(left, maximum);
          left -= u[axis];
          if (left == 0 && u[axis] > 0)
            lambda = reward[axis];
        }
      }
      multipliers[j - k - 1] = lambda;
      Rational control_bound = lambda * capacity;
      for (std::size_t axis = 0; axis < u.size(); ++axis) {
        const auto maximum = exact(constraints.at("control").at(j - 1).at(axis).at(1));
        control_bound += std::max(Rational{0}, Rational{reward[axis] - lambda}) * maximum;
      }
      require(control_bound == dot(reward, u), "budget dual bound mismatch");
      bound += control_bound - dot(y, drift[j - 1]);
      const auto effect = add(drift[j - 1], image(B, u));
      for (std::size_t i = 0; i < x.size(); ++i)
        x[i] -= effect[i];
      x = primal.solve(x);
      states[j - k - 1] = x;
    }
    bool feasible = true;
    for (std::size_t j = 0; j < states.size(); ++j) {
      for (std::size_t i = 0; i < x.size(); ++i) {
        const auto &interval = constraints.at("state").at(k + j).at(i);
        if ((!interval.at(0).is_null() && states[j][i] < exact(interval.at(0))) ||
            (!interval.at(1).is_null() && states[j][i] > exact(interval.at(1))))
          feasible = false;
      }
    }
    const Rational value = d[0] * x.at(plane[0]) + d[1] * x.at(plane[1]);
    require(value == bound, "exact support bound does not match the candidate");
    auto inputs = Json::array(), trace = Json::array();
    for (const auto &u : actions)
      inputs.push_back(encode(u));
    for (const auto &state : states)
      trace.push_back(encode(state));
    samples.push_back({{"stage", k}, {"direction", input.at("direction")},
                       {"status", feasible ? "exact-optimal" : "requires-coupled-state-solve"},
                       {"upper_bound", bound.get_str()}, {"states", std::move(trace)},
                       {"controls", std::move(inputs)}, {"budget_multipliers", encode(multipliers)}});
  }
  return {{"model_id", data.at("model_id")}, {"samples", std::move(samples)}};
}
} // namespace

int main(int argc, char **argv) try {
  require(argc == 2, "Usage: predecessor archived-model.json");
  std::ifstream source(argv[1]);
  require(static_cast<bool>(source), "cannot read source JSON");
  std::cout << run(Json::parse(source)).dump(2) << '\n';
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
