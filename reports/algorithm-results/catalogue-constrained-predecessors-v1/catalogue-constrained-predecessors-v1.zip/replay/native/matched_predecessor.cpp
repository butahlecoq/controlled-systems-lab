#ifdef MATCHED_PREDECESSOR_USE_IPOPT
#include <csl/adapters/convex/ipopt.hpp>
#else
#include <csl/adapters/lp/highs.hpp>
#include <csl/optimization/linear_program.hpp>
#endif

#include <nlohmann/json.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <variant>
#include <vector>

namespace {
namespace opt = csl::optimization;
using csl::Diagnostics;
using csl::Interval;
using csl::LinearProgramInput;
using csl::Matrix;
using csl::Vector;
using Json = nlohmann::json;
constexpr std::size_t horizon = 3;
constexpr std::array<std::array<double, 2>, 8> directions{{
    {1., 0.},
    {1., 1.},
    {0., 1.},
    {-1., 1.},
    {-1., 0.},
    {-1., -1.},
    {0., -1.},
    {1., -1.},
}};
constexpr std::array<std::string_view, 3> profiles{"authored", "saved_controls", "full"};

template <class T> T checked(std::variant<T, Diagnostics> result) {
    if (const auto *diagnostics = std::get_if<Diagnostics>(&result)) {
        throw std::runtime_error(diagnostics->at(0).field + ": " + diagnostics->at(0).explanation);
    }
    return std::get<T>(std::move(result));
}

Matrix matrix(const Json &value) {
    Matrix result{value.at("rows").get<std::size_t>(), value.at("cols").get<std::size_t>(),
                  value.at("values").get<Vector>()};
    if (result.rows * result.cols != result.values.size()) {
        throw std::runtime_error("invalid matrix dimensions");
    }
    return result;
}

std::optional<double> endpoint(const Json &value) {
    return value.is_null() ? std::nullopt : std::optional(value.get<double>());
}

Interval interval(const Json &value) { return {endpoint(value.at(0)), endpoint(value.at(1))}; }

struct StageRows {
    Matrix state;
    Matrix control;
    Matrix external;
    std::vector<Interval> bounds;
};

struct TerminalRows {
    Matrix state;
    std::vector<Interval> bounds;
};

struct PositivePartBudget {
    std::vector<std::size_t> axes;
    double upper;
};

std::vector<Interval> intervals(const Json &values) {
    std::vector<Interval> result;
    for (const auto &item : values) {
        result.push_back(interval(item));
    }
    return result;
}

struct Fixture {
    std::string id;
    Matrix a, b, g;
    Vector offset;
    std::vector<Vector> external;
    std::array<std::size_t, 2> plane;
    std::vector<Interval> target;
    std::vector<std::vector<Interval>> state_bounds, control_bounds;
    std::vector<StageRows> stages;
    std::vector<TerminalRows> terminal;
    std::array<std::vector<PositivePartBudget>, horizon> budgets;
};

Fixture parse(const Json &input) {
    Fixture result{input.at("model_id").get<std::string>(),
                   matrix(input.at("A")),
                   matrix(input.at("B")),
                   matrix(input.at("G")),
                   input.at("offset").get<Vector>(),
                   input.at("external").get<std::vector<Vector>>(),
                   input.at("plane").get<std::array<std::size_t, 2>>(),
                   intervals(input.at("target")),
                   {},
                   {},
                   {},
                   {},
                   {}};
    const auto &constraints = input.at("constraints");
    for (const auto &row : constraints.at("state")) {
        result.state_bounds.push_back(intervals(row));
    }
    for (const auto &row : constraints.at("control")) {
        result.control_bounds.push_back(intervals(row));
    }
    for (const auto &rows : constraints.at("stage")) {
        result.stages.push_back({matrix(rows.at("state")), matrix(rows.at("control")),
                                 matrix(rows.at("external")), intervals(rows.at("bounds"))});
    }
    for (const auto &rows : constraints.at("terminal")) {
        result.terminal.push_back({matrix(rows.at("state")), intervals(rows.at("bounds"))});
    }
    for (std::size_t k = 0; k < horizon; ++k) {
        for (const auto &group : constraints.at("positive_part").at(k)) {
            result.budgets[k].push_back({group.at("indices").get<std::vector<std::size_t>>(),
                                         group.at("upper").get<double>()});
        }
    }
    return result;
}

void assign(Vector &row, std::size_t column, const Matrix &map, std::size_t index, double sign) {
    for (std::size_t j = 0; j < map.cols; ++j) {
        row.at(column + j) = sign * map.values.at(index * map.cols + j);
    }
}

double external_shift(const Matrix &map, std::size_t index, const Vector &external) {
    double shift = 0.;
    for (std::size_t j = 0; j < map.cols; ++j) {
        shift += map.values.at(index * map.cols + j) * external.at(j);
    }
    return shift;
}

void append(LinearProgramInput &input, const Vector &coefficients, Interval bounds) {
    auto &matrix = input.constraints;
    for (std::size_t j = 0; j < coefficients.size(); ++j) {
        if (coefficients[j] == 0.) {
            continue;
        }
        matrix.column_indices.push_back(j);
        matrix.values.push_back(coefficients[j]);
    }
    matrix.row_offsets.push_back(matrix.values.size());
    ++matrix.rows;
    input.rows.push_back(bounds);
}

LinearProgramInput build(const Fixture &data, std::size_t start, std::string_view profile) {
    const auto nx = data.a.rows, nu = data.b.cols, remaining = horizon - start;
    const auto state_count = (remaining + 1) * nx;
    const auto base_count = state_count + remaining * nu;
    auto total = base_count;
    const bool full = profile == "full";
    if (full) {
        for (auto k = start; k < horizon; ++k) {
            for (const auto &group : data.budgets[k]) {
                total += group.axes.size();
            }
        }
    }
    const std::string tag = data.id + "/" + std::string(profile) + "/" + std::to_string(start);
    LinearProgramInput program{{{"catalogue-matched-predecessor/" + data.id}, {tag}},
                               Vector(total),
                               0.,
                               {0, total, {0}, {}, {}},
                               std::vector<Interval>(total),
                               {}};
    for (auto k = start; k <= horizon; ++k) {
        const auto local = k - start;
        const auto state_column = local * nx;
        if (full) {
            for (std::size_t i = 0; i < nx; ++i) {
                program.variables[state_column + i] = data.state_bounds.at(k).at(i);
            }
        }
        if (k == horizon) {
            break;
        }
        const auto control_column = state_count + local * nu;
        for (std::size_t i = 0; i < nu; ++i) {
            program.variables[control_column + i] =
                profile == "authored" ? Interval{-1., 1.} : data.control_bounds.at(k).at(i);
        }
        for (std::size_t i = 0; i < nx; ++i) {
            Vector row(total);
            assign(row, state_column, data.a, i, -1.);
            assign(row, control_column, data.b, i, -1.);
            row[state_column + nx + i] = 1.;
            const auto rhs = external_shift(data.g, i, data.external.at(k)) + data.offset.at(i);
            append(program, row, {rhs, rhs});
        }
        if (full && !data.stages.empty()) {
            const auto &rows = data.stages.at(k);
            for (std::size_t i = 0; i < rows.bounds.size(); ++i) {
                Vector row(total);
                assign(row, state_column, rows.state, i, 1.);
                assign(row, control_column, rows.control, i, 1.);
                const auto known = external_shift(rows.external, i, data.external.at(k));
                auto bounds = rows.bounds[i];
                if (bounds.lower) {
                    *bounds.lower -= known;
                }
                if (bounds.upper) {
                    *bounds.upper -= known;
                }
                append(program, row, bounds);
            }
        }
    }
    auto aux = base_count;
    if (full) {
        for (auto k = start; k < horizon; ++k) {
            const auto control_column = state_count + (k - start) * nu;
            for (const auto &group : data.budgets[k]) {
                Vector sum(total);
                for (const auto axis : group.axes) {
                    if (axis >= nu) {
                        throw std::runtime_error("budget axis outside control");
                    }
                    Vector row(total);
                    row[control_column + axis] = 1.;
                    row[aux] = -1.;
                    program.variables[aux] = {0., std::nullopt};
                    sum[aux++] = 1.;
                    append(program, row, {std::nullopt, 0.});
                }
                append(program, sum, {std::nullopt, group.upper});
            }
        }
        for (const auto &rows : data.terminal) {
            for (std::size_t i = 0; i < rows.bounds.size(); ++i) {
                Vector row(total);
                assign(row, remaining * nx, rows.state, i, 1.);
                append(program, row, rows.bounds[i]);
            }
        }
    }
    for (std::size_t i = 0; i < nx; ++i) {
        Vector row(total);
        row[remaining * nx + i] = 1.;
        append(program, row, data.target.at(i));
    }
    return program;
}

#ifndef MATCHED_PREDECESSOR_USE_IPOPT
// Use the same bounded transform as the SDK convex row-scaling experiment.
std::optional<LinearProgramInput> scaled_retry(const LinearProgramInput &source) {
    constexpr double removal_threshold = 1e-12;
    constexpr int maximum_power = 20;
    constexpr double maximum_magnitude = 0x1p20;
    auto input = source;
    auto &matrix = input.constraints;
    bool changed = false;
    for (std::size_t row = 0; row < matrix.rows; ++row) {
        auto minimum = std::numeric_limits<double>::infinity();
        const auto begin = matrix.row_offsets[row], end = matrix.row_offsets[row + 1];
        for (auto j = begin; j < end; ++j) {
            minimum = std::min(minimum, std::abs(matrix.values[j]));
        }
        if (minimum > removal_threshold) {
            continue;
        }
        int power = 1;
        while (power <= maximum_power && std::scalbn(minimum, power) <= removal_threshold) {
            ++power;
        }
        if (power > maximum_power) {
            return std::nullopt;
        }
        const auto scale = [power](double &value) {
            const auto result = std::scalbn(value, power);
            if (!std::isfinite(result) || std::abs(result) > maximum_magnitude ||
                std::scalbn(result, -power) != value) {
                return false;
            }
            value = result;
            return true;
        };
        for (auto j = begin; j < end; ++j) {
            if (!scale(matrix.values[j])) {
                return std::nullopt;
            }
        }
        auto &bounds = input.rows[row];
        if ((bounds.lower && !scale(*bounds.lower)) || (bounds.upper && !scale(*bounds.upper))) {
            return std::nullopt;
        }
        changed = true;
    }
    if (!changed) {
        return std::nullopt;
    }
    input.identity.program.value += "/bounded-row-scaling";
    return input;
}

#endif

std::string_view label(csl::MathematicalOutcome outcome) {
    using Outcome = csl::MathematicalOutcome;
    switch (outcome) {
    case Outcome::optimal:
        return "optimal";
    case Outcome::infeasible:
        return "infeasible";
    case Outcome::unbounded:
        return "unbounded";
    case Outcome::infimum_not_attained:
        return "infimum-not-attained";
    case Outcome::undetermined:
        return "undetermined";
    }
    throw std::runtime_error("unexpected mathematical status");
}

Json solve(const auto &registration, const csl::ExecutionContext &context,
           LinearProgramInput &input, const Fixture &fixture, const auto &direction) {
    input.objective.at(fixture.plane[0]) = -direction[0];
    input.objective.at(fixture.plane[1]) = -direction[1];
#ifdef MATCHED_PREDECESSOR_USE_IPOPT
    // The provider takes quadratic objectives. A zero Hessian leaves the LP cost unchanged.
    const auto dimension = input.objective.size();
    const auto result = opt::make_convex_program(
        {input.identity,
         csl::QuadraticTerminal{Matrix{dimension, dimension, Vector(dimension * dimension)},
                                input.objective, input.offset},
         input.constraints, input.variables, input.rows, std::nullopt});
    const auto *candidate = std::get_if<csl::ConvexProgram>(&result);
    if (!candidate) {
        throw std::runtime_error("linear-objective convex program construction failed");
    }
    const auto &program = *candidate;
#else
    const auto program = checked(opt::make_linear_program(input));
#endif
    auto solver = registration.factory(program);
    if (!solver) {
        throw std::runtime_error("backend did not create an LP workspace");
    }
    const auto outcome = solver->solve(program, context);
    if (const auto *refused = std::get_if<csl::Unsupported>(&outcome)) {
        Json messages = Json::array();
        for (const auto &diagnostic : refused->diagnostics) {
            messages.push_back(
                {{"field", diagnostic.field}, {"explanation", diagnostic.explanation}});
        }
        return {{"status", "unsupported"}, {"diagnostics", std::move(messages)}};
    }
    const auto &solved = std::get<csl::ProgramResult>(outcome);
    Json evidence{{"status", label(solved.outcome.value)},
                  {"termination", static_cast<int>(solved.termination)},
                  {"diagnostics", solved.raw_diagnostics}};
    if (solved.outcome.value == csl::MathematicalOutcome::optimal && solved.primal) {
        const auto &state = *solved.primal;
        evidence["support"] =
            direction[0] * state.at(fixture.plane[0]) + direction[1] * state.at(fixture.plane[1]);
        evidence["witness"] = state;
    }
    return evidence;
}
} // namespace

int main(int argc, char **argv) try {
    if (argc != 2) {
        throw std::runtime_error("usage: matched_predecessor input.json");
    }
    std::ifstream source(argv[1]);
    const auto input = Json::parse(source);
    const auto fixture = parse(input);
#ifdef MATCHED_PREDECESSOR_USE_IPOPT
    const auto provider = checked(csl::adapters::convex::make_ipopt_registration());
#else
    const auto provider = checked(csl::adapters::lp::make_highs_registration());
#endif
    const csl::ExecutionContext context{
        std::make_shared<const csl::ResourcePolicy>(csl::ResourcePolicy{1, 1, 1, {}}),
        {},
        {},
        {1e-8, 1e-8},
        "catalogue-matched-predecessor"};
    auto samples = Json::array();
    for (std::size_t k = 0; k <= horizon; ++k) {
        std::array programs{build(fixture, k, profiles[0]), build(fixture, k, profiles[1]),
                            build(fixture, k, profiles[2])};
#ifndef MATCHED_PREDECESSOR_USE_IPOPT
        std::array scaled{scaled_retry(programs[0]), scaled_retry(programs[1]),
                          scaled_retry(programs[2])};
#endif
        for (const auto &direction : directions) {
            auto result = Json::object();
            for (std::size_t i = 0; i < profiles.size(); ++i) {
                auto evidence = solve(provider, context, programs[i], fixture, direction);
#ifndef MATCHED_PREDECESSOR_USE_IPOPT
                if (evidence.at("status") == "unsupported" && scaled[i]) {
                    evidence["scaled_retry"] =
                        solve(provider, context, *scaled[i], fixture, direction);
                }
#endif
                result[profiles[i]] = std::move(evidence);
            }
            samples.push_back(
                {{"stage", k}, {"direction", direction}, {"profiles", std::move(result)}});
        }
    }
    const Json report{{"model_id", fixture.id},
                      {"input_sha256", input.at("input_sha256")},
                      {"domain", input.at("domain")},
                      {"forecast", input.at("forecast")},
                      {"backend", provider.identity.id.value},
                      {"backend_version", provider.identity.version},
                      {"samples", std::move(samples)}};
    std::cout << report.dump(2) << '\n';
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
}
