"""Check the building witness and relaxation upper bound with rational arithmetic."""

import json
import sys
from fractions import Fraction
from pathlib import Path

from prepare_inputs import BACKWARD_SHA, HISTORY_SHA, checked_zip

sys.set_int_max_str_digits(16000)
root = Path(__file__).resolve().parent


def matrix(document):
    values = list(map(Fraction, document["values"]))
    cols = document["cols"]
    return [values[i * cols : (i + 1) * cols] for i in range(document["rows"])]


def matvec(a, x):
    return [sum(c * v for c, v in zip(row, x, strict=True) if c and v) for row in a]


def dot(a, b):
    return sum(x * y for x, y in zip(a, b, strict=True) if x and y)


def intervals(values, bounds):
    return all(
        (lo is None or Fraction(lo) <= v) and (hi is None or v <= Fraction(hi))
        for v, (lo, hi) in zip(values, bounds, strict=True)
    )


with checked_zip(root / "backward.zip", BACKWARD_SHA) as archive:
    reference = json.loads(archive.read("results/28.json"))
raw_input = (root / "building-matched-input.json").read_bytes()
with checked_zip(root / "history.zip", HISTORY_SHA) as archive:
    assert raw_input == archive.read("raw/28.json")
input_data = json.loads(raw_input)
native = json.loads((root / "building-exact.json").read_text())
prototype = json.loads((root.parent / "outcome.json").read_text())["records"][27]
assert (
    native["model_id"] == input_data["model_id"] == reference["model_id"] == prototype["model_id"]
)
A, B, G = (matrix(input_data[key]) for key in ("A", "B", "G"))
bounds = input_data["constraints"]
plane = input_data["plane"]
assert len(reference["dual_basis"]) == 2
bases = [[list(map(Fraction, row)) for row in axis] for axis in reference["dual_basis"]]
AT = list(zip(*A, strict=True))
BT = list(zip(*B, strict=True))
for axis, basis in zip(plane, bases, strict=True):
    assert len(basis) == 4
    assert basis[0] == [int(axis == i) for i in range(len(A))]
    for j in range(3):
        assert matvec(AT, basis[j + 1]) == basis[j]
center, radius = (
    list(map(Fraction, reference[name])) for name in ("target_center", "target_radius")
)
terminal = list(
    zip(
        [c - r for c, r in zip(center, radius, strict=True)],
        [c + r for c, r in zip(center, radius, strict=True)],
        strict=True,
    )
)
terminal_intersection = [
    (
        max(lo, Fraction(xlo)) if xlo is not None else lo,
        min(hi, Fraction(xhi)) if xhi is not None else hi,
    )
    for (lo, hi), (xlo, xhi) in zip(terminal, bounds["state"][-1], strict=True)
]
assert not bounds["terminal"] and not any(bounds["positive_part"])
drift = [
    [
        a + c
        for a, c in zip(
            matvec(G, list(map(Fraction, external))),
            map(Fraction, input_data["offset"]),
            strict=True,
        )
    ]
    for external in input_data["external"]
]
max_delta = 0.0
certified = []
for result, expected in zip(native["samples"], prototype["samples"], strict=True):
    start = result["stage"]
    assert (start, result["direction"]) == (expected["stage"], expected["direction"])
    x = [list(map(Fraction, row)) for row in result["states"]]
    u = [list(map(Fraction, row)) for row in result["controls"]]
    multipliers = list(map(Fraction, result["budget_multipliers"]))
    assert len(x) == 4 - start and len(u) == len(multipliers) == 3 - start
    dx, dy = map(Fraction, result["direction"])
    q = [
        [dx * a + dy * b for a, b in zip(left, right, strict=True)]
        for left, right in zip(*bases, strict=True)
    ]
    upper_bound = sum(
        max(c * lo, c * hi)
        for c, (lo, hi) in zip(q[-1 - start], terminal_intersection, strict=True)
    )
    assert intervals(x[-1], terminal)
    for i, (command, lam) in enumerate(zip(u, multipliers, strict=True)):
        k = start + i
        stage = bounds["stage"][k]
        assert stage["control"]["values"] == [1] * len(command)
        assert not any(stage["state"]["values"]) and not any(stage["external"]["values"])
        [[lo, cap]] = stage["bounds"]
        assert lo is None and lam >= 0 and sum(command) <= cap
        control_intervals = bounds["control"][k]
        assert all(lo == 0 and hi is not None for lo, hi in control_intervals)
        assert intervals(command, control_intervals)
        expected_state = [
            a + b + c for a, b, c in zip(matvec(A, x[i]), matvec(B, command), drift[k], strict=True)
        ]
        assert expected_state == x[i + 1]
        reward = [-v for v in matvec(BT, q[i + 1])]
        upper_bound += (
            lam * Fraction(cap)
            + sum(
                max(0, c - lam) * Fraction(hi)
                for c, (_, hi) in zip(reward, control_intervals, strict=True)
            )
            - dot(q[i + 1], drift[k])
        )
    actual = dot((dx, dy), [x[0][p] for p in plane])
    assert actual == upper_bound == Fraction(result["upper_bound"])
    valid = all(intervals(state, bounds["state"][start + j]) for j, state in enumerate(x))
    assert valid == (result["status"] == "exact-optimal")
    if valid:
        ref = expected["profiles"]["full"]["highs-ipm"]["support"]
        error = abs(ref - float(actual)) / max(1, abs(ref))
        assert error <= 1e-7
        max_delta = max(max_delta, error)
        certified.append((start, result["direction"]))
print(
    json.dumps(
        {
            "certificate_count": len(certified),
            "certified": certified,
            "max_scaled_delta": max_delta,
        },
        indent=2,
    )
)
