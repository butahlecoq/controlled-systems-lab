"""Verify the matched captures and export only the C++ replay's concrete inputs."""

import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile

HISTORY_SHA = "b393255e8c91049363a8e718e2063e04fc2f31c0f56e69e4e587a99a5926c92a"
BACKWARD_SHA = "4805124a15e87f5738a295072c5ecd12dec8719971acc8e9be352a7c797a3ec8"


def checked_zip(path, digest):
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise ValueError(f"unexpected archive digest for {path}")
    return ZipFile(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("history", type=Path)
    parser.add_argument("backward", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    args.destination.mkdir(parents=True, exist_ok=True)
    with (
        checked_zip(args.history, HISTORY_SHA) as history,
        checked_zip(args.backward, BACKWARD_SHA) as backward,
    ):
        for number in range(1, 36):
            key = f"raw/{number}.json"
            source = history.read(key)
            if source != backward.read("input/" + key):
                raise ValueError(f"archive records differ: {key}")
            model = json.loads(source)
            archived = json.loads(backward.read(f"results/{number}.json"))
            if archived["model_id"] != model["model_id"] or archived["plane"] != model["plane"]:
                raise ValueError(f"target does not belong to {key}")
            center = list(map(Fraction, archived["target_center"]))
            half_width = list(map(Fraction, archived["target_radius"]))
            model["target"] = [
                [float(a - r), float(a + r)] for a, r in zip(center, half_width, strict=True)
            ]
            model["input_sha256"] = hashlib.sha256(source).hexdigest()
            for field in ("full_history", "intervals_only"):
                del model[field]
            target = args.destination / f"{number}.json"
            target.write_text(json.dumps(model, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
