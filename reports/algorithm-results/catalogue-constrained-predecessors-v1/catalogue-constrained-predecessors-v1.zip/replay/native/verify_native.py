"""Check native suffix witnesses against archived dynamics and original domain rows."""

import argparse
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path

import numpy as np

THRESHOLD = 1e-7


def matrix(value):
    return np.asarray(value["values"]).reshape(value["rows"], value["cols"])


def max_violation(value, interval, scale):
    lower, upper = interval
    if lower is not None:
        scale = max(scale, abs(lower))
    if upper is not None:
        scale = max(scale, abs(upper))
    return max(
        0.0,
        (lower - value) / scale if lower is not None else 0.0,
        (value - upper) / scale if upper is not None else 0.0,
    )


def check_intervals(values, intervals):
    return max(
        (
            max_violation(value, bound, max(1.0, abs(value)))
            for value, bound in zip(values, intervals, strict=True)
        ),
        default=0.0,
    )


def check_witness(model, sample, profile, primal):
    A, B, G = (matrix(model[key]) for key in ("A", "B", "G"))
    nx, nu = B.shape
    start = sample["stage"]
    remaining = 3 - start
    state_count = (remaining + 1) * nx
    base_count = state_count + remaining * nu
    states = np.asarray(primal[:state_count]).reshape(remaining + 1, nx)
    controls = np.asarray(primal[state_count:base_count]).reshape(remaining, nu)
    con = model["constraints"]
    error = check_intervals(states[-1], model["target"])
    x0 = states[0, model["plane"]]
    projected = float(x0 @ sample["direction"])
    for j, control in enumerate(controls):
        k = start + j
        ext = model["external"][k]
        expected = A @ states[j] + B @ control + G @ ext + model["offset"]
        scale = np.maximum(
            1.0,
            abs(A) @ abs(states[j])
            + abs(B) @ abs(control)
            + abs(G) @ np.abs(ext)
            + np.abs(model["offset"])
            + abs(states[j + 1]),
        )
        error = max(error, float(max(abs(expected - states[j + 1]) / scale)))
        bounds = [(-1.0, 1.0)] * nu if profile == "authored" else con["control"][k]
        error = max(error, check_intervals(control, bounds))
        if profile == "full":
            if con["stage"]:
                stage = con["stage"][k]
                F, H, W = (matrix(stage[key]) for key in ("state", "control", "external"))
                values = F @ states[j] + H @ control + W @ ext
                row_scale = (
                    1 + abs(F) @ abs(states[j]) + abs(H) @ abs(control) + abs(W) @ np.abs(ext)
                )
                error = max(
                    error,
                    *(
                        max_violation(v, bounds, s)
                        for v, bounds, s in zip(values, stage["bounds"], row_scale, strict=True)
                    ),
                )
            for group in con["positive_part"][k]:
                positive = float(np.maximum(control[group["indices"]], 0.0).sum())
                error = max(
                    error,
                    max_violation(positive, (None, group["upper"]), max(1, positive)),
                )
    if profile == "full":
        for k, state in enumerate(states, start):
            error = max(error, check_intervals(state, con["state"][k]))
        for constraint in con["terminal"]:
            F = matrix(constraint["state"])
            error = max(
                error,
                *(
                    max_violation(v, b, s)
                    for v, b, s in zip(
                        F @ states[-1],
                        constraint["bounds"],
                        1 + abs(F) @ abs(states[-1]),
                        strict=True,
                    )
                ),
            )
    return projected, float(error)


def main():
    import sys

    sys.set_int_max_str_digits(16000)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("native", type=Path)
    parser.add_argument("prototype", type=Path)
    parser.add_argument("--ipopt", type=Path)
    options = parser.parse_args()
    inputs = json.loads((options.prototype / "outcome.json").read_text())["records"]
    intervals = json.loads((options.prototype / "interval-certificates-final.json").read_text())[
        "records"
    ]
    certifiably_empty = json.loads((options.prototype / "summary.json").read_text())[
        "analytically_empty_roots"
    ]
    counts = {profile: Counter() for profile in ("authored", "saved_controls", "full")}
    checked_counts = Counter()
    ipopt_counts = Counter()
    failures, exceptions = [], []
    max_residual = max_gap = 0.0
    for i, reference in enumerate(inputs, 1):
        model = json.loads((options.native / f"input/{i}.json").read_text())
        native = json.loads((options.native / f"raw/{i}.json").read_text())
        ident = reference["model_id"]
        assert native["model_id"] == ident == model["model_id"]
        for key in ("input_sha256", "domain", "forecast"):
            assert model[key] == native[key]
        assert len(native["samples"]) == 32
        alternative = {}
        if options.ipopt is not None and (options.ipopt / f"{i}.json").is_file():
            candidate = json.loads((options.ipopt / f"{i}.json").read_text())
            for name in ("model_id", "input_sha256", "domain", "forecast"):
                assert candidate[name] == native[name]
            assert candidate["backend"] == "csl.convex.ipopt"
            assert len(candidate["samples"]) == len(native["samples"])
            alternative = {
                (row["stage"], tuple(row["direction"])): row["profiles"]
                for row in candidate["samples"]
            }
            assert len(alternative) == len(native["samples"])
        for raw, expected, exact in zip(
            native["samples"], reference["samples"], intervals[ident], strict=True
        ):
            assert raw["stage"] == expected["stage"] == exact["stage"]
            assert raw["direction"] == expected["direction"] == exact["direction"]
            for profile, primary in raw["profiles"].items():
                actual = primary.get("scaled_retry", primary)
                if actual is not primary:
                    counts[profile].update([f"retry/{actual['status']}"])
                counts[profile].update([primary["status"]])
                alt = alternative.get((raw["stage"], tuple(raw["direction"])))
                use_ipopt = alt is not None and actual["status"] in {
                    "unsupported",
                    "undetermined",
                }
                if use_ipopt:
                    actual = alt[profile]
                    counts[profile].update([f"ipopt/{actual['status']}"])
                position = {
                    "model_id": ident,
                    "stage": raw["stage"],
                    "direction": raw["direction"],
                    "profile": profile,
                }
                if profile == "authored":
                    status, support = (
                        "optimal",
                        float(Fraction(expected["authored_exact"])),
                    )
                elif profile == "saved_controls":
                    status = exact["status"].removeprefix("exact-")
                    support = exact.get("rounded")
                elif str(i) in certifiably_empty:
                    status, support = "infeasible", None
                else:
                    result = expected["profiles"]["full"]["highs-ipm"]
                    status, support = result["status"], result.get("support")
                if actual["status"] in {"unsupported", "undetermined"}:
                    exceptions.append(
                        {
                            **position,
                            "actual": actual["status"],
                            "expected": status,
                            "primary": primary["status"],
                        }
                    )
                    continue
                if actual["status"] != status:
                    failures.append({**position, "actual": actual["status"], "expected": status})
                    continue
                if status == "optimal":
                    value, slack = check_witness(model, raw, profile, actual["witness"])
                    error = max(abs(value - support), abs(actual["support"] - support)) / max(
                        1.0, abs(support)
                    )
                    max_residual, max_gap = (
                        max(max_residual, slack),
                        max(max_gap, error),
                    )
                    if not all(math.isfinite(x) and x <= THRESHOLD for x in (error, slack)):
                        failures.append(
                            {
                                **position,
                                "scaled_error": error,
                                "scaled_violation": slack,
                            }
                        )
                        continue
                checked_counts[profile] += 1
                if use_ipopt:
                    ipopt_counts[profile] += 1
    print(
        json.dumps(
            {
                "counts": counts,
                "checked": checked_counts,
                "checked_ipopt": ipopt_counts,
                "fails": failures,
                "exceptions": exceptions,
                "max_scaled_original_domain_residual": max_residual,
                "max_scaled_support_gap": max_gap,
            },
            allow_nan=False,
            indent=2,
        )
    )
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
