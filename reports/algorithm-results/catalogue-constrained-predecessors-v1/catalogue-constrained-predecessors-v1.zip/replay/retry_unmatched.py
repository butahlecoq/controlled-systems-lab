"""Recheck full-domain numerical refusals in their original full-space formulation."""

import argparse
import json
from fractions import Fraction
from pathlib import Path

from prototype_predecessor import build, open_capture, solve


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path)
    parser.add_argument("outcome", type=Path)
    args = parser.parse_args()
    out = json.loads(args.outcome.read_bytes())
    archive, digest = open_capture(
        str(args.archives.resolve()),
        "feasible-history",
    )
    assert digest == out["history_archive_sha256"]
    cases = []
    with archive:
        for i, record in enumerate(out["records"], 1):
            refusals = [
                sample
                for sample in record["samples"]
                if sample["profiles"]["full"]["highs-ds"]["status"] == "numerical"
            ]
            if not refusals:
                continue
            source = json.loads(archive.read(f"raw/{i}.json"))
            assert source["model_id"] == record["model_id"]
            terminal = [[float(Fraction(value)) for value in bounds] for bounds in record["target"]]
            for row in refusals:
                program = build(source, terminal, row["stage"], "full", condensed=False)
                direction, plane = row["direction"], record["plane"]
                comparison = row["profiles"]["full"]["highs-ipm"]
                assert comparison["status"] == "optimal"
                retries = {
                    f"{method}-presolve-{presolve}": solve(
                        program, direction, plane, method, presolve
                    )
                    for method, presolve in (
                        ("highs-ds", False),
                        ("highs-ipm", True),
                        ("highs-ipm", False),
                    )
                }
                for attempt in retries.values():
                    if attempt["status"] == "optimal":
                        ref, candidate = comparison["support"], attempt["support"]
                        attempt["scaled_gap_to_condensed"] = abs(ref - candidate) / max(
                            1.0, abs(ref)
                        )
                cases.append(
                    {
                        "model": record["model_id"],
                        "stage": row["stage"],
                        "direction": direction,
                        "original": row["profiles"]["full"],
                        "retry": retries,
                    }
                )
    print(json.dumps(cases, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
