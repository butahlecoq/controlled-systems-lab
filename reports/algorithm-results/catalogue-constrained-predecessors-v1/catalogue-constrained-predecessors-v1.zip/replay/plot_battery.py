"""Plot matched predecessor rectangles for the Battery pair."""

import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

root = Path(__file__).resolve().parent
data = json.loads((root / "summary.json").read_text())["battery_rectangles"]
mpl.rcParams["svg.hashsalt"] = "1012-battery-matched-predecessor"
fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.8), layout="constrained", sharex=True, sharey=True)
for k, ax in enumerate(axes.flat):
    for name, color, style, face in (
        ("full", "#174f73", "-", "#87d4ee"),
        ("saved_controls", "#a84228", "--", "none"),
    ):
        (a, b), (c, d) = data[name][k]
        ax.add_patch(
            Rectangle(
                (a, c),
                b - a,
                d - c,
                edgecolor=color,
                facecolor=face,
                linewidth=2.0,
                linestyle=style,
                zorder=3 if name == "full" else 4,
            )
        )
    ax.set(xlim=(-38, 110), ylim=(-29, 183), title=f"Stage {k}")
    ax.axvline(0, color="#697680", linewidth=0.65)
    ax.axhline(0, color="#697680", linewidth=0.65)
    ax.grid(alpha=0.20)
fig.legend(
    axes[0, 0].patches,
    ["Saved controls and state bounds", "Saved controls alone"],
    loc="outside lower center",
    ncol=2,
    frameon=False,
)
axes[1, 0].set_xlabel("Battery 1 energy (MWh)")
axes[1, 1].set_xlabel("Battery 1 energy (MWh)")
axes[0, 0].set_ylabel("Battery 2 energy (MWh)")
axes[1, 0].set_ylabel("Battery 2 energy (MWh)")
fig.suptitle("Which battery states can reach the same terminal target?")
fig.savefig(root / "battery-predecessor.svg", metadata={"Date": None})
fig.savefig(root / "battery-predecessor.png", dpi=170)
