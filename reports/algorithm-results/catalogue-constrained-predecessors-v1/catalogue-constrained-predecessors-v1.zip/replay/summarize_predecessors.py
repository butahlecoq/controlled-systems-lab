"""Audit the predecessor prototype, including analytic controls on the comparison."""

import argparse
import json
import math
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

from native.prepare_inputs import HISTORY_SHA, checked_zip
from prototype_predecessor import PROFILES

TOL = 1e-7


def battery_rectangles(record, target, full):
    assert record["A"]["values"] == [1, 0, 0, 1]
    assert record["G"]["values"] == [0, 0] and record["offset"] == [0, 0]
    B = list(map(Fraction, record["B"]["values"]))
    assert B[2:6] == [0, 0, 0, 0]
    con = record["constraints"]
    assert not (con["stage"] or con["terminal"] or any(con["positive_part"]))
    rect = target
    rectangles = [rect]
    for k in range(2, -1, -1):
        initial = []
        for coord in range(2):
            contributions = []
            for j in range(4):
                limits = con["control"][k][j]
                contributions.append(sorted(B[coord * 4 + j] * Fraction(value) for value in limits))
            lower, upper = rect[coord]
            lower -= sum(term[1] for term in contributions)
            upper -= sum(term[0] for term in contributions)
            if full:
                low, high = con["state"][k][coord]
                lower = max(lower, Fraction(low))
                upper = min(upper, Fraction(high))
            initial.append((lower, upper))
        rect = initial
        rectangles.append(rect)
    return rectangles[::-1]


def main():
    sys.set_int_max_str_digits(16000)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path)
    parser.add_argument("outcome", type=Path)
    args = parser.parse_args()
    data = json.loads(args.outcome.read_bytes())
    assert len(data["records"]) == 35
    classifications = {p: Counter() for p in PROFILES}
    solver_status = {p: Counter() for p in PROFILES}
    variance = Counter()
    issues = {p: {} for p in PROFILES}
    status_issues = {p: {} for p in PROFILES}
    max_scaled_gap = {p: 0 for p in PROFILES}
    max_residual = {p: 0 for p in PROFILES}
    empty_terminal, battery = {}, {}
    with checked_zip(args.archives / "history.zip", HISTORY_SHA) as archive:
        for i, record in enumerate(data["records"], 1):
            model = json.loads(archive.read(f"raw/{i}.json"))
            assert record["model_id"] == model["model_id"]
            target = [tuple(map(Fraction, v)) for v in record["target"]]
            for j, ((lo, hi), (xlo, xhi)) in enumerate(
                zip(target, model["constraints"]["state"][-1], strict=True)
            ):
                if (xlo is not None and hi < Fraction(xlo)) or (
                    xhi is not None and lo > Fraction(xhi)
                ):
                    empty_terminal[i] = {
                        "coordinate": j + 1,
                        "target": [str(lo), str(hi)],
                        "state": [xlo, xhi],
                    }
                    break
            assert len(record["samples"]) == 32
            if i == 5:
                battery = {
                    p: battery_rectangles(model, target, p == "full")
                    for p in ("saved_controls", "full")
                }
            for row in record["samples"]:
                reviewed = {}
                for profile, solvers in row["profiles"].items():
                    a, b = solvers.values()
                    statuses = (a["status"], b["status"])
                    solver_status[profile].update(["/".join(statuses)])
                    if statuses != ("optimal", "optimal"):
                        key = "/".join(statuses)
                        counts = status_issues[profile].setdefault(i, Counter())
                        counts[key] += 1
                        classifications[profile][key] += 1
                        continue
                    v, w = a["support"], b["support"]
                    diff = abs(v - w) / max(1, abs(v), abs(w))
                    residual = max(a["scaled_primal_violation"], b["scaled_primal_violation"])
                    truth = (
                        float(Fraction(row["authored_exact"])) if profile == "authored" else None
                    )
                    exact_error = (
                        max(abs(v - truth), abs(w - truth)) / max(1, abs(truth))
                        if truth is not None
                        else 0
                    )
                    max_scaled_gap[profile] = max(max_scaled_gap[profile], diff)
                    max_residual[profile] = max(max_residual[profile], residual)
                    if max(diff, residual, exact_error) > TOL:
                        issues[profile].setdefault(i, []).append(
                            {
                                "stage": row["stage"],
                                "direction": row["direction"],
                                "full_space_support": v,
                                "condensed_support": w,
                                "scaled_gap": diff,
                                "scaled_violation": residual,
                                "exact_error": exact_error,
                            }
                        )
                        classifications[profile]["failed-cross-check"] += 1
                        continue
                    classifications[profile]["matched-optimal"] += 1
                    reviewed[profile] = v
                    if i == 5 and profile in battery:
                        bounds = battery[profile][row["stage"]]
                        exact = sum(
                            max(c * lo, c * hi)
                            for c, (lo, hi) in zip(row["direction"], bounds, strict=True)
                        )
                        assert math.isclose(v, float(exact), rel_tol=1e-12, abs_tol=1e-12)
                if "full" in reviewed and "saved_controls" in reviewed:
                    full, intervals = reviewed["full"], reviewed["saved_controls"]
                    gap = intervals - full
                    scale = max(1, abs(full), abs(intervals))
                    assert gap >= -TOL * scale, (i, row)
                    if gap > TOL * scale:
                        variance[i] += 1
    for i in empty_terminal:
        assert status_issues["full"][i] == Counter({"infeasible/infeasible": 32})
    print(
        json.dumps(
            {
                "threshold": TOL,
                "counts": classifications,
                "statuses": solver_status,
                "models_with_checked_strict_contraction": variance,
                "analytically_empty_roots": empty_terminal,
                "battery_rectangles": {
                    p: [[[float(a), float(b)] for a, b in stage] for stage in rec]
                    for p, rec in battery.items()
                },
                "max_scaled_gap_before_filter": max_scaled_gap,
                "max_scaled_violation_before_filter": max_residual,
                "failed_cross_checks": issues,
                "non_optimal_pairs": status_issues,
            },
            indent=2,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
