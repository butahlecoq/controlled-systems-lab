"""Certify predecessor supports for separable control intervals by exact transpose equations."""

import argparse
import json
import math
import sys
from collections import Counter
from fractions import Fraction
from itertools import pairwise
from pathlib import Path

from prototype_predecessor import open_capture


def dot(a, b):
    return sum(x * y for x, y in zip(a, b, strict=True))


def matrix(data):
    entries = list(map(Fraction, data["values"]))
    width = data["cols"]
    return [entries[k * width : (k + 1) * width] for k in range(data["rows"])]


def transpose(mat):
    return list(zip(*mat, strict=True))


def prove_invertible(matrix):
    # Nonzero determinant modulo an odd prime proves a nonzero dyadic determinant.
    prime = 2147483647
    rows = [[a.numerator * pow(a.denominator, -1, prime) % prime for a in row] for row in matrix]
    for col in range(len(rows)):
        pivot = next((k for k in range(col, len(rows)) if rows[k][col]), None)
        if pivot is None:
            raise ValueError("failed to certify nonsingularity modulo the chosen prime")
        rows[col], rows[pivot] = rows[pivot], rows[col]
        lead_inverse = pow(rows[col][col], -1, prime)
        for j in range(col + 1, len(rows)):
            factor = rows[j][col] * lead_inverse % prime
            if factor:
                rows[j][col:] = [
                    (x - factor * y) % prime
                    for x, y in zip(rows[j][col:], rows[col][col:], strict=True)
                ]


def data_for(model, reference):
    A, B, G = (matrix(model[key]) for key in ("A", "B", "G"))
    prove_invertible(A)
    C = [[Fraction(x) for x in row] for row in reference["dual_basis"][0]]
    D = [[Fraction(x) for x in row] for row in reference["dual_basis"][1]]
    assert len(C) == len(D) == 4
    for unit, basis in zip(reference["plane"], (C, D), strict=True):
        assert basis[0] == [int(j == unit) for j in range(len(A))]
        for u, v in pairwise(basis):
            assert [dot(col, v) for col in transpose(A)] == u
    offset = list(map(Fraction, model["offset"]))
    shifts = [
        [dot(row, list(map(Fraction, disturbance))) + a for row, a in zip(G, offset, strict=True)]
        for disturbance in model["external"]
    ]
    return transpose(B), C, D, shifts


def support(sample, data, target, controls):
    B_cols, C, D, drift = data
    dx, dy = map(Fraction, sample["direction"])
    stage = sample["stage"]
    basis = [
        [dx * u + dy * v for u, v in zip(c, d, strict=True)] for c, d in zip(C, D, strict=True)
    ]
    terminal = sum(
        max(q * lo, q * hi) for q, (lo, hi) in zip(basis[3 - stage], target, strict=True)
    )
    value = terminal
    for index, bounds in enumerate(controls[stage:], start=stage):
        q = basis[index + 1 - stage]
        value -= dot(q, drift[index])
        for axis, (column, interval) in enumerate(zip(B_cols, bounds, strict=True)):
            c = -dot(q, column)
            if c == 0:
                continue
            edge = interval[int(c > 0)]
            if edge is None:
                return {
                    "status": "exact-unbounded",
                    "input_stage": index,
                    "input_axis_zero_based": axis,
                    "improving_coefficient": str(c),
                    "ray_sign": 1 if c > 0 else -1,
                }
            value += c * Fraction(edge)
    return {"status": "exact-optimal", "value": str(value), "rounded": float(value)}


def main():
    sys.set_int_max_str_digits(16000)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path)
    parser.add_argument("outcome", type=Path)
    args = parser.parse_args()
    report = json.loads(args.outcome.read_bytes())
    capture, digest = open_capture(
        str(args.archives.resolve()),
        "backward-reachability",
    )
    assert digest == report["backward_archive_sha256"]
    counts = Counter()
    failed_presolve = Counter()
    result = {}
    numeric_error = 0.0
    with capture:
        for i, record in enumerate(report["records"], start=1):
            ref = json.loads(capture.read(f"results/{i}.json"))
            model = json.loads(capture.read(f"input/raw/{i}.json"))
            assert record["model_id"] == ref["model_id"] == model["model_id"]
            target = [tuple(map(Fraction, interval)) for interval in record["target"]]
            controls = model["constraints"]["control"]
            assert all(
                lo is None or hi is None or lo <= hi for stage in controls for lo, hi in stage
            )
            data = data_for(model, ref)
            rows = []
            for row in record["samples"]:
                authored_support = support(
                    row, data, target, [[[-1, 1]] * len(data[0]) for _ in range(3)]
                )
                assert Fraction(authored_support["value"]) == Fraction(row["authored_exact"])
                actual = support(row, data, target, controls)
                counts[actual["status"]] += 1
                for method, solver in row["profiles"]["saved_controls"].items():
                    status = solver["status"]
                    if actual["status"] == "exact-optimal":
                        assert status == "optimal"
                        rd = actual["rounded"]
                        error = abs(rd - solver["support"]) / max(1.0, abs(rd))
                        assert math.isfinite(error) and error <= 1e-7
                        numeric_error = max(numeric_error, error)
                    elif status != "unbounded":
                        failed_presolve[f"{method}/{status}"] += 1
                rows.append({"stage": row["stage"], "direction": row["direction"], **actual})
            result[record["model_id"]] = rows
    print(
        json.dumps(
            {
                "exact_counts": counts,
                "contradicted_solver_statuses": failed_presolve,
                "max_scaled_numerical_error": numeric_error,
                "records": result,
            },
            allow_nan=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
