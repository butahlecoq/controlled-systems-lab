"""Retest the certified open rays whose condensed presolved LP reported infeasibility."""

import argparse
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

from prototype_predecessor import build, open_capture, solve


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path)
    parser.add_argument("outcome", type=Path)
    args = parser.parse_args()
    report = json.loads(args.outcome.read_bytes())
    history, digest = open_capture(
        str(args.archives.resolve()),
        "feasible-history",
    )
    assert digest == report["history_archive_sha256"]
    replay = []
    with history:
        for i, record in enumerate(report["records"], start=1):
            refused = [
                row
                for row in record["samples"]
                if row["profiles"]["saved_controls"]["highs-ipm"]["status"] == "infeasible"
            ]
            if not refused:
                continue
            source = json.loads(history.read(f"raw/{i}.json"))
            terminal = [
                [float(Fraction(value)) for value in interval] for interval in record["target"]
            ]
            for row in refused:
                program = build(source, terminal, row["stage"], "saved_controls", condensed=True)
                result = solve(
                    program,
                    row["direction"],
                    record["plane"],
                    "highs-ipm",
                    presolve=False,
                )
                replay.append(
                    {
                        "model_id": record["model_id"],
                        "stage": row["stage"],
                        "direction": row["direction"],
                        "presolved": "infeasible",
                        **result,
                    }
                )
    print(
        json.dumps(
            {"counts": Counter(row["status"] for row in replay), "records": replay},
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
