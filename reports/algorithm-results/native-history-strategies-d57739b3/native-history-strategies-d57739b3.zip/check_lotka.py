"""Verify the portable Lotka–Volterra lesson and its native exchange links."""
import hashlib
import json
import math
from pathlib import Path
import sys


def load(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def linked(root, reference):
    path = (root / reference["path"]).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Unsafe saved reference")
    data = path.read_bytes()
    assert len(data) == reference["bytes"] and digest(data) == reference["sha256"]
    return json.loads(data)


def check(root):
    manifest = load(root / "manifest.json")
    for name, expected in manifest["files_sha256"].items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and digest(path.read_bytes()) == expected
    task = load(root / "task/syn-nl-lv-01.json")
    task_hash = digest(canonical(task))
    intervals = task["episode"]["intervals"]
    scope = task["objective"]["source_definition"]
    bounds = task["control_domains"]["continuous"]["bounds"]
    results = []
    for entry in manifest["lesson_attempts"]:
        directory = (root / entry["path"]).resolve()
        attempt = load(directory / "attempt.json")
        assert attempt["task_sha256"] == task_hash
        assert attempt["controller_id"] == entry["controller"]
        assert attempt["completed_holds"] == intervals
        assert attempt["algorithm_status"] == attempt["postcheck_status"] == attempt["render_status"] == "complete"
        states, controls = attempt["physical_states"], attempt["controls"]
        assert len(states) == intervals + 1 and len(controls) == intervals
        assert states[0] == [axis["initial"] for axis in task["model"]["states"]]
        terminal = math.fsum(
            w * ((state - target) / scale) ** 2
            for state, target, scale, w in zip(states[-1], scope["terminal_target"],
                                              scope["terminal_scale"], scope["terminal_weights"], strict=True)
        )
        running = scope["running_weight"] / intervals * math.fsum(
            ((value - target) / scale) ** 2
            for control in controls
            for value, target, scale in zip(control, scope["running_reference"],
                                            scope["running_scale"], strict=True)
        )
        asserted = attempt["physical_objective"]
        for field, actual in (("terminal", terminal), ("running", running), ("total", terminal + running)):
            assert math.isclose(actual, asserted[field], rel_tol=1e-12, abs_tol=1e-12)
        records = (directory / attempt["stage_records"]["path"]).read_text().splitlines()
        assert len(records) == intervals
        exchanges = 0
        for stage, reference in enumerate(records):
            record = linked(directory, json.loads(reference))
            assert record["update_index"] == stage
            assert record["observed_physical"] == states[stage]
            assert record["observed_next_physical"] == states[stage + 1]
            assert record["applied_control"] == controls[stage]
            assert all(lo <= value <= hi for value, (lo, hi) in zip(controls[stage], bounds, strict=True))
            query = linked(directory, record["native_query_capture"])
            requests = query["native_strategy_attempts"]
            for item in requests:
                request = linked(directory, item["request"])
                response = linked(directory, item["response"])
                assert request["task_sha256"] == response["task_sha256"] == task_hash
                assert request["absolute_update_index"] == stage
                exchange = response.get("solver_receipt")
                if exchange:
                    assert exchange["program_id"] == request["request_id"]
                    assert exchange["supplied_readback"] is True
                    assert exchange["provider"] == request["native_history_optimizer"]
                exchanges += 1
            assert requests[-1]["outcome"] == "accepted"
            strategy, module = (
                ("A", "csl.synthesis.reach-back")
                if entry["controller"] == "native-strategy-a-history-polytope/1"
                else ("B", "csl.synthesis.strategy-b")
            )
            if (
                response["status"] != "solved"
                or not exchange
                or exchange["strategy"] != strategy
                or exchange["strategy_module"] != module
                or request["native_history_strategy"] != strategy
                or response["policy_id"] != request["controller_id"]
                or request["controller_id"] != entry["controller"]
            ):
                raise ValueError("Accepted response or solver receipt does not identify this policy")
            first_control = len(states[stage]) * (len(request["predictor_stages"]) + 1)
            if response["primal"][first_control : first_control + len(bounds)] != controls[stage]:
                raise ValueError("Accepted native primal does not supply the applied first control")
            assert record["solve_receipt"]["independent_validation"]["accepted"]
        postcheck = load(directory / attempt["postcheck_record"])
        assert postcheck["postcheck_status"] == "complete"
        assert postcheck["task_sha256"] == task_hash
        results.append({"controller": entry["controller"], "intervals": intervals,
                        "native_exchanges": exchanges, "recomputed_cost": terminal + running})
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    check(Path(sys.argv[1]).resolve())
