#include <cmath>
#include <iostream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <string_view>
#include <syncstream>
#include <vector>
#include <new>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
static bool fail_new=false;
__attribute__((noinline)) void* operator new(std::size_t n){if(fail_new)throw std::bad_alloc{};if(auto p=std::malloc(n?n:1))return p;throw std::bad_alloc{};}
__attribute__((noinline)) void operator delete(void* p)noexcept{std::free(p);}
__attribute__((noinline)) void operator delete(void* p,std::size_t)noexcept{std::free(p);}
struct Clock {int id;const char* name;int calls;double seconds;};
struct Highs {const char* version()const{return "probe";}std::vector<Clock> getClockRecordsForDiagnostics()const{return {{0,"probe",1,1}};}};
constexpr const char* archive_hash="probe";
constexpr const char* clock_snapshot_patch_hash="probe";
constexpr const char* adapter_version="probe";
constexpr std::string_view clock_event_prefix="CSL_HIGHS_CLOCK/1 ";
void write_json_string(std::ostream& out, std::string_view value) {
    constexpr char hex[] = "0123456789abcdef";
    out << '"';
    for (const unsigned char character : value) {
        switch (character) {
        case '"': out << "\\\""; break;
        case '\\': out << "\\\\"; break;
        case '\b': out << "\\b"; break;
        case '\f': out << "\\f"; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        default:
            if (character < 0x20) {
                out << "\\u00" << hex[character >> 4] << hex[character & 0x0f];
            } else {
                out << static_cast<char>(character);
            }
        }
    }
    out << '"';
}

void emit_clock_event(const Highs& highs, std::uint64_t provider_call_index,
                      int native_call_status) noexcept {
    try {
        const auto clocks = highs.getClockRecordsForDiagnostics();
        std::ostringstream event;
        event << std::setprecision(std::numeric_limits<double>::max_digits10)
              << "{\"schema\":\"csl.highs-clock-group/1\",\"provider_call_index\":"
              << provider_call_index
              << ",\"capture_status\":\"captured\",\"highs_version\":";
        write_json_string(event, highs.version());
        event << ",\"highs_archive_sha256\":\"" << archive_hash
              << "\",\"clock_patch_sha256\":\"" << clock_snapshot_patch_hash
              << "\",\"native_call_status\":" << native_call_status
              << ",\"clocks\":[";
        for (std::size_t index = 0; index < clocks.size(); ++index) {
            if (index) event << ',';
            const auto& clock = clocks[index];
            const bool duration_available = std::isfinite(clock.seconds) && clock.seconds >= 0;
            const bool calls_available = clock.calls >= 0;
            const auto status = !duration_available || !calls_available ? "unavailable"
                              : clock.calls == 0 ? "uncalled" : "observed";
            event << "{\"id\":" << clock.id << ",\"name\":";
            write_json_string(event, clock.name);
            event << ",\"calls\":";
            if (duration_available && calls_available) event << clock.calls;
            else event << "null";
            event << ",\"elapsed_seconds\":";
            if (duration_available && calls_available) event << clock.seconds;
            else event << "null";
            event << ",\"status\":\"" << status << "\"}";
        }
        event << "]}";
        std::osyncstream output(std::cerr);
        output << clock_event_prefix << event.str() << '\n';
    } catch (...) {
        std::osyncstream(std::cerr)
            << clock_event_prefix
            << "{\"schema\":\"csl.highs-clock-group/1\",\"provider_call_index\":"
            << provider_call_index
            << ",\"capture_status\":\"unavailable\",\"highs_version\":\""
            << adapter_version << "\",\"highs_archive_sha256\":\"" << archive_hash
            << "\",\"clock_patch_sha256\":\"" << clock_snapshot_patch_hash
            << "\",\"native_call_status\":" << native_call_status
            << ",\"clocks\":[]}\n";
    }
}


int main(){std::set_terminate([]{std::fputs("TERMINATE from noexcept diagnostic path\n",stderr);std::_Exit(71);});Highs h;fail_new=true;emit_clock_event(h,0,0);fail_new=false;std::fputs("RETURNED despite diagnostic allocation failure\n",stderr);return 0;}
