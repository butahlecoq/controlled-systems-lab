import sys,json,hashlib,os,time,subprocess,statistics
from pathlib import Path
root=Path('/home/butahlecoq/.local/share/codex/worktrees/review05-resource-phase-20261104');sys.path.insert(0,str(root/'benchmarks/reporting/review05'))
from run_horizon_ladder import run_with_resource_receipt
from check_horizon_ladder import check_attempt
from highs_clock_events import parse_result_stdout,parse_stderr
out=Path(sys.argv[1]);out.mkdir();(out/'raw').mkdir();binary=Path('/home/butahlecoq/.local/share/codex/tmp/review05-highs-clocks-build/csl_review05_horizon_ladder')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={'schema':'review05.native-clock-pairs/1','binary_sha256':sha(binary.read_bytes()),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'claim':'descriptive interleaved same-binary native-clock mode observations; causal performance verdict inconclusive because concurrent builds and no isolated limiter profile','load_start':os.getloadavg(),'cpu_count':os.cpu_count(),'script_sha256':sha(Path(__file__).read_bytes()),'warmup_pairs_per_cell':1,'measured_pairs_per_cell':6,'timing_scope':'same OBS-enabled SynthesisWorkspace::run; clock export outside native solve timer but within synthesis','limits':'300s wall and helper POSIX CPU/address-space limits; wait4 whole-process resource receipt'}
(out/'capture.py').write_bytes(Path(__file__).read_bytes());rows=[]
with (out/'attempts.jsonl').open('x') as f:
 for rep in range(7):
  for h in (2,4,8):
   fixture=root/f'benchmarks/reporting/review05/scenarios/horizon01-t{h:02d}.json';fixturehash=sha(fixture.read_bytes())
   for strategy in ('csl.synthesis.reach-back','csl.synthesis.strategy-b'):
    for enabled in ((False,True) if (rep+h//2)%2 else (True,False)):
     aid=f't{h}-r{rep}-{strategy.rsplit(".",1)[1]}-clocks{int(enabled)}';env=os.environ.copy();env.pop('CSL_HIGHS_INTERNAL_CLOCKS',None)
     if enabled:env['CSL_HIGHS_INTERNAL_CLOCKS']='1'
     start=time.monotonic_ns();rc,timeout,stdout,stderr,resource=run_with_resource_receipt([str(binary),str(fixture),strategy,'--phase-diagnostics'],300,env)
     row={'attempt_id':aid,'horizon':h,'repetition':rep,'warmup':rep==0,'strategy':strategy,'native_clocks':enabled,'process_status':'timed_out' if timeout else 'completed' if rc==0 else 'failed','return_code':rc,'process_wall_ns':time.monotonic_ns()-start,'resource_receipt':resource,'scenario_sha256':fixturehash}
     for name,data in [('stdout',stdout),('stderr',stderr)]:
      path=out/'raw'/f'{aid}.{name}';path.write_bytes(data);row[name+'_path']=str(path.relative_to(out));row[name+'_sha256']=sha(data)
     try:row['result']=parse_result_stdout(stdout,enabled);row['clock_groups']=parse_stderr(stderr,enabled);row['check_status'],row['check_reasons']=check_attempt(row,fixturehash)
     except Exception as error:row.update(check_status='unavailable',check_reasons=[str(error)])
     f.write(json.dumps(row,allow_nan=False)+'\n');f.flush();rows.append(row)
manifest['load_end']=os.getloadavg();manifest['attempt_count']=len(rows);manifest['checked_count']=sum(r['check_status']=='verified' for r in rows);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'attempts':len(rows),'statuses':{s:sum(r['check_status']==s for r in rows) for s in set(r['check_status'] for r in rows)},'output':str(out)}))
