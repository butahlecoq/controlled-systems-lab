# Interleaved native-clock observations

84 exact-checked attempts, including 36 measured on/off pairs. OBS collection remains enabled in both modes. Same binary hash is bound to the earlier archived build receipt; its precommit-source limitation remains explicit. Concurrent builds and absent isolated limiter profiling make all performance differences inconclusive. Whole-process resource receipts include startup/setup; strategy timing includes clock serialization. Native timer scopes overlap and are never summed.

`capture.py` records the collection procedure. Its absolute paths describe this local execution; copied inputs, raw streams, parsed records, checks, hashes and summary are retained. This is a local diagnostic artifact, not a published comparison or a complete REVIEW-05 result.
