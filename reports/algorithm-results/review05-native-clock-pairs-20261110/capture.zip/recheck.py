from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from check_horizon_ladder import check_attempt
from highs_clock_events import parse_result_stdout,parse_stderr
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[json.loads(line) for line in (root/'attempts.jsonl').read_text().splitlines()]
assert len(rows)==84
keys=set()
for row in rows:
 key=(row['horizon'],row['strategy'],row['repetition'],row['native_clocks'])
 assert key not in keys
 keys.add(key)
 fixture=root/'inputs'/('horizon01-t%02d.json'%row['horizon'])
 assert sha(fixture.read_bytes())==row['scenario_sha256']
 assert row['process_status']=='completed' and row['return_code']==0
 data={}
 for kind in ('stdout','stderr'):
  relative=Path(row[kind+'_path'])
  assert not relative.is_absolute() and '..' not in relative.parts
  data[kind]=(root/relative).read_bytes()
  assert sha(data[kind])==row[kind+'_sha256']
 assert parse_result_stdout(data['stdout'],row['native_clocks'])==row['result']
 assert parse_stderr(data['stderr'],row['native_clocks'])==row['clock_groups']
 status,reasons=check_attempt(row,row['scenario_sha256'])
 assert status=='verified',reasons
print(json.dumps({'attempts':len(rows),'verified':len(rows),'performance_verdict':'inconclusive'}))
