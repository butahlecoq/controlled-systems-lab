import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
base=Path('/home/butahlecoq/.local/share/codex/tmp');root=Path.cwd();stage=base/'mpc10-package-final-20261110';stage.mkdir(exist_ok=False)
out=root/'benchmarks/reporting/mpc10/evidence/comparison-525871ea';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(base/'mpc10-final-capture-20261110',stage/'capture')
shutil.copytree(base/'mpc10-core-coverage-before-fix-20261110',stage/'original-core-before-fix')
shutil.copytree(base/'mpc10-core-coverage-corrected-T3-20261110',stage/'engineering-first-core-correction')
shutil.copytree(base/'mpc10-environment-qualification-20261110',stage/'qualification')
receipt=stage/'qualification/native-build-receipt.json';r=json.loads(receipt.read_text());r['requested_jobs_per_build_invocation']=r.pop('maximum_build_jobs');r['build_attempt_scope']='One initial overlapping Ninja invocation was interrupted; its logs and subsequent successful serial rebuilds are retained. Algorithm workers were sequential.';receipt.write_text(json.dumps(r,indent=2)+'\n')
env=json.loads((stage/'capture/environment.json').read_text());assert not env['source_dirty'];assert env['bridge_sha256']==r['consumer_bridge_sha256'];assert env['source_sha256']['bridge.cpp']==r['consumer_source_sha256'];core=subprocess.check_output(['git','show',env['source_revision']+':src/synthesis/hybrid_linear_h_family_verifier.cpp']);assert hashlib.sha256(core).hexdigest()==r['corrected_verifier_source_sha256'];(stage/'capture-core-source.cpp').write_bytes(core)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();reading=stage/('reading-tools-'+revision[:8]);reading.mkdir()
for p in sorted((root/'benchmarks/reporting/mpc10').glob('*')):
 if p.is_file():shutil.copy2(p,reading/p.name)
styles=stage/'reporting-style';styles.mkdir()
for name in ['figure_style.py','plot.py','report_data.py','requirements.txt']:shutil.copy2(root/'scripts/reports'/name,styles/name)
checks=stage/'checks';checks.mkdir()
for pattern in ['mpc10-final-verification-v*.json','mpc10-final-check*.json','mpc10-final-check*.log','mpc10-*tests.log','mpc10-*-red.log','mpc10-figure-repeat-check.json','mpc10-post-capture-core-followup.json']:
 for p in base.glob(pattern):
  if p.is_file():shutil.copy2(p,checks/p.name)
engineering=stage/'engineering-attempts';engineering.mkdir()
for pattern in ['mpc10-native-smoke*','mpc10-scip-smoke*','mpc10-scip-oracle-pilot-20261110','mpc10-scip-interrupt-smoke-20261110','mpc10-scip-raw-binding-smoke-20261110']:
 for p in base.glob(pattern):
  if p.is_dir() and not (engineering/p.name).exists():shutil.copytree(p,engineering/p.name)
for pattern in ['mpc10-build*.log','mpc10-configure.log','mpc10-ninja-recompact.log','mpc10-figures*.log','mpc10-final-figures.log']:
 for p in base.glob(pattern):
  if p.is_file():shutil.copy2(p,engineering/p.name)
regressions=stage/'core-regressions';regressions.mkdir();old=base/'issue910-coverage-regression'
for p in old.iterdir():
 if p.is_file() and p.suffix in ['.json','.stdout','.stderr']:shutil.copy2(p,regressions/p.name)
for name in ['src/synthesis/hybrid_linear_h_family_verifier.cpp','tests/unit/synthesis/hybrid_linear_h_coverage_tests.cpp']:
 source=Path('/home/butahlecoq/.local/share/codex/worktrees/hybrid-exact-coverage-status-910-20261110')/name;shutil.copy2(source,regressions/source.name)
shutil.copy2(base/'mpc10-public-build/CMakeCache.txt',stage/'qualification/CMakeCache.txt')
for p in (base/'mpc10-saved-figures-v4-20261110').iterdir():
 if p.is_file():shutil.copy2(p,stage/('earlier-render-'+p.name))
for p in (base/'mpc10-final-figures-20261110').iterdir():
 if p.is_file() and p.name!='README.md':shutil.copy2(p,out/p.name)
shutil.copy2(base/'mpc10-final-verification-v6.json',out/'verification.json');shutil.copy2(base/'mpc10-final-metrics-v4.json',out/'metrics.json');shutil.copy2(Path(__file__),stage/'package-builder.py')
verification=json.loads((out/'verification.json').read_text());actual={p.relative_to(stage/'capture').as_posix():sha(p) for p in (stage/'capture').rglob('*') if p.is_file() and p.name!='file-hashes.json'};assert actual==verification['input_files']
metrics=json.loads((out/'metrics.json').read_text());assert metrics['verification_sha256']==sha(out/'verification.json');export=json.loads((out/'figure-export.json').read_text());assert export['verification_sha256']==sha(out/'verification.json');assert json.loads((out/'figure-data.json').read_text())['verification_sha256']==sha(out/'verification.json')
for name,digest in export['figures'].items():assert sha(out/name)==digest
(stage/'layer-binding.json').write_text(json.dumps({'capture_revision':env['source_revision'],'reading_revision':revision,'reading_sources':{p.name:sha(p) for p in reading.iterdir() if p.is_file()},'capture_core_source_sha256':sha(stage/'capture-core-source.cpp'),'mathematical_verification_sha256':sha(out/'verification.json'),'source_epoch_scope':'Original capture and clocks preserved. Current readers/renderers and the later core-only refutation refinement are separate layers. Engineering smokes retain only recorded provenance and are excluded from qualified observations.'},indent=2)+'\n')
(stage/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(stage).as_posix()}\n' for p in sorted(stage.rglob('*')) if p.is_file() and p!=stage/'SHA256SUMS'))
with zipfile.ZipFile(out/'capture.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():
   info=zipfile.ZipInfo(p.relative_to(stage).as_posix(),(2026,11,10,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes())
(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
with zipfile.ZipFile(out/'capture.zip') as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
print('archive',sha(out/'capture.zip'),'size', (out/'capture.zip').stat().st_size,'capture inputs',len(actual))
