objective value:                                    0
x_0                                                 0 	(obj:1)
