objective value:                                    0
action_0_0                                         -0 	(obj:0)
action_0_1                                         -0 	(obj:0)
action_0_2                                          1 	(obj:0)
x_0                                                 0 	(obj:0)
x_1                                                 0 	(obj:1)
u_0                                                 0 	(obj:0)
