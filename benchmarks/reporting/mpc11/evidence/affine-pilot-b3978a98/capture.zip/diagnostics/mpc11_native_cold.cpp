#include <Highs.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
int main(int argc,char** argv) {
 if(argc!=2)return 2;
 std::ifstream stream(argv[1]);nlohmann::json j;stream>>j;
 HighsModel model;auto& lp=model.lp_;const auto n=j["variables"].size();lp.num_col_=n;lp.num_row_=1;
 lp.col_cost_=j["linear"].get<std::vector<double>>();lp.offset_=j["offset"];
 for(auto row:j["variables"]){lp.col_lower_.push_back(row[0]);lp.col_upper_.push_back(row[1]);}
 lp.row_lower_={-kHighsInf};lp.row_upper_={kHighsInf};
 lp.a_matrix_.num_col_=n;lp.a_matrix_.num_row_=1;lp.a_matrix_.format_=MatrixFormat::kRowwise;
 lp.a_matrix_.start_={0,1};lp.a_matrix_.index_={0};lp.a_matrix_.value_={1};
 auto& h=model.hessian_;h.dim_=n;h.format_=HessianFormat::kTriangular;h.start_={0};
 for(size_t col=0;col<n;++col){for(size_t row=col;row<n;++row){double value=j["q_matrix"][row][col];if(value!=0){h.index_.push_back(row);h.value_.push_back(value);}}h.start_.push_back(h.value_.size());}
 Highs solver;solver.setOptionValue("threads",1);solver.setOptionValue("parallel","off");solver.setOptionValue("presolve","off");solver.setOptionValue("qp_regularization_value",0.0);solver.setOptionValue("use_warm_start",false);solver.setOptionValue("qp_iteration_limit",100000);solver.setOptionValue("time_limit",20.0);solver.passModel(model);auto api=solver.run();
 nlohmann::json result={{"api",static_cast<int>(api)},{"model_status",solver.modelStatusToString(solver.getModelStatus())},{"objective",solver.getObjectiveValue()},{"primal",solver.getSolution().col_value}};
 std::cout<<"RESULT "<<result.dump()<<'\n';
}
