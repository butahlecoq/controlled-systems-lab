import copy,hashlib,json,shutil,zipfile
from pathlib import Path
base=Path('/home/butahlecoq/.local/share/codex/tmp');p=base/'mpc11-timing-package-20261110';out=Path('benchmarks/reporting/mpc11/evidence/timing-five-68515dcb')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
summary=json.loads((base/'mpc11-alternating-five-summary-v3.json').read_text());old=json.loads((base/'mpc11-alternating-five-summary-v2.json').read_text())
assert old['aggregates']==summary['aggregates']
for a,b in zip(old['records'],summary['records']):
 a=copy.deepcopy(a);b=copy.deepcopy(b);a.pop('offline_saved_checker_seconds',None);b.pop('offline_saved_checker_seconds',None);assert a==b
actual={f.relative_to(p/'capture').as_posix():sha(f) for f in sorted((p/'capture').rglob('*')) if f.is_file()};assert actual==summary['input_files']
assert sha(p/'review-a238b05c/check_timing.py')==summary['checked_sources']['review_tool_sha256']
for name in ['mpc11-alternating-five-summary-v3.json','mpc11-alternating-five-check-v3.log']:shutil.copy2(base/name,p/'checks'/name)
shutil.copy2(Path(__file__),p/'package-builder.py')
(p/'SHA256SUMS').write_text(''.join(f'{sha(f)}  {f.relative_to(p).as_posix()}\n' for f in sorted(p.rglob('*')) if f.is_file() and f!=p/'SHA256SUMS'))
with zipfile.ZipFile(out/'capture.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(p.rglob('*')):
  if f.is_file():
   info=zipfile.ZipInfo(f.relative_to(p).as_posix(),(2026,11,10,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,f.read_bytes())
shutil.copy2(base/'mpc11-alternating-five-summary-v3.json',out/'summary.json')
receipt={'schema':'csl.mpc11.timing-archive-verification/1','archive_sha256':sha(out/'capture.zip'),'summary_sha256':sha(out/'summary.json'),'consumed_capture_files':len(actual),'all_18_units_status':'completed','all_420_nlp_transcriptions_checked':True,'affine_qp_and_nonlinear_execution_checks':'all six arms including warmup checked','measured_samples_per_arm_and_case':5,'warmup_excluded':True,'summary_input_map_equals_archived_capture_bytes':True,'review_tool_sha256':summary['checked_sources']['review_tool_sha256'],'final_reader_adds_input_binding_without_changing_v2_numerical_or_timing_extraction':True,'verdict':summary['verdict']}
(out/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in sorted(out.iterdir()) if f.is_file() and f.name!='SHA256SUMS'))
with zipfile.ZipFile(out/'capture.zip') as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
print(json.dumps(receipt,indent=2))
